
$(document).ready(function(){

    $(".advertisement_listing").click(function(){
        $.ajax({
            headers: { "X-Requested-With": "XMLHttpRequest" },
            url: '/job_seeker/job_listings/',
            type: 'get',
            data: {
                advertisement_id: $(this).text()
            },
            success: function(response) {
                $("#chosen_advertisement").html(response.chosen_ad)
            }
        });
    });
});

$(document).ready(function(){

    $(".my_listing").click(function(){
        $.ajax({
            headers: { "X-Requested-With": "XMLHttpRequest" },
            url: '/employer/home/',
            type: 'get',
            data: {
                advertisement_id: $(this).text()
            },
            success: function(response) {
                $("#chosen_advertisement").html(response.chosen_ad)
            }
        });
    });
});

$(document).ready(function(){

    $(".application_listing").click(function(){
        $.ajax({
            headers: { "X-Requested-With": "XMLHttpRequest" },
            url: '/employer/view_applications/',
            type: 'get',
            data: {
                application_id: $(this).text()
            },
            success: function(response) {
                $("#chosen_application").html(response.chosen_app)
            }
        });
    });
});

$(document).ready(function(){

    $(".seeker_app_listing").click(function(){
        $.ajax({
            headers: { "X-Requested-With": "XMLHttpRequest" },
            url: '/job_seeker/applications/',
            type: 'get',
            data: {
                application_id: $(this).text()
            },
            success: function(response) {
                $("#chosen_application").html(response.chosen_app)
            }
        });
    });
});

// Fetches any new message notifications and updates message icon to show this
function get_message_notifications(){
    $.ajax({
        type: 'GET',
        url : "/messages/notifications_count/",

        success: function(response){
            let element=document.createElement("h1");
            element.classList.add("notification-counter-icon")
            if (response.message_notifications_count > 0 && response.message_notifications_count < 100){
                element.innerText=response.message_notifications_count
                $("#message-notification-counter").html(element)
            }
            else if (response.message_notifications_count > 99){
                element.style.width = "150%"
                element.style.left = "20%"
                element.innerText="99+"
                $("#message-notification-counter").html(element)
            }
            else{
                $("#message-notification-counter").html('')
            }

        },
        error: function(response){
            console.log("An error getting notifications occurred")
        }
    });
}

// Check for new message notifications at set intervals
$(document).ready(function(){
    setInterval(get_message_notifications,1000);
})

// Check for new message notifications on page load
$(document).ready(get_message_notifications)

// Fetches the current notification count for the user
function get_notifications_count(){
    $.ajax({
        type: 'GET',
        url : "/notifications/update_count/",

        success: function(response){
            let element=document.createElement("h1");
            element.classList.add("notification-counter-icon")
            if (response.notifications_count > 0 && response.notifications_count < 100){
                element.innerText=response.notifications_count
                $("#notification-counter").html(element)
            }
            else if (response.notifications_count > 99){
                element.style.width = "150%"
                element.style.left = "20%"
                element.innerText="99+"
                $("#notification-counter").html(element)
            }
            else{
                $("#notification-counter").html('')
            }

        },
        error: function(response){
            console.log("An error getting notifications occurred")
        }
    });
}

// Check for new notifications at set intervals
$(document).ready(function(){
    setInterval(get_notifications_count,1000);
})

// Check for new notifications on page load
$(document).ready(get_notifications_count)

