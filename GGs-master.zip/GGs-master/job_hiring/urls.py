"""job_hiring URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from jobs import views
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('admin/', admin.site.urls),
    path('employer_sign_up/', views.employer_sign_up, name='employer_sign_up'),
    path('job_seeker_sign_up/', views.job_seeker_sign_up, name='job_seeker_sign_up'),
    path('', views.home, name='home'),
    path('home/example_advertisement/', views.example_advertisement, name='example_advertisement'),
    path('log_in/', views.log_in, name='log_in'),
    path('log_out/', views.log_out, name='log_out'),
    path('password/', views.password, name='password'),
    path('profile/', views.profile, name='profile'),
    path('view_pdf/', views.view_pdf, name='view_pdf'),


    # Job Seeker URLs
    path('job_seeker/home/', views.job_seeker_home, name='job_seeker_home'),
    path('job_seeker/job_listings/', views.job_seeker_job_listings, name='job_seeker_job_listings'),
    path('job_seeker/job_listings/process_job_application/<int:advertisement_id>/', views.process_job_application,
         name='process_job_application'),
    path('job_seeker/job_listings/withdraw_job_application/<int:advertisement_id>/', views.withdraw_job_application,
         name='withdraw_job_application'),
    path('job_seeker/job_listings/report_job_advertisement/<int:advertisement_id>/', views.report_job_advertisement,
         name='report_job_advertisement'),
    path('job_seeker/applications/', views.job_seeker_applications, name='job_seeker_applications'),

    # Employer URLs
    path('employer/home/', views.employer_home, name='employer_home'),
    path('employer/delete_advertisement/<int:advertisement_id>/', views.delete_advertisement, name='delete_advertisement'),
    path('employer/create_advertisement/', views.create_advertisement,name='create_advertisement'),
    path('employer/view_applications/', views.list_applications, name='view_applications'),
    path('employer/view_applications/accept/<int:application_id>/', views.accept_application, name='accept_application'),
    path('employer/view_applications/reject/<int:application_id>/', views.reject_application, name='reject_application'),
    path('employer/view_cv/<int:job_seeker_id>/', views.view_job_seeker_cv, name='view_cv'),
    path('employer/update_advertisement_preview/', views.update_advertisement_preview, name='update_advertisement_preview'),

    # User messaging urls
    path('message_home/', views.message_home, name='message_home'),
    path('messages/send/', views.send_message, name='send_message'),
    path('messages/get/', views.get_messages_in_channel, name='get_messages_in_channel'),
    path('messages/your_messages/', views.your_messages, name='your_messages'),
    path('messages/start_channel/<int:receiver_id>/', views.start_channel, name='start_message_channel'),

    # Notification urls
    path('notifications/', views.your_notifications, name='your_notifications'),
    path('messages/channel/notifications_count/', views.update_message_channel_notifications_count, name='message_channel_notifications_count'),
    path('messages/notifications_count/', views.update_message_notifications_count, name='message_notifications_count'),
    path('notifications/update_count/', views.update_notifications_count, name='update_notifications_count'),
    path('notifications/update/', views.update_notifications, name='update_notifications'),
    path('notifications/delete/', views.delete_notifications, name='delete_notifications'),

]

urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
