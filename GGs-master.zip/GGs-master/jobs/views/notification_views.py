"""Contains all views related to user notifications"""

from django.http import HttpResponse, JsonResponse
from django.shortcuts import render
from django.template.loader import render_to_string

from jobs.helpers import user_access
from jobs.models import Message, MessageChannel, MessageNotification, \
    Notification


@user_access
def update_message_notifications_count(request):
    """
    Returns the number of message notifications belonging to user
    Returns a JSON response containing this
    """
    message_notifications_count = MessageNotification.objects.filter(user_to_notify=request.user).count()
    return JsonResponse({"message_notifications_count":message_notifications_count})

@user_access
def update_notifications_count(request):
    """
    Returns the number of notifications belonging to the user
    Returns a JSON response containing this
    NOTE WE ARE EXCLUDING MESSAGE NOTIFICATIONS AS WE DO NOT WANT TO INCLUDE THEM HERE
    """
    notifications_count = Notification.objects.filter(user_to_notify=request.user).exclude(id__in=MessageNotification.objects.all()).count()
    return JsonResponse({"notifications_count":notifications_count})

@user_access
def update_message_channel_notifications_count(request):
    """
    Returns the number of notifications belonging to the user in given channel
    Returns a JSON response containing this
    """
    channel_id = request.GET['channel_id']
    channel = MessageChannel.objects.get(id=channel_id)
    messages_in_channel = Message.objects.filter(message_channel=channel)

    channel_notifications_count = MessageNotification.objects.filter(user_to_notify=request.user, message__in=messages_in_channel).count()
    return JsonResponse({"channel_notifications_count":channel_notifications_count})


@user_access
def update_notifications(request):
    """
    Updates notifications for user in real time
    NOTE WE ARE EXCLUDING MESSAGE NOTIFICATIONS AS WE DO NOT WANT TO INCLUDE THEM HERE
    """
    notifications = Notification.objects.filter(user_to_notify=request.user).exclude(id__in=MessageNotification.objects.all())
    notifications_partial = render_to_string('partials/notifications.html',
                                                 {'notifications': notifications})

    # If no new notifications then don't update page
    if request.GET.get('notifications_text').count("notification_listing")==notifications_partial.count("notification_listing"):
        return HttpResponse('No new notifications to update')

    return JsonResponse({"notifications_partial":notifications_partial})

@user_access
def delete_notifications(request):
    """Deletes a given notification by its"""

    notification_id_to_delete = request.GET['notification_id'].split('#')[0]
    Notification.objects.get(id=notification_id_to_delete).delete()

    return HttpResponse('Notification deleted')


@user_access
def your_notifications(request):
    """
    Shows the user a list of all their notifications
    NOTE WE ARE EXCLUDING MESSAGE NOTIFICATIONS AS WE DO NOT WANT TO INCLUDE THEM HERE
    """
    notifications_to_show = Notification.objects.filter(user_to_notify=request.user).exclude(id__in=MessageNotification.objects.all())

    return render(request, 'your_notifications.html', {'notifications':notifications_to_show})



