"""Contains all views related to job seekers"""

from django.shortcuts import render, redirect
from django.contrib import messages
from django.utils import timezone
from django.core.paginator import Paginator
from django.http import JsonResponse
from django.template.loader import render_to_string
from djmoney.money import Money


from job_hiring.settings import JOB_ADVERTISEMENTS_PER_PAGE,JOB_APPLICATIONS_PER_PAGE
from jobs.helpers import is_ajax, has_reported, has_applied
from jobs.forms.job_seeker_forms import JobAdvertisementReportForm
from jobs.models import JobAdvertisement, JobApplication, JobSeeker, JobAdvertisementReport, ReportGroup
from jobs.helpers import job_seeker_access, estimate_yearly_salary
from jobs.matchers import order_by_application_count, template_match, job_title_match, location_match, remote_work_match, hours_match, job_type_match, salary_match, delete_expired_adverts


@job_seeker_access
def job_seeker_job_listings(request):
    """Get all job advertisements and annotate them with the count of job applications for each advertisement"""
    seeker = JobSeeker.objects.get(user_id=request.user.id)
    delete_expired_adverts()
    all_advertisements = JobAdvertisement.objects.all()
    advertisements = template_match(list(all_advertisements), seeker, remote_work_match, job_type_match, job_title_match, hours_match, salary_match, location_match, order_by_application_count)

    paginator = Paginator(advertisements, JOB_ADVERTISEMENTS_PER_PAGE)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)

    job_count = len(advertisements)

    chosen_advertisement_id = request.GET.get('advertisement_id')
    application_count = 0
    
    if chosen_advertisement_id:
        try:
            chosen_advertisement_id = chosen_advertisement_id.replace("\n", "").split()[0]
            chosen_ad = JobAdvertisement.objects.get(id=chosen_advertisement_id)
            application_count = JobApplication.objects.filter(advertisement=chosen_ad).count()

        except:
            application_count = 0

        seeker = JobSeeker.objects.get(user_id=request.user.id)

        if is_ajax(request):
            chosen_ad_details_partial = render_to_string('partials/job_advertisement_details.html',
                                                         {'advertisement': chosen_ad,
                                                          'can_apply': True,
                                                          'has_applied': has_applied(seeker, chosen_ad),
                                                          'has_reported': has_reported(seeker, chosen_ad)})
            return JsonResponse({'chosen_ad': chosen_ad_details_partial, 'application_count': application_count}, status=200)
    else:
        if len(advertisements) > 0:
            top_ad = advertisements[0]
            chosen_ad_details_partial = render_to_string('partials/job_advertisement_details.html',
                                                         {'advertisement': top_ad,
                                                          'can_apply': True,
                                                          'has_applied': has_applied(seeker, top_ad),
                                                          'has_reported': has_reported(seeker, top_ad)})
        else:
            chosen_ad_details_partial = None

    yearly_estimates = {}
    if seeker.min_salary != None:
        for ad in advertisements:
            yearly_estimates[ad.id] = Money(estimate_yearly_salary(ad, seeker), seeker.min_salary.currency)
    else:
        yearly_estimates = None

    return render(request, 'job_seeker_job_listings.html', {'yearly_estimates': yearly_estimates, 'chosen_ad': chosen_ad_details_partial, 'page_obj': page_obj, 'advertisements': advertisements, 'application_count': application_count, 'job_count': job_count})


@job_seeker_access
def job_seeker_applications(request):
    """View for job-seekers to see all their applications"""
    current_job_seeker = request.user
    applications = JobApplication.objects.filter(job_seeker=JobSeeker.objects.get(user_id=current_job_seeker.id)).order_by('id')

    paginator = Paginator(applications, JOB_APPLICATIONS_PER_PAGE)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)

    application_count = applications.count()

    chosen_application_id = request.GET.get('application_id')
    if chosen_application_id:
        try:
            chosen_application_id = chosen_application_id.replace("\n", "").split()[0]
            chosen_app = JobApplication.objects.get(id=chosen_application_id)
            
        except:
            application_count = 0


        if is_ajax(request):
            chosen_app_details_partial = render_to_string('partials/job_advertisement_details.html',
                                                         {'advertisement': chosen_app.advertisement,
                                                          'can_apply' : False,
                                                          'has_applied': True})
            return JsonResponse({'chosen_app': chosen_app_details_partial, 'application_count': application_count}, status=200)

    else:
        if len(applications) > 0:
            top_app = applications[0]
            chosen_app_details_partial = render_to_string('partials/job_advertisement_details.html',
                                                         {'advertisement': top_app.advertisement,
                                                          'can_apply' : False,
                                                          'has_applied': True})
        else:
            chosen_app_details_partial = None


    return render(request, 'job_seeker_applications.html', {'chosen_app': chosen_app_details_partial, 'page_obj': page_obj, 'applications': applications, 'application_count': application_count})


@job_seeker_access
def process_job_application(request, advertisement_id):
    """Creates a job application for a user applying to a job advertisement"""
    advertisement = JobAdvertisement.objects.get(id=advertisement_id)
    applicant = JobSeeker.objects.get(user_id=request.user.id)
    application = JobApplication.objects.create(
        advertisement=advertisement,
        job_seeker=applicant,
        application_date=timezone.now()
    )
    messages.add_message(request, messages.SUCCESS, "Your application was successful!")

    return redirect('job_seeker_job_listings')


@job_seeker_access
def withdraw_job_application(request, advertisement_id):
    """Withdraws a job application for a user applying to a job advertisement"""
    advertisement = JobAdvertisement.objects.get(id=advertisement_id)
    applicant = JobSeeker.objects.get(user_id=request.user.id)
    application = JobApplication.objects.get(advertisement=advertisement, job_seeker=applicant)
    application.delete()
    messages.add_message(request, messages.SUCCESS, "Your application was withdrawn!")

    return redirect('job_seeker_applications')


@job_seeker_access
def report_job_advertisement(request, advertisement_id):
    """Submits a report for a job advertisement"""
    if request.method == 'POST':
        form = JobAdvertisementReportForm(request.POST)
        if form.is_valid():
            report_text = form.cleaned_data.get('report_text')
            advertisement = JobAdvertisement.objects.get(id=advertisement_id)
            reporter = JobSeeker.objects.get(user_id=request.user.id)

            if not (ReportGroup.objects.filter(job_advertisement=advertisement).exists()):
                ReportGroup.objects.create(job_advertisement=advertisement)

            report_group = ReportGroup.objects.get(job_advertisement=advertisement)

            JobAdvertisementReport(reporter=reporter, report_date=timezone.now(),
                                   report_text=report_text, report_group=report_group).save()

        return redirect("job_seeker_job_listings")

    form = JobAdvertisementReportForm()
    return render(request, 'submit_job_advertisement_report.html', {'form': form,
                                                                    'advertisement_id': advertisement_id})
