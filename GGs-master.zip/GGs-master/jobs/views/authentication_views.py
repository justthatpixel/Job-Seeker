from django.contrib import messages
from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout

from jobs.helpers import login_prohibited
from jobs.forms.authentication_forms import JobSeekerSignUpForm, EmployerSignUpForm, LogInForm
from jobs.models.user_models import Employer, JobSeeker


@login_prohibited
def job_seeker_sign_up(request):
    """Define the sign-up page for job seekers of the website"""
    if request.method == 'POST':
        form = JobSeekerSignUpForm(request.POST)
        if form.is_valid():
            job_seeker = form.save()
            # Have to pass the job seeker's user field for authentication
            login(request, job_seeker.user)
            messages.add_message(request, messages.SUCCESS,
                                 "Your sign up was successful! You have been automatically logged in")
            return redirect('log_in')
    else:
        form = JobSeekerSignUpForm()
    return render(request, 'auth_pages/sign_up_job_seeker.html', {'form': form})


@login_prohibited
def employer_sign_up(request):
    """Define the sign-up page for employers of the website"""
    if request.method == 'POST':
        form = EmployerSignUpForm(request.POST)
        if form.is_valid():
            employer = form.save()
            # Have to pass the employer's user field for authentication
            login(request, employer.user)
            messages.add_message(request, messages.SUCCESS,
                                 "Your sign up was successful! You have been automatically logged in")
            return redirect('log_in')
    else:
        form = EmployerSignUpForm()
    return render(request, 'auth_pages/sign_up_employer.html', {'form': form})


@login_prohibited
def log_in(request):
    """Define the login page of the website"""
    if request.method == 'POST':
        form = LogInForm(request.POST)
        if form.is_valid():
            email = form.cleaned_data.get('email')
            password = form.cleaned_data.get('password')
            user = authenticate(email=email, password=password)
            if user is not None:
                if user.is_active:
                    login(request, user)
                    messages.add_message(request, messages.SUCCESS, "You have been logged in successfully!")
                    # If the employer/job seeker was created by admin then their details may not have been created
                    # If this is the case their details are created here to prevent errors during site navigation
                    if user.user_type == 'employer':
                        if not Employer.objects.filter(user=user).exists():
                            Employer.objects.create(user=user)
                    if user.user_type == 'job_seeker':
                        if not JobSeeker.objects.filter(user=user).exists():
                            JobSeeker.objects.create(user=user)

                    if user.is_staff or user.is_director:
                        return redirect('admin:index')

                    return redirect('home')
        messages.add_message(request, messages.ERROR, "The credentials provided were invalid!")
    form = LogInForm()
    return render(request, 'auth_pages/log_in.html', {'form': form})


def log_out(request):
    """Logs the user out"""
    logout(request)
    return redirect('home')
