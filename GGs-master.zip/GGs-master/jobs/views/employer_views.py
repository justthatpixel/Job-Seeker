"""Contains all views related to employers"""

from django.shortcuts import render, redirect
from django.contrib import messages
from django.utils import timezone
from django.core.paginator import Paginator
from django.http import JsonResponse
from django.core.exceptions import ObjectDoesNotExist
from django.template.loader import render_to_string
from django.http import HttpResponse, JsonResponse
from djmoney.money import Money,Currency
from django.urls import reverse
from djmoney.money import Money, Currency

from job_hiring.settings import JOB_APPLICATIONS_PER_PAGE
from jobs.forms.employer_forms import AdvertisementForm
from jobs.models import JobAdvertisement, Employer, JobApplication, JobSeeker, \
                        JobApplicationStatusNotification
from jobs.helpers import is_ajax
from jobs.helpers import employer_access
from jobs.enums import JOB_TYPES


@employer_access
def delete_advertisement(request, advertisement_id):
    """Deletes an advertisement"""
    advertisement = JobAdvertisement.objects.get(id=advertisement_id)
    try:
        advertisement.delete(is_admin=False)
        messages.success(request, 'Advertisement deleted successfully!')
    except:
        messages.error(request, 'Advertisement could not be deleted!')
    return redirect('employer_home')


@employer_access
def create_advertisement(request):
    """Defines the page for the employer to create and view advertisements"""

    if request.method == 'POST':
        base_advertisement = JobAdvertisement.objects.create(employer=Employer.objects.get(user=request.user))
        form = AdvertisementForm(request.POST, instance=base_advertisement)
        if form.is_valid():
            form.save()
            messages.add_message(request, messages.SUCCESS, "Advertisement Created!")
            return redirect('employer_home')
        base_advertisement.delete(is_admin=False)
        messages.add_message(request, messages.ERROR, "invalid form input")
    else:
        form = AdvertisementForm()
    return render(request, 'create_advertisement.html', {'form': form})


@employer_access
def list_applications(request):
    """View for employers to see applications to their advertisements"""
    # Gets advertisements created by logged in user
    advertisements = JobAdvertisement.objects.filter(employer=Employer.objects.get(user_id=request.user.id))
    # Gets applications to the advertisements above
    applications = JobApplication.objects.filter(advertisement__in=advertisements).order_by('id')

    paginator = Paginator(applications, JOB_APPLICATIONS_PER_PAGE)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)

    application_count = applications.count()

    chosen_application_id = request.GET.get('application_id')
    if chosen_application_id:
        try:
            chosen_application_id = chosen_application_id.replace("\n", "").split()[0]
            chosen_app = JobApplication.objects.get(id=chosen_application_id)

        except:
            application_count = 0


        if is_ajax(request):
            chosen_app_details_partial = render_to_string('partials/job_application_details.html',
                                                         {'application': chosen_app})
            return JsonResponse({'chosen_app': chosen_app_details_partial,
                                 'application_count': application_count}, status=200)

    else:
        if len(applications) > 0:
            top_app = applications[0]
            chosen_app_details_partial = render_to_string('partials/job_application_details.html',
                                                         {'application': top_app})
        else:
            chosen_app_details_partial = None

    return render(request, 'employer_applications.html', {'chosen_app': chosen_app_details_partial,
                                                          'page_obj': page_obj,
                                                          'applications': applications,
                                                          'application_count': application_count })


@employer_access
def accept_application(request, application_id):
    """Allows for employers to set an application to accepted"""
    try:
        application = JobApplication.objects.get(id=application_id)
    except ObjectDoesNotExist:
        return redirect('view_applications')
    else:
        application.status = "Accepted"
        application.save()

        # Create notification for job seeker
        notification = JobApplicationStatusNotification.objects.create(
            user_to_notify=application.job_seeker.user,
            header=f" One of your applications has changed status: {application.advertisement.job_title}",
            description=f"{application.advertisement.job_title} : {application.status}",
            application=application,
            link=reverse('job_seeker_applications'),
        )

        messages.success(request, 'Application accepted successfully!')

        return redirect('view_applications')


@employer_access
def reject_application(request, application_id):
    """Allows for employers to set an application to rejected"""
    try:
        application = JobApplication.objects.get(id=application_id)
    except ObjectDoesNotExist:
        return redirect('view_applications')
    else:
        application.status = "Rejected"
        application.save()

        # Create notification for job seeker
        notification = JobApplicationStatusNotification.objects.create(
            user_to_notify=application.job_seeker.user,
            header=f" One of your applications has changed status: {application.advertisement.job_title}",
            description=f"{application.advertisement.job_title} : {application.status}",
            application=application,
            link=reverse('job_seeker_applications'),
        )

        messages.success(request, 'Application rejected successfully!')

        return redirect('view_applications')


@employer_access
def view_job_seeker_cv(request, job_seeker_id):
    """Allow an employer to view a job seeker's cv"""
    try:
        job_seeker = JobSeeker.objects.get(user_id=job_seeker_id)
    except ObjectDoesNotExist:
        return redirect('view_applications')
    else:
        if job_seeker.cv is not None:
            response = HttpResponse(job_seeker.cv, content_type='application/pdf')
            response['Content-Disposition'] = f'inline;filename={job_seeker.user.first_name} {job_seeker.user.last_name}.pdf'
            return response
        else:
            return redirect("view_applications")


@employer_access
def update_advertisement_preview(request):
    """
    Updates the advertisement every time there is an 
    input in the create advertisement form
    """
    
    
    if request.POST['salary_0'] and request.POST['salary_1']:      
        salary = Money(request.POST['salary_0'], request.POST['salary_1'])
    else:
            salary = Money(0,Currency("EUR"))
            
    # Create preview advertisement to give to advertisement partial
    preview_advertisement = PreviewAdvertisement(
        job_title=request.POST['job_title'],
        job_description=request.POST['job_description'],
        start_date=request.POST['start_date'],
        salary = salary,
        salary_type=request.POST['salary_type'],
        job_type=request.POST['job_type'],
        hours=request.POST['hours'],
        remote_work=request.POST['remote_work'],
        website=request.POST['website'],
        benefits=request.POST['benefits'],
        country=request.POST['country'],
        state=request.POST['state'],
        city=request.POST['city'],
        street=request.POST['street'],
        postcode=request.POST['postcode'],
    )
    

    preview_advertisement_partial = render_to_string('partials/job_advertisement_details.html',
                                                     {'advertisement': preview_advertisement})

    return JsonResponse({"advertisement": preview_advertisement_partial})


def example_advertisement(request):
    """ Example of an advertisement used to display features of the site """

    example_advertisement = PreviewAdvertisement(
        job_title='Software Engineer',
        job_description='We are looking for a professional capable of designing code, testing and maintaining software programs for various purposes.',
        start_date=timezone.now()+timezone.timedelta(days=21),
        salary=Money(80000, Currency("USD")),
        salary_type='Yearly',
        job_type=JOB_TYPES[1][0],
        hours=40,
        remote_work=False,
        website='https://google.com',
        benefits='Free food, Work laptop',
        country='USA',
        state='California',
        city='San Francisco',
        street='1600 Amphitheatre Pkwy, Mountain View',
        postcode='CA 94043',
    )

    example_advertisement_partial = render_to_string('partials/job_advertisement_details.html',
                                                     {'advertisement': example_advertisement})

    return JsonResponse({"advertisement": example_advertisement_partial})

class PreviewAdvertisement():
    """
    Represents a job advertisement in creation
    Hence none of the fields have to be filled
    """

    def __init__(self, job_title=None,
                 job_description=None, start_date=None,
                 salary_type=None, salary=None,
                 job_type=None, hours=None,
                 remote_work=None, website=None,
                 benefits=None, country=None,
                 state=None, city=None,
                 street=None, postcode=None):

        self.job_title = job_title
        self.job_description = job_description
        self.start_date = start_date
        self.salary_type = salary_type
        self.salary = salary
        self.job_type = job_type
        self.hours = hours

        if remote_work == 'true':
            self.remote_work = True
        elif remote_work == 'false':
            self.remote_work = False

        self.website = website

        if benefits == "" or benefits is None:
            self.benefits = None
        else:
            self.benefits = benefits.split(",")

        self.country = country
        self.state = state
        self.city = city
        self.street = street
        self.postcode = postcode
