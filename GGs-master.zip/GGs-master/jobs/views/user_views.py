"""Contains all views related to users in general"""

from jobs.helpers import save_bin, job_seeker_access, user_access
from django.contrib import messages
from django.http import HttpResponse
from django.contrib.auth import login
from django.shortcuts import render, redirect
from django.contrib.auth.hashers import check_password
from django.core.files.storage import FileSystemStorage

from jobs.forms.authentication_forms import PasswordForm
from jobs.forms.job_seeker_forms import JobSeekerProfileForm
from jobs.forms.employer_forms import EmployerProfileForm
from jobs.models.user_models import Employer, JobSeeker


@user_access
def profile(request):
    """The edit profile page of the website"""
    user = request.user
    user_data = {'first_name': user.first_name,
                 'last_name': user.last_name,
                 'email': user.email
                 }
    response_data = {"user_type": user.user_type}

    if user.user_type == 'employer':
        employer_details = Employer.objects.get(user=user)
        if request.method == 'POST':
            form = EmployerProfileForm(employer_details, request.POST)
            if form.is_valid():
                form.save()
                messages.add_message(request, messages.SUCCESS, "Profile updated!")
                return redirect('home')
        else:
            employer_data = user_data.copy()
            employer_data.update({'company': employer_details.company})
            form = EmployerProfileForm(employer_details, initial=employer_data)

    # If the user isn't an employer then they are a job seeker
    else:
        user_data['phone_number'] = user.phone_number
        job_seeker_details = JobSeeker.objects.get(user=user)
        if request.method == 'POST':
            form = JobSeekerProfileForm(job_seeker_details, request.POST, request.FILES)
            if form.is_valid():
                if 'file' in request.FILES.keys():
                    file = request.FILES['file']
                    fs = FileSystemStorage()
                    filename = fs.save(file.name, file)
                    uploaded_file_url = fs.url(filename)
                    save_bin(filename, JobSeeker.objects.get(user_id=request.user.id))
                form.save()
                messages.add_message(request, messages.SUCCESS, "Profile updated!")
                return redirect('home')
        else:
            job_seeker_data = user_data.copy()
            job_seeker_data.update({
                'bio': job_seeker_details.bio,
                'cv': job_seeker_details.cv
            })
            form = JobSeekerProfileForm(job_seeker_details, initial=job_seeker_data)

            response_data["cv"] = JobSeeker.objects.get(user_id=user.id).cv

    response_data["form"] = form

    return render(request, 'profile.html', response_data)


@user_access
def password(request):
    """The change password page of the website"""
    current_user = request.user
    if request.method == 'POST':
        form = PasswordForm(data=request.POST)
        if form.is_valid():
            password = form.cleaned_data.get('password')
            if check_password(password, current_user.password):
                new_password = form.cleaned_data.get('new_password')
                current_user.set_password(new_password)
                current_user.save()
                login(request, current_user)
                messages.add_message(request, messages.SUCCESS, "Password successfully updated!")
                return redirect('home')
    form = PasswordForm()
    return render(request, 'password.html', {'form': form})

@job_seeker_access
def view_pdf(request):
    current_user = JobSeeker.objects.get(user_id=request.user.id)
    if current_user.cv is not None:
        response = HttpResponse(current_user.cv, content_type='application/pdf')
        response['Content-Disposition'] = 'inline;filename=mypdf.pdf'
        return response
    else:
        return redirect("home")
