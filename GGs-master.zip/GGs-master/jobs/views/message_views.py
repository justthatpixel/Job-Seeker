"""Contains all views related to employers"""

from django.contrib import messages
from django.http import HttpResponse, JsonResponse
from django.shortcuts import render, redirect
from django.template.loader import render_to_string
from django.utils import timezone
from django.urls import reverse

from job_hiring.settings import MESSAGES_PER_PAGE
from jobs.forms.messaging_forms import GoToMessageChannelForm, SendMessageForm
from jobs.models import User, Message, MessageChannel, MessageNotification \
                        ,MessageChannelNotification
from jobs.helpers import is_ajax, user_access
from jobs.models import User, Message, MessageChannel, MessageNotification
from django.core.paginator import Paginator



@user_access
def message_home(request):
    """
    View which lets the user input another user to message
    USED FOR TESTING, NOT INTENDED TO BE IN FINAL BUILD
    """

    if request.method == 'POST':
        form = GoToMessageChannelForm(request.POST)
        if form.is_valid():
            sender = request.user
            receiver = request.POST.get('receiver')

            # If no user with input email exists
            if not User.objects.filter(email=receiver).exists():
                messages.add_message(request, messages.ERROR, "No user with that email exists")
                return render(request, 'user_messaging/message_home.html', {'form':form})

            # User that sender wants to start a channel with
            receiver = User.objects.get(email=receiver)


            # Checks if channel like one requested already exists and creates ones if it doesn't
            if MessageChannel.objects.filter(users=sender).filter(users=receiver).exists():
                messages.add_message(request, messages.ERROR, "You are already in a channel with this person")
                return render(request, 'user_messaging/message_home.html', {'form':form})
            else:
                channel = MessageChannel.objects.create()
                channel.users.add(sender)
                channel.users.add(receiver)

            return redirect('your_messages')

    form = GoToMessageChannelForm()
    return render(request, 'user_messaging/message_home.html', {'form': form})

@user_access
def start_channel(request, receiver_id):
    """
    Creates a message channel between two users and redirects them to their messages' page
    If a message channel already exists between them then redirects them to their messages page
    """
    # Person creating channel
    sender = request.user

    # User that sender wants to start a channel with
    receiver = User.objects.get(id=receiver_id)

    # Checks if channel like one requested already exists and creates ones if it doesn't
    if not MessageChannel.objects.filter(users=sender).filter(users=receiver).exists():
        channel = MessageChannel.objects.create()
        channel.users.add(sender)
        channel.users.add(receiver)

    else:
        # Otherwise, we take a channel with both users in and update its last updated field
        channel = MessageChannel.objects.filter(users=sender).filter(users=receiver).first()
        channel.last_updated = timezone.now()
        channel.save()

    return redirect('your_messages')


@user_access
def send_message(request):
    """
    View to send a message when requested
    Will be called by an ajax request and return a http response
    Retrieves form data from ajax request and uses it to create a new message instance
    """

    message_text = request.POST['message']
    sender_id = request.POST['sender']
    message_channel_id = request.POST['message_channel']

    # Single out channel id in string
    message_channel_id = message_channel_id.replace("\n", "").split("#")[0]
    message_channel = MessageChannel.objects.get(id=message_channel_id)

    sender = User.objects.get(id=sender_id)

    message = Message.objects.create(message_text=message_text,
                                     sender=sender,
                                     message_channel=message_channel,
                                     date=timezone.now())

    # Alert all users in channel about new message
    for user in message_channel.users.all():
        if user != sender:
            message_notification = MessageNotification.objects.create(
                user_to_notify=user,
                header=f"You have received a new message from {message.sender.first_name} {message.sender.last_name}",
                description=message.message_text,
                message=message,
                link=reverse('your_messages'),
            )

            # Create a notification saying the message channel has unread messages
            if not MessageChannelNotification.objects.filter(message_channel=message_channel).exists():
                message_channel_notification = MessageChannelNotification.objects.create(
                    user_to_notify=user,
                    header=f"You have unread messages from {message.sender.first_name} {message.sender.last_name}",
                    description=message.message_text,
                    message_channel=message_channel,
                    link=reverse('your_messages'),
                )
            else:
                # If such a notification exists then update it with the content of the most recent message sent
                channel_notification = MessageChannelNotification.objects.filter(message_channel=message_channel).first()
                channel_notification.description = message.message_text
                channel_notification.date = timezone.now()
                channel_notification.save()


    # Update the channel's 'last_updated' field
    message_channel.last_updated = timezone.now()
    message_channel.save()

    return HttpResponse("Message Sent!")

@user_access
def get_messages_in_channel(request):
    """
    Returns all the messages in a given message channel
    This view is intended to respond to an ajax request
    If you want to respond to a http request then extend this method or write another view
    """

    sender = request.user
    chosen_channel_id = request.GET.get('channel_id')
    if chosen_channel_id:

        # Extract only id from input text
        chosen_channel_id = chosen_channel_id.replace("\n", "").split('#')[0]

        if chosen_channel_id=='?':
            return HttpResponse("No messages to show")

        if MessageChannel.objects.filter(id=chosen_channel_id).exists():
            channel = MessageChannel.objects.get(id=chosen_channel_id)
        else:
            return HttpResponse("Could not resolve channel id!")

    else:
        # If we get no channel id attempt to show whatever their first channel is if it exists
        if MessageChannel.objects.filter(users=sender).exists():
            channel = MessageChannel.objects.filter(users=sender).first()
        else:
            return HttpResponse("No messages to show")

    messages_to_get = Message.objects.filter(message_channel=channel).order_by('date')

    message_channel_partial = render_to_string('partials/user_messaging/message_channel.html',
                                               {'user_messages': messages_to_get,
                                                'channel': channel,
                                                'sender':sender})

    # If no new messages then don't update the channel
    if request.GET.get('channel_id').count("user-message-listing")==message_channel_partial.count("user-message-listing"):
        return HttpResponse('dont update')

    return JsonResponse({"message_channel":message_channel_partial})


@user_access
def your_messages(request):
    """
    Shows the user all the message channels they are in
    Should sort them by channels with the most recent messages
    """

    user = request.user
    channels = MessageChannel.objects.filter(users=user).order_by('last_updated').reverse()

    paginator = Paginator(channels, MESSAGES_PER_PAGE)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)

    # Sort channels by most recent messages
    #channels.order_by('last_updated').reverse()

    chosen_channel_id = request.GET.get('channel_id')
    if chosen_channel_id:

        chosen_channel_id = chosen_channel_id.replace("\n", "").split()[0]
        chosen_channel = MessageChannel.objects.get(id=chosen_channel_id)

        if is_ajax(request):

            channel_messages = Message.objects.filter(message_channel=chosen_channel)
            chosen_channel_partial = render_to_string('partials/user_messaging/message_channel.html',
                                                      {'user_messages': channel_messages,
                                                       'channel':chosen_channel,
                                                       'sender':request.user})

            # Delete any notifications for user tied to this channel as they are about to see it
            MessageNotification.objects.filter(message__in=channel_messages, user_to_notify=user).delete()
            MessageChannelNotification.objects.filter(message_channel=chosen_channel, user_to_notify=user).delete()

            return JsonResponse({'chosen_channel': chosen_channel_partial},
                                status=200)

    else:
        chosen_channel = channels.first()

    form = SendMessageForm()
    messages_to_show = Message.objects.filter(message_channel=chosen_channel).order_by('date')

    return render(request, 'user_messaging/your_messages.html', {'chosen_channel':chosen_channel,
                                                                 'sender':request.user,
                                                                 'user_messages':messages_to_show,
                                                                 'form':form,
                                                                 'page_obj':page_obj,
                                                                 'channels':channels})

