from django.shortcuts import render
from django.contrib import messages
from django.core.paginator import Paginator
from django.template.loader import render_to_string
from django.http import JsonResponse

from jobs.helpers import login_prohibited, employer_access, job_seeker_access, is_ajax
from jobs.forms.job_seeker_forms import JobSeekerSearchPreferenceForm
from jobs.models import JobAdvertisement, JobSeeker, JobApplication, Employer
from job_hiring.settings import JOB_ADVERTISEMENTS_PER_PAGE



@login_prohibited
def home(request):
    """Display the home page of the sight for non logged in users"""
    return render(request, 'home_pages/home.html')


@job_seeker_access
def job_seeker_home(request):
    """Display the seeker search criteria form on the seeker home page"""
    user = request.user
    job_seeker_details = JobSeeker.objects.get(user=user)
    
    if request.method == 'POST':
        form = JobSeekerSearchPreferenceForm(request.POST, instance=job_seeker_details)
        if form.is_valid():
            form.save()
            messages.add_message(request, messages.SUCCESS, "Search criteria updated!")
            form = JobSeekerSearchPreferenceForm(instance=job_seeker_details)
    else:
        form = JobSeekerSearchPreferenceForm(instance=job_seeker_details)

    return render(request, 'home_pages/home_job_seeker.html', {'form': form})


@employer_access
def employer_home(request):
    """Get all job advertisements made by the employer"""
    # Get advertisements created by logged in user
    advertisements = JobAdvertisement.objects.filter(employer=Employer.objects.get(user_id=request.user.id)).order_by('id')

    paginator = Paginator(advertisements, JOB_ADVERTISEMENTS_PER_PAGE)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)

    job_count = advertisements.count()

    chosen_advertisement_id = request.GET.get('advertisement_id')
    if chosen_advertisement_id:
        try:
            chosen_advertisement_id = chosen_advertisement_id.replace("\n", "").split()[0]
            chosen_ad = JobAdvertisement.objects.get(id=chosen_advertisement_id)

            application_count = JobApplication.objects.filter(advertisement=chosen_ad).count()

        except:
            application_count = 0


        if is_ajax(request):
            chosen_ad_details_partial = render_to_string('partials/job_advertisement_details.html',
                                                         {'advertisement': chosen_ad,
                                                          'can_edit': True})
            return JsonResponse({'chosen_ad': chosen_ad_details_partial,
                                 'application_count': application_count}, status=200)

    else:
        if len(advertisements) > 0:
            top_ad = advertisements[0]
            chosen_ad_details_partial = render_to_string('partials/job_advertisement_details.html',
                                                         {'advertisement': top_ad,
                                                          'can_edit': True})
        else:
            chosen_ad_details_partial = None

    return render(request, 'home_pages/home_employer.html', {'chosen_ad': chosen_ad_details_partial,
                                                             'page_obj': page_obj,
                                                             'advertisements': advertisements,
                                                             'job_count': job_count })


