from django.core.management.base import BaseCommand
from django.db.utils import IntegrityError
from django.utils import timezone
from django.core.management import call_command
from django.test import TestCase
from django.conf import settings
from djmoney.money import Money, Currency
from django.urls import reverse

from faker import Faker
from faker.providers.geo import Provider as GeoProvider
import datetime
import requests
import random
import sys

from jobs.models import JobAdvertisement, JobApplication, JobSeeker, Employer, User, \
    JobAdvertisementReport, ReportGroup, MessageNotification, Message, MessageChannel \
    , MessageChannelNotification, JobApplicationStatusNotification, CurrencyRate
from jobs.enums import JOB_TYPES, JOB_TITLES_AND_DESCRIPTIONS, SALARY_TYPES2, JOB_TYPES2, \
    JOBSEEKER_MESSAGES, EMPLOYER_MESSAGES
from job_hiring.settings import GEOAPIFY_API_KEY
from jobs.locations import LOCATIONS
from job_hiring.settings import CURRENCIES


class Command(BaseCommand, TestCase):
    """
    Seeds the database
    Will generate a number of random entities for each model
    The number of each of these is specified in the project's settings file
    Will also generate additional non-random entities for each model
    These will have known data which can be used for testing
    To know what these are, check the code below or the README
    """

    # Password for seeded users
    PASSWORD = settings.DEFAULT_TESTING_PASSWORD
    ADMIN_PASSWORD = settings.DEFAULT_ADMIN_PASSWORD
    # Amount random entities of each model to generate
    RANDOM_JOB_SEEKER_COUNT = settings.RANDOM_JOB_SEEKER_COUNT
    RANDOM_EMPLOYER_COUNT = settings.RANDOM_EMPLOYER_COUNT
    RANDOM_JOB_ADVERTISEMENT_COUNT = settings.RANDOM_JOB_ADVERTISEMENT_COUNT
    RANDOM_JOB_APPLICATION_COUNT = settings.RANDOM_JOB_APPLICATION_COUNT
    DEFAULT_PHONE_NUMBER = "+1 604 401 1234"
    RANDOM_JOB_ADVERTISEMENT_REPORT_COUNT = settings.RANDOM_JOB_ADVERTISEMENT_REPORT_COUNT
    RANDOM_USER_MESSAGE_COUNT = settings.RANDOM_USER_MESSAGE_COUNT
    RANDOM_ADMIN_COUNT = settings.RANDOM_ADMIN_COUNT

    def __init__(self):
        super().__init__()
        self.faker = Faker('en_GB')

    def handle(self, *args, **options):
        call_command('unseed')

        self._seed_testing_users()
        self._seed_currency_rates()
        self._seed_admin()
        self._seed_job_seekers()
        self._seed_employers()
        self._seed_job_advertisements()
        self._seed_job_applications()
        self._seed_job_advertisement_reports()
        self._seed_user_messages()
        self._seed_message_notifications()
        self._seed_job_application_status_notifications()

    def _seed_testing_users(self):
        """Seed the default users for testing"""
        print("Seeding default users", end='\r')
        User.objects.create_superuser(first_name="Admin", last_name="System", email="noreply@jobs.admin.org",
                                    password=Command.ADMIN_PASSWORD)
        
        User.objects.create_superuser(first_name="Kelly", last_name="Brown", email="kelly.brown@example.org",
                                    password=Command.ADMIN_PASSWORD)
        
        User.objects.create_staff(first_name="Bobby", last_name="Flomp", email="bobby.flomp@example.org",
                                password=Command.ADMIN_PASSWORD)
        
        User.objects.create_staff(first_name="Tim", last_name="Turner", email="tim.turner@example.org",
                                password=Command.ADMIN_PASSWORD)
            

        self._create_job_seeker_with_params(firstname="John", lastname="Doe", email="john.doe@example.org",
                                            bio="Looking for work!", password=Command.PASSWORD)
        
        self._create_job_seeker_with_params(firstname="Jane", lastname="Doe", email="jane.doe@example.org",
                                            bio="Lead Hiring Executive of Java", password=Command.PASSWORD)
        

        self._create_employer_with_params(firstname="James", lastname="Jamison", email="james.jamison@example.org",
                                        company="Java Inc", password=Command.PASSWORD)
        
        self._create_employer_with_params(firstname="Josh", lastname="Jones", email="josh.jones@example.org",
                                        company="Blue J Corporation", password=Command.PASSWORD)
        print("Default user seeding complete")
        print("Seeded 8 default users")
    
    def _seed_currency_rates(self):
        """Seed all the currencies with initial exchange rates to the dollar"""
        if CurrencyRate.objects.count() >= len(CURRENCIES):
            return
        currency_count = 0
        while currency_count < len(CURRENCIES):
            print(f'Seeding currency {currency_count}', end='\r')
            url = f'https://api.exchangerate.host/convert?from={CURRENCIES[currency_count]}&to=USD'
            try:
                response = requests.get(url).json()
                CurrencyRate.objects.update_or_create(currency=CURRENCIES[currency_count], exchange_rate=response['result'])
            except:
                raise Exception("API not functional at the moment")
            currency_count += 1
        print("Currency seeding complete")
        print('Seeded ' + str(CurrencyRate.objects.count()) + ' currencies')
    
    def _seed_admin(self):
        """Seed a certain number of randomly generated admin"""
        admin_count = 0
        while admin_count < Command.RANDOM_ADMIN_COUNT:
            print(f'Seeding admin {admin_count}', end='\r')
            try:
                self._generate_admin()
            except (IntegrityError):
                continue
            admin_count += 1
        print('Admin seeding complete')
        print('Seeded ' + str(User.objects.filter(is_staff=True).count()-4) + ' admin')

    def _generate_admin(self):
        """Randomly generates an administrator"""
        first_name = self.faker.first_name()
        last_name = self.faker.last_name()
        email = self._get_email(first_name, last_name)

        User.objects.create_staff(first_name=first_name, last_name=last_name, email=email, password=Command.ADMIN_PASSWORD)

    def _seed_job_seekers(self):
        """Seed a certain number of randomly generated job seekers"""
        seeker_count = 0
        while seeker_count < Command.RANDOM_JOB_SEEKER_COUNT:
            print(f'Seeding job seeker {seeker_count}', end='\r')
            try:
                self._generate_job_seeker()
            except (IntegrityError):
                continue
            seeker_count += 1
        print('Job seeker seeding complete')
        print('Seeded ' + str(JobSeeker.objects.count()) + ' job seekers')

    def _create_job_seeker_with_params(self, firstname, lastname, email, bio, password):
        """Creates a job-seeker with passed in data"""
        created_job_seeker = JobSeeker.objects.create(
            bio=bio,
            user=User.objects.create(
                first_name=firstname,
                last_name=lastname,
                email=email,
                password=password,
                user_type='job_seeker',
                phone_number=self.DEFAULT_PHONE_NUMBER
            )
        )

    def _generate_job_seeker(self):
        """Generates a job-seeker with random data"""
        first_name = self.faker.first_name()
        last_name = self.faker.last_name()
        email = self._get_email(first_name, last_name)
        bio = self.faker.text()

        self._create_job_seeker_with_params(first_name, last_name, email, bio, Command.PASSWORD)

    def _seed_employers(self):
        """Seed a certain number of randomly generated employers"""
        employer_count = 0
        while employer_count < Command.RANDOM_EMPLOYER_COUNT:
            print(f'Seeding employer {employer_count}', end='\r')
            try:
                self._generate_employer()
            except (IntegrityError):
                continue
            employer_count += 1
        print('Employer seeding complete')
        print('Seeded ' + str(Employer.objects.count()) + ' employers')

    def _create_employer_with_params(self, firstname, lastname, email, company, password):
        """Creates an employer with passed in data"""
        created_employer = Employer.objects.create(
            company=company,
            user=User.objects.create(
                first_name=firstname,
                last_name=lastname,
                email=email,
                password=password,
                user_type='employer',
                phone_number=self.DEFAULT_PHONE_NUMBER
            )
        )

    def _create_staff_with_params(self, firstname, lastname, email, company, password):
        """Creates an employer with passed in data"""
        created_employer = Employer.objects.create(
            company=company,
            user=User.objects.create(
                first_name=firstname,
                last_name=lastname,
                email=email,
                password=password,
                user_type='employer'
            )
        )

    def _generate_employer(self):
        """Generates an employer with random data"""
        first_name = self.faker.first_name()
        last_name = self.faker.last_name()
        email = self._get_email(first_name, last_name)
        company = self.faker.company()

        self._create_employer_with_params(first_name, last_name, email, company, Command.PASSWORD)

    def _get_email(self, first_name, last_name):
        """Returns an example email for a person with a passed in first and last name"""
        return f'{first_name.lower()}.{last_name.lower()}@example.org'

    def _seed_job_advertisements(self):
        """Seeds job advertisements, employers must be seeded before calling this"""
        employer1 = Employer.objects.get(user_id=User.objects.get(email="james.jamison@example.org").id)
        employer2 = Employer.objects.get(user_id=User.objects.get(email="josh.jones@example.org").id)

        seven_days = datetime.timedelta(days=7)
        self._create_job_advertisement_with_params_with_location(employer1, "Java Developer",
                                                    "Develop complex software for our company using java",
                                                    timezone.now() + seven_days, "Yearly",
                                                    Money(80000, Currency("USD")),
                                                    "United Kingdom", "England", "London", "112 Barkshlow street",
                                                    "IG11 9UT", JOB_TYPES[1][0], 40, False,
                                                    "https://docs.oracle.com/en/java/")
        self._create_job_advertisement_with_params_with_location(employer1, "C++ Developer",
                                                    "Work in a team to develop/improve software requested by our clients",
                                                    timezone.now() + seven_days, "Yearly",
                                                    Money(60000, Currency("GBP")), "United Kingdom", "England",
                                                    "London", "10 Lynford gardens", "IG3 9LY",
                                                    JOB_TYPES[1][0], 45, False, "https://devdocs.io/cpp/")
        self._create_job_advertisement_with_params_with_location(employer2, "Scala Developer",
                                                    "Looking for an experienced scala developer to create software",
                                                    timezone.now() + seven_days, "Hourly", Money(13, Currency("GBP")),
                                                    "United Kingdom", "England", "London", "25 marmion avenue",
                                                    "E4 8EP",
                                                    JOB_TYPES[0][0], 35, False, "https://docs.scala-lang.org/")
        self._create_job_advertisement_with_params_with_location(employer2, "Scratch Developer",
                                                    "Looking for a an experienced software developer with at least 10 years of experience working with scratch",
                                                    timezone.now() + seven_days, "Hourly", Money(30, Currency("GBP")),
                                                    "United Kingdom", "England", "London", "22a Chingford Road",
                                                    "E17 4PG",
                                                    JOB_TYPES[1][0], 40, True, "https://scratch.mit.edu/developers")

        ad_count = 0
        while ad_count < Command.RANDOM_JOB_ADVERTISEMENT_COUNT:
            print(f'Seeding job advertisement {ad_count}', end='\r')
            try:
                self._generate_job_advertisement()
            except (IntegrityError):
                continue
            ad_count += 1
        print('Job advertisement seeding complete')
        print('Seeded ' + str(JobAdvertisement.objects.count()) + ' job advertisements')

    def _create_job_advertisement_with_params(self, employer, job_title, job_description, start_date, salary_type,
                                              salary,
                                              job_type, hours, remote_work, website):
        """Creates a job advertisement with passed in data"""
        created_advertisement = JobAdvertisement.objects.create(
            employer=employer,
            job_title=job_title,
            job_description=job_description,
            start_date=start_date,
            salary_type=salary_type,
            salary=salary,
            job_type=job_type,
            hours=hours,
            remote_work=remote_work,
            website=website,
        )

    def _create_job_advertisement_with_params_with_location(self, employer, job_title, job_description, start_date, salary_type,
                                               salary,
                                               country, state, city, street, postcode, job_type, hours, remote_work,
                                               website):
        """Creates a job advertisement with passed in data"""
        created_advertisement = JobAdvertisement.objects.create(
            employer=employer,
            job_title=job_title,
            job_description=job_description,
            start_date=start_date,
            salary_type=salary_type,
            salary=salary,
            country=country,
            state=state,
            city=city,
            street=street,
            postcode=postcode,
            job_type=job_type,
            hours=hours,
            remote_work=remote_work,
            website=website,
        )

    def _generate_job_advertisement(self):
        """Generates a job advertisement with random data"""
        location_details = random.choice(LOCATIONS)
        currency = location_details[7]
        job_title, job_description = random.choice(JOB_TITLES_AND_DESCRIPTIONS)
        employer = random.choice(Employer.objects.all())
        start_date = timezone.now() + datetime.timedelta(weeks=random.randrange(0, 50))
        salary_type = random.choice(SALARY_TYPES2)
        if salary_type == 'Hourly':
            amount = random.randrange(10, 50)
            salary = Money(amount, currency)
        elif salary_type == 'Monthly':
            amount = round(random.uniform(1800, 14500), -2)
            salary = Money(amount, currency)
        elif salary_type == 'Yearly':
            amount = round(random.uniform(18000, 150000), -2)
            salary = Money(amount, currency)
        country = location_details[0]
        state = location_details[1]
        city = location_details[2]
        street = location_details[3]
        postcode = location_details[4]
        job_type = random.choice(JOB_TYPES2)
        hours = random.randrange(20, 50, 5)
        remote_work = self.faker.boolean()
        website = self.faker.url()

        self._create_job_advertisement_with_params_with_location(employer, job_title, job_description, start_date, salary_type,
                                                    salary,
                                                    country, state, city, street, postcode, job_type, hours,
                                                    remote_work, website)

    def _seed_job_applications(self):
        """Seeds job applications, job seekers and job advertisements must be seeded before calling this"""
        john_doe_job_seeker = JobSeeker.objects.get(user_id=User.objects.get(email="john.doe@example.org").id)
        jane_doe_job_seeker = JobSeeker.objects.get(user_id=User.objects.get(email="jane.doe@example.org").id)

        java_developer_ad = JobAdvertisement.objects.get(job_title="Java Developer")
        c_plus_plus_developer_ad = JobAdvertisement.objects.get(job_title="C++ Developer")
        scala_developer_ad = JobAdvertisement.objects.get(job_title="Scala Developer")
        scratch_developer_ad = JobAdvertisement.objects.get(job_title="Scratch Developer")

        self._create_job_application_with_params(java_developer_ad, john_doe_job_seeker, timezone.now(), 'Accepted')
        self._create_job_application_with_params(c_plus_plus_developer_ad, john_doe_job_seeker, timezone.now())
        self._create_job_application_with_params(scala_developer_ad, john_doe_job_seeker, timezone.now(), 'Rejected')
        self._create_job_application_with_params(scratch_developer_ad, john_doe_job_seeker, timezone.now())
        self._create_job_application_with_params(java_developer_ad, jane_doe_job_seeker, timezone.now())
        self._create_job_application_with_params(scala_developer_ad, jane_doe_job_seeker, timezone.now())

        application_count = 0
        while application_count < Command.RANDOM_JOB_APPLICATION_COUNT:
            print(f'Seeding job application {application_count}', end='\r')
            try:
                self._generate_job_application()
            except (IntegrityError):
                continue
            application_count += 1
        print('Job application seeding complete')
        print('Seeded ' + str(JobApplication.objects.count()) + ' job applications')

    def _create_job_application_with_params(self, advertisement, job_seeker, application_date, status='Pending'):
        """Creates a job application with passed in data"""
        created_application = JobApplication.objects.create(
            advertisement=advertisement,
            job_seeker=job_seeker,
            application_date=application_date,
            status=status,
        )

    def _generate_job_application(self):
        """Generates a job application with random data"""
        advertisement = random.choice(JobAdvertisement.objects.all())
        job_seeker = random.choice(JobSeeker.objects.all())
        application_date = timezone.now() - datetime.timedelta(days=random.randrange(0, 20))
        status = random.choice(['Accepted','Rejected','Pending'])

        self._create_job_application_with_params(advertisement, job_seeker, application_date, status)

    def _seed_job_advertisement_reports(self):
        """
        Seeds job advertisement reports
        Job seekers and job advertisements must be seeded before calling this
        """
        john_doe_job_seeker = JobSeeker.objects.get(user_id=User.objects.get(email="john.doe@example.org").id)
        jane_doe_job_seeker = JobSeeker.objects.get(user_id=User.objects.get(email="jane.doe@example.org").id)

        # Creating report groupings corresponding earlier seeded job advertisements
        java_specialist_report_group = self._create_report_group_with_params(
            JobAdvertisement.objects.get(job_title="Java Developer"))
        c_enthusiast_report_group = self._create_report_group_with_params(
            JobAdvertisement.objects.get(job_title="C++ Developer"))
        scala_enjoyer_report_group = self._create_report_group_with_params(
            JobAdvertisement.objects.get(job_title="Scala Developer"))

        self._create_job_advertisement_report_with_params(reporter=john_doe_job_seeker, report_date=timezone.now(),
                                                          report_group=java_specialist_report_group,
                                                          report_text="It didn't seem genuine to me")
        self._create_job_advertisement_report_with_params(reporter=john_doe_job_seeker, report_date=timezone.now(),
                                                          report_group=java_specialist_report_group,
                                                          report_text="Looks suspicious")
        self._create_job_advertisement_report_with_params(reporter=jane_doe_job_seeker, report_date=timezone.now(),
                                                          report_group=c_enthusiast_report_group,
                                                          report_text="Looks too good to be true")
        self._create_job_advertisement_report_with_params(reporter=jane_doe_job_seeker, report_date=timezone.now(),
                                                          report_group=scala_enjoyer_report_group, report_text="")

        report_count = 0
        while report_count < Command.RANDOM_JOB_ADVERTISEMENT_REPORT_COUNT:
            print(f'Seeding job advertisement reports {report_count}', end='\r')
            try:
                self._generate_job_advertisement_report()
            except (IntegrityError):
                continue
            report_count += 1
        print('Job advertisement report seeding complete')
        print('Seeded ' + str(JobAdvertisementReport.objects.count()) + ' reports')

    def _create_job_advertisement_report_with_params(self, reporter, report_date, report_group, report_text=''):
        """Creates a job advertisement report with passed in data"""
        created_report = JobAdvertisementReport.objects.create(
            report_group=report_group,
            report_date=report_date,
            reporter=reporter,
            report_text=report_text,
        )
        created_report.save()
        return created_report

    def _generate_job_advertisement_report(self):
        """Generates a job advertisement report with random data"""
        reporter = random.choice(JobSeeker.objects.all())
        report_date = timezone.now() - datetime.timedelta(days=random.randrange(0, 20))
        report_group = self.get_random_report_group()
        report_text = self.faker.text()
        self._create_job_advertisement_report_with_params(reporter, report_date, report_group, report_text)

    def _create_report_group_with_params(self, advertisement):
        """Creates a report group with passed in data"""
        created_report_group = ReportGroup.objects.create(
            job_advertisement=advertisement,
        )
        created_report_group.save()
        return created_report_group

    def get_random_report_group(self):
        random_ad = random.choice(JobAdvertisement.objects.all())
        if ReportGroup.objects.filter(job_advertisement=random_ad).exists():
            return ReportGroup.objects.get(job_advertisement=random_ad)
        else:
            return self._create_report_group_with_params(random_ad)

    def _seed_user_messages(self):
        """
        Seeds user messages, some users (job seekers/employer, not admin) must be seeded before using this
        """
        john_doe_job_seeker = User.objects.get(email="john.doe@example.org")
        jane_doe_job_seeker = User.objects.get(email="jane.doe@example.org")

        james_jamison_employer = User.objects.get(email="james.jamison@example.org")
        josh_jones_employer = User.objects.get(email="josh.jones@example.org")

        # Instantiate all messages channels between our users
        john_doe_james_jamison_channel = self._create_message_channel(james_jamison_employer, john_doe_job_seeker)
        jane_doe_james_jamison_channel = self._create_message_channel(james_jamison_employer, jane_doe_job_seeker)
        john_doe_josh_jones_channel = self._create_message_channel(josh_jones_employer, john_doe_job_seeker)
        jane_doe_josh_jones_channel = self._create_message_channel(josh_jones_employer, jane_doe_job_seeker)

        # Seed some messages between our users
        self._create_user_message_with_params(
            message_text='Greetings John! I saw your application for our job posting and was looking to offer you an interview. Would you be free to come to the office tomorrow?',
            date=timezone.now() - timezone.timedelta(days=1),
            sender=james_jamison_employer, message_channel=john_doe_james_jamison_channel)
        self._create_user_message_with_params(
            message_text='Hi James, that\'s great news! Yes I would love to come by tomorrow. Would I need to bring anything?',
            date=timezone.now() - timezone.timedelta(hours=2),
            sender=john_doe_job_seeker, message_channel=john_doe_james_jamison_channel)
        self._create_user_message_with_params(message_text='Just yourself and your CV',
                                              date=timezone.now() - timezone.timedelta(minutes=30),
                                              sender=james_jamison_employer,
                                              message_channel=john_doe_james_jamison_channel)

        self._create_user_message_with_params(
            message_text='Hi John, Unfortunately we\'re not hiring for the position you\'ve applied for anymore. However, we do have multiple other positions we could offer you if you\'re interested?',
            date=timezone.now() - timezone.timedelta(days=5),
            sender=josh_jones_employer, message_channel=john_doe_josh_jones_channel)
        self._create_user_message_with_params(
            message_text='Hello Josh, unfortunately I\'ve accepted another position now. I appreciate the offer though',
            date=timezone.now() - timezone.timedelta(days=4, hours=3),
            sender=john_doe_job_seeker, message_channel=john_doe_josh_jones_channel)
        self._create_user_message_with_params(message_text='No worries John and all the best',
                                              date=timezone.now() - timezone.timedelta(days=2, minutes=20),
                                              sender=josh_jones_employer, message_channel=john_doe_josh_jones_channel)

        self._create_user_message_with_params(message_text='I\'m interested in your recent posting for a worker',
                                              date=timezone.now() - timezone.timedelta(days=3, minutes=55),
                                              sender=jane_doe_job_seeker,
                                              message_channel=jane_doe_james_jamison_channel)
        self._create_user_message_with_params(message_text='What qualifications do you have?',
                                              date=timezone.now() - timezone.timedelta(days=1, hours=8),
                                              sender=james_jamison_employer,
                                              message_channel=jane_doe_james_jamison_channel)
        self._create_user_message_with_params(message_text='2 years experience in Scala, 1 in Java and 5 in Scratch',
                                              date=timezone.now() - timezone.timedelta(minutes=20),
                                              sender=jane_doe_job_seeker,
                                              message_channel=jane_doe_james_jamison_channel)

        message_count = 0
        while message_count < Command.RANDOM_USER_MESSAGE_COUNT:
            print(f'Seeding messages between users {message_count}', end='\r')
            try:
                self._generate_user_message()
            except (IntegrityError):
                continue
            message_count += 1
        print('User messages seeding complete')
        print('Seeded ' + str(Message.objects.count()) + ' messages')

    def _create_user_message_with_params(self, message_text, date, sender, message_channel):
        """Creates a user message with passed in data"""
        if not message_channel.users.contains(sender):
            print('passed in user and channel dont match')
        created_message = Message.objects.create(
            message_text=message_text,
            date=date,
            sender=sender,
            message_channel=message_channel,
        )
        created_message.save()
        return created_message

    def _generate_user_message(self):
        """Generates a user message with random data"""
        message_text = self.faker.text(),
        date = timezone.now() - datetime.timedelta(days=random.randrange(0, 20))
        sender = random.choice(User.objects.filter(is_staff=False, is_superuser=False))
        message_channel = self._get_random_message_channel(sender)
        if sender.user_type == "employer":
            message_text = random.choice(EMPLOYER_MESSAGES)
        if sender.user_type == "job_seeker":
            message_text = random.choice(JOBSEEKER_MESSAGES)
        self._create_user_message_with_params(message_text, date, sender, message_channel)

    def _create_message_channel(self, *users):
        """Creates a message channel"""
        # All message channels initialised so that they were last updated 20 days before seeding
        created_message_channel = MessageChannel.objects.create(
            last_updated=timezone.now() - timezone.timedelta(days=20)
        )
        for user in users:
            created_message_channel.users.add(user)

        created_message_channel.save()
        return created_message_channel

    def _get_random_message_channel(self, sender):
        random_user_to_message = random.choice(User.objects.filter(is_staff=False, is_superuser=False))
        while sender.email == random_user_to_message.email:
            random_user_to_message = random.choice(User.objects.filter(is_staff=False, is_superuser=False))

        if MessageChannel.objects.filter(users=random_user_to_message).filter(users=sender).exists():
            return MessageChannel.objects.filter(users=sender).get(users=random_user_to_message)
        else:
            return self._create_message_channel(random_user_to_message, sender)

    def _seed_message_notifications(self):
        """
        Seeds message notifications, some users (job seekers/employer, not admin) and messages must be seeded before using this
        Note that the number of message notifications generated will be the total number of messages at most
        """

        print('Now seeding notifications for your seeded messages and message channels...')

        for channel in MessageChannel.objects.all():
            most_recent_message_to_channel = Message.objects.filter(message_channel=channel).order_by(
                'date').last()
            if most_recent_message_to_channel:
                users_in_channel_receiving_message = channel.users.exclude(id=most_recent_message_to_channel.sender.id)

                # Should only be a single user most of the time, for loop is to catch any outliers
                for user in users_in_channel_receiving_message:
                    self._create_message_channel_notification_with_params(
                        user_to_notify=user,
                        header=f'You have unread messages from {most_recent_message_to_channel.sender.first_name} {most_recent_message_to_channel.sender.last_name}',
                        description=most_recent_message_to_channel.message_text,
                        link=reverse('your_messages'),
                        message_channel=channel,
                    )

                    self._create_message_notification_with_params(
                        user_to_notify=user,
                        header=f'You received a message from {most_recent_message_to_channel.sender.first_name} {most_recent_message_to_channel.sender.last_name}',
                        description=most_recent_message_to_channel.message_text,
                        link=reverse('your_messages'),
                        message=most_recent_message_to_channel,
                    )

        print('Seeded ' + str(MessageNotification.objects.count()) + ' message notifications')
        print('Seeded ' + str(MessageChannelNotification.objects.count()) + ' message channel notifications')

    def _create_message_notification_with_params(self, user_to_notify, header, description,
                                                 link, message):
        """Creates a message notification with passed in data"""
        # if a notification already exists for that message then we don't want to generate another one
        if MessageNotification.objects.filter(message=message).exists():
            pass
        else:
            created_notification = MessageNotification.objects.create(
                user_to_notify=user_to_notify,
                header=header,
                description=description,
                link=link,
                message=message,
            )
            created_notification.save()
            return created_notification

    def _create_message_channel_notification_with_params(self, user_to_notify, header, description,
                                                         link, message_channel):
        """Creates a message channel notification with passed in data"""
        # if a notification already exists for that message channel then we don't want to generate another one
        if MessageChannelNotification.objects.filter(message_channel=message_channel).exists():
            pass
        else:
            created_notification = MessageChannelNotification.objects.create(
                user_to_notify=user_to_notify,
                header=header,
                description=description,
                link=link,
                message_channel=message_channel,
            )
            created_notification.save()
            return created_notification

    def _seed_job_application_status_notifications(self):
        """
        Seeds job applicaton status notifications, some users (job seekers/employer, not admin) and job applications
            must be seeded before using this
        We will generate a notification for any application that has been marked as rejected or accepted
        """

        print('Now seeding job application status notifications for your seeded job applications...')

        for application in JobApplication.objects.all():
            if application.status == 'Accepted' or application.status == 'Rejected':
                self._create_job_application_status_notification_with_params(
                    user_to_notify=application.job_seeker.user,
                    header=f" One of your applications has changed status: {application.advertisement.job_title}",
                    description=f"{application.advertisement.job_title} : {application.status}",
                    link=reverse('job_seeker_applications'),
                    application=application,
                )

        print('Seeded ' + str(JobApplicationStatusNotification.objects.count()) + ' status notifications')

    def _create_job_application_status_notification_with_params(self, user_to_notify, header, description,
                                                            link, application):
        """Creates a message channel notification with passed in data"""
        # if a notification already exists for that message channel then we don't want to generate another one
        if not JobApplicationStatusNotification.objects.filter(application=application).exists():
            created_notification = JobApplicationStatusNotification.objects.create(
                user_to_notify=user_to_notify,
                header=header,
                description=description,
                link=link,
                application=application,
            )
            created_notification.save()
            return created_notification


###########################
# DO NOT INVOKE THIS METHOD
###########################
def generate_locations():
    """
    Generate the job advertisement locations in an external list located in the locations module.
    Use this method sparingly as it makes requests to an api.
    """
    fake = Faker()
    fake.add_provider(GeoProvider)
    Faker.seed(0)
    locations = []
    for _ in range(100):
        loc = fake.location_on_land()
        lat = loc[0]
        lon = loc[1]
        response = requests.get(
            f"https://api.geoapify.com/v1/geocode/reverse?lat={lat}&lon={lon}&format=json&apiKey={GEOAPIFY_API_KEY}")
        result = response.json()['results'][0]
        try:
            locations.append((result['country'], result['state'], result['city'], result['street'], result['postcode'],
                              result['lat'], result['lon']))
        except:
            pass
    file = open(sys.path[0] + '/jobs/locations.py', 'w')
    file.write("LOCATIONS = [\n")
    # If this method is used again then it should be edited here to remove locations with currencies
    # that are not in the CURRENCIES list
    for loc in locations:
        file.write("    (")
        for detail in loc:
            file.write("'" + str(detail) + "',")
        file.write("),\n")
    file.write("]")
    file.close()
    return locations

###########################
# DO NOT INVOKE THIS METHOD
###########################
def trimmed_currencies():
    """Generate a list of the currencies that are available in both the api and the django money field."""
    trimmed = []
    url = 'https://api.exchangerate.host/symbols'
    response = requests.get(url).json()
    currencies = response['symbols'].keys()
    for c in currencies:
        for r in CURRENCIES:
            if c == r:
                trimmed.append(c)
                break
    return trimmed

###########################
# DO NOT INVOKE THIS METHOD
###########################
def trimmed_locations():
    """Trim locations with currencies not inside the CURRENCIES list"""
    trimmed = []
    for location in LOCATIONS:
        for c in CURRENCIES:
            if location[7] == c:
                trimmed.append(location)
                break
    file = open(sys.path[0]+'/jobs/locations2.py', 'w')
    file.write("LOCATIONS = [\n")
    for loc in trimmed:
        file.write("    (")
        for detail in loc:
            file.write("'"+str(detail)+"',")
        file.write("),\n")
    file.write("]")
    file.close()
    return trimmed
