from django.core.management.base import BaseCommand

from jobs.models.user_models import User
from jobs.models import Message, MessageChannel, MessageNotification, JobAdvertisementReport, ReportGroup

class Command(BaseCommand):
    """
    Unseed the database
    All models except for CurrencyRate have their data wiped
    If you want to delete the data of CurrencyRate you have to do that manually in code
    """

    def handle(self, *args, **options):

        """Can uncomment the line below, this is a choice (a matter of preference)"""
        #User.objects.filter(is_staff=False, is_superuser=False).delete()

        User.objects.all().delete()
        MessageChannel.objects.all().delete()
        Message.objects.all().delete()
        MessageNotification.objects.all().delete()
        JobAdvertisementReport.objects.all().delete()
        ReportGroup.objects.all().delete()

