from django.db import models

from jobs.models import JobSeeker, JobAdvertisement


class ReportGroup(models.Model):
    """
    Models a grouping of reports for an individual job advertisement
    There will be a maximum of one of these per job advertisement
    """
    # These fields are only relevant to adminsite, please ignore them
    # Their values are automatically assigned when you save an instance of this model
    ad_employer_first_name = models.CharField(verbose_name='Creator first name', max_length=100, blank=False, null=True)
    ad_employer_last_name = models.CharField(verbose_name='Creator surname', max_length=100, blank=False, null=True)
    ad_employer_email = models.CharField(verbose_name='Creator email', max_length=100, blank=False, null=True)            
    ad_company = models.CharField(verbose_name='Company', max_length=100, blank=False, null=True)
    ad_id = models.IntegerField(verbose_name='Advert id', blank=False, null=True)
    count = models.IntegerField(verbose_name='Report count', blank=False, null=False, default=0)

    job_advertisement = models.OneToOneField(
        JobAdvertisement,
        on_delete=models.CASCADE,
        blank=False,
        unique=True,
    )

    class Meta:
        verbose_name_plural = "Advert reports"
        verbose_name = "reports for this advert"

    @property
    def reports(self):
        """Returns all the reports belonging to this report group"""
        return JobAdvertisementReport.objects.filter(report_group=self)

    @property
    def reports_count(self):
        """Returns the number of reports in this report group"""
        return JobAdvertisementReport.objects.filter(report_group=self).count()
    
    def save(self, *args, **kwargs):
        """Save additional information relevant to the report group model"""
        if self.job_advertisement:
            self.ad_employer_first_name = self.job_advertisement.employer.user.first_name
            self.ad_employer_last_name = self.job_advertisement.employer.user.last_name
            self.ad_employer_email = self.job_advertisement.employer.user.email
            self.ad_company = self.job_advertisement.employer.company
            self.ad_id = self.job_advertisement.id
            # I was getting a type using self.report_count() so I did the count manually instead
            self.count = JobAdvertisementReport.objects.filter(report_group=self).count()
        else:
            self.count = 0
        super().save(*args, **kwargs)

    def __str__(self):
        return f"Advert {self.ad_id}"

class JobAdvertisementReport(models.Model):
    """
    Models a report for a job advertisement
    Ie when a job seeker reports a job advertisement, it will generate a report like this
    """

    report_group = models.ForeignKey(
        ReportGroup,
        on_delete=models.CASCADE,
        blank=False,
    )

    # Date when report was generated
    report_date = models.DateTimeField(
        blank=False
    )

    # Job seeker who made the report
    reporter = models.ForeignKey(
        JobSeeker,
        on_delete=models.CASCADE,
        blank=False,
    )

    # This field is only relevant to the adminsite, please ignore it
    # It's value is automatically assigned when you save an instance of this model
    reporter_email = models.CharField(blank=False, null=True, max_length=100)

    # Reason reported, can be blank
    report_text = models.CharField(
        blank=True,
        max_length=200,
        default=None,
        null=True,
    )

    def save(self, *args, **kwargs):
        """Save additional information relevant to the advertisement report model"""
        if self.reporter:
            self.reporter_email = self.reporter.user.email
        if self.report_group:
            self.report_group.save()
        super().save(*args, **kwargs)
    
    def __str__(self):
        return f"{self.id}"






