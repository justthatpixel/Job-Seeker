from django.db import models


class LocationMixin(models.Model):
    """Models location fields that may be of use"""
    country = models.CharField(default=None, max_length=100, blank=True, null=True, help_text="To ignore location filtering don't input details in any of the location text boxes.")
    state = models.CharField(default=None, max_length=100, blank=True, null=True)
    city = models.CharField(default=None, max_length=100, blank=True, null=True)
    street = models.CharField(default=None, max_length=100, blank=True, null=True)
    postcode = models.CharField(default=None, max_length=100, blank=True, null=True)
    latitude = models.DecimalField(decimal_places=6, max_digits=9, blank=True, null=True)
    longitude = models.DecimalField(decimal_places=6, max_digits=9, blank=True, null=True)
    
    class Meta:
        abstract = True


class ExchangeRateMixin(models.Model):
    """Models the exchange rate a currency to USD"""
    exchange_rate = models.DecimalField(max_digits=13, decimal_places=6, null=True)

    class Meta:
        abstract = True