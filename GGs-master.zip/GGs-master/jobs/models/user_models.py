from django.db import models
from django.contrib.auth.models import AbstractUser, BaseUserManager
from phonenumber_field.modelfields import PhoneNumberField
from djmoney.models.fields import MoneyField
from libgravatar import Gravatar
from djmoney.models.validators import MinMoneyValidator
from django.core.validators import MinValueValidator

from jobs.enums import *
from jobs.models.model_mixins import LocationMixin, ExchangeRateMixin
from jobs.models.currency_model import CurrencyRate


class UserManager(BaseUserManager):
    """
    All overriden methods except 'create' require user_type='default'.
    Use the 'create' method for making employers and job seekers.
    Use the remaining overriden methods for creating users with different maintenance roles.
    """

    use_in_migrations = True

    def _create_user(self, email, password, **extra_fields):
        """
        Create and save a user with the given email,
        and password.
        """
        if not email:
            raise ValueError('The email cannot be empty')

        email = self.normalize_email(email)
        user = self.model(email=email, **extra_fields)
        user.set_password(password)
        user.save(using=self._db)
        return user

    def create_user(self, email, password, **extra_fields):
        """Create and save a job-seeker"""

        extra_fields.setdefault('is_staff', False)
        extra_fields.setdefault('is_superuser', False)
        extra_fields.setdefault('user_type', 'default')
        extra_fields.setdefault('is_director', False)

        if extra_fields.get('is_staff') is True:
            raise ValueError('Default user must have is_staff=False')
        if extra_fields.get('is_superuser') is True:
            raise ValueError('Default user must have is_superuser=False')
        if extra_fields.get('user_type') != 'default':
            raise ValueError("Default user must have user_type='default'")
        if extra_fields.get('is_director') is not False:
            raise ValueError("Default user must have is_director=False")

        return self._create_user(email, password, **extra_fields)

    def create_staff(self, email, password, **extra_fields):
        """Create and save an administrator"""

        extra_fields.setdefault('is_staff', True)
        extra_fields.setdefault('is_superuser', True)
        extra_fields.setdefault('user_type', 'default')
        extra_fields.setdefault('is_director', False)

        if extra_fields.get('is_staff') is not True:
            raise ValueError('Administrator must have is_staff=True')
        if extra_fields.get('is_superuser') is not True:
            raise ValueError('Administrator must have is_superuser=True')
        if extra_fields.get('user_type') != 'default':
            raise ValueError("Administrator must have user_type='default'")
        if extra_fields.get('is_director') is not False:
            raise ValueError("Administrator must have is_director=False")

        return self._create_user(email, password, **extra_fields)

    def create_superuser(self, email, password, **extra_fields):
        """Create and save a superuser"""

        extra_fields.setdefault('is_staff', True)
        extra_fields.setdefault('is_superuser', True)
        extra_fields.setdefault('user_type', 'default')
        extra_fields.setdefault('is_director', True)

        if extra_fields.get('is_staff') is not True:
            raise ValueError('Superuser must have is_staff=True')
        if extra_fields.get('is_superuser') is not True:
            raise ValueError('Superuser must have is_superuser=True')
        if extra_fields.get('user_type') != 'default':
            raise ValueError("Superuser must have user_type='default'")
        if extra_fields.get('is_director') is not True:
            raise ValueError("Superuser must have is_director=True")

        return self._create_user(email, password, **extra_fields)

    def create(self, email, password, **extra_fields):
        """Create and save a user"""

        extra_fields.setdefault('is_staff', False)
        extra_fields.setdefault('is_superuser', False)
        extra_fields.setdefault('user_type', 'default')
        extra_fields.setdefault('is_director', False)

        return self._create_user(email, password, **extra_fields)


class User(AbstractUser):
    """
    Define the user model
    User creation example:
    User.objects.create(email='john@gmail.com', password='Password123', user_type='default')

    If a field is changed within this model then its corresponding field may need to be changed within the SignUpForm
    """
    username = None
    first_name = models.CharField(max_length=50, blank=False)
    last_name = models.CharField(max_length=50, blank=False)
    email = models.EmailField(unique=True, blank=False)
    phone_number = PhoneNumberField(null=False, blank=False, unique=False)

    DEFAULT = 'default'
    EMPLOYER = 'employer'
    JOBSEEKER = 'job_seeker'
    CHOICES = [(DEFAULT, 'Default'), (EMPLOYER, 'Employer'), (JOBSEEKER, 'Job Seeker')]
    user_type = models.CharField('Group', max_length=10, choices=CHOICES, null=True, blank=False)

    # This field distinguishes superusers from admin, can't use is_superuser anymore since admin are 'superusers'
    # for the sake of permissions
    is_director = models.BooleanField('director status')

    # Username is a required field in AbstractUser but email is used instead of username to login
    USERNAME_FIELD = 'email'
    REQUIRED_FIELDS = []

    objects = UserManager()

    def save(self, *args, **kwargs):
        if self.is_director is None:
            self.is_director = False
        # All staff (admin or directors) are superusers because of the permission perks
        self.is_superuser = self.is_staff

        if self.first_name != None:
            self.first_name = self.first_name.lower().capitalize()
        if self.last_name != None:
            self.last_name = self.last_name.lower().capitalize()

        super().save(*args, **kwargs)

    def gravatar(self, size=40):
        """Return URL to the user's gravatar"""
        gravatar_object = Gravatar(self.email)
        gravatar_url = gravatar_object.get_image(size=size, default='mp')
        return gravatar_url

    def mini_gravatar(self):
        """Return URL to a smaller version of the user's gravatar"""
        return self.gravatar(size=25)
    
    def large_gravatar(self):
        """Return URL to a smaller version of the user's gravatar"""
        return self.gravatar(size=120)
    

class Employer(models.Model):
    """
    Define the employer profile model
    Employer creation example:
    Employer.objects.create(company='Google', user=User.objects.create(email='john@gmail.com', password='Password123', user_type='default'))

    If a field is changed within this model then its corresponding field may need to be changed in the EmployerSignUpForm
    """
    user = models.OneToOneField(User, on_delete=models.CASCADE, default=None)
    company = models.CharField(max_length=50, blank=False)

    def __str__(self):
        return 'details'


class JobSeeker(LocationMixin, ExchangeRateMixin):
    """
    Define the job-seeker profile model
    Job-seeker creation example:
    JobSeeker.objects.create(bio='This is my bio', user=User.objects.create(email='john@gmail.com', password='Password123', user_type='default'))

    If a field is changed within this model then its corresponding field may need to be changed in the JobSeekerSignUpForm
    """
    user = models.OneToOneField(User, on_delete=models.CASCADE, default=None)
    bio = models.TextField(null=True, blank=True)
    cv = models.BinaryField(null=True, blank=True)

    """User Profile Variables"""
    hours = models.IntegerField('Maximum weekly hours', default=None, blank=True, null=True, validators=[MinValueValidator(0)])
    type = models.CharField('Employment type',default=None, max_length=100, choices=JOB_TYPES, blank=True, null=True)
    job_title = models.CharField(default=None, max_length=100, choices=JOB_TITLES, blank=True, null=True)
    remote = models.BooleanField('Remote work', blank=True, null=True)
    min_salary = MoneyField(
        'Minimum yearly salary', max_digits=15, decimal_places=2, default_currency='GBP',
        blank = True, null=True, validators=[MinMoneyValidator(0)]
    )

    class Meta:
        abstract = False

    def __str__(self):
        return 'details'
    
    def save(self, *args, **kwargs):
        """Save additional information relevant to the job seeker model"""
        if self.min_salary != None:
            self.exchange_rate = CurrencyRate.objects.get(currency=self.min_salary.currency).exchange_rate

        super().save(*args, **kwargs)
