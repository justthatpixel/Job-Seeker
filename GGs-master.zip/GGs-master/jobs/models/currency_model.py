from django.db import models

from jobs.models.model_mixins import ExchangeRateMixin

class CurrencyRate(ExchangeRateMixin):
    """Models the exchange rates of currencies to the dollar"""

    currency = models.CharField(max_length=3, unique=True)

    class Meta:
        abstract = False