"""
More specialised notification models that might have something attached to them
Ie a MessageNotification has a message attached
"""

from django.db import models

from jobs.models import Message, JobApplication, MessageChannel
from jobs.models.notifications.base_notification_model import Notification


class MessageNotification(Notification):
    """Notification which alerts the user they have an unread message"""

    # New message user is being notified about
    message = models.ForeignKey(
        Message,
        on_delete=models.CASCADE,
        blank=False,
    )

    @property
    def message_channel(self):
        """Returns the MessageChannel notified message belongs to"""
        return self.message.message_channel


class MessageChannelNotification(Notification):
    """Notification which alerts the user they have an unread messages in a message channel"""

    # Message channel which has unread messages
    message_channel = models.ForeignKey(
        MessageChannel,
        on_delete=models.CASCADE,
        blank=False,
    )


class JobApplicationStatusNotification(Notification):
    """Notification which alerts the user if the status of one of their applications has change"""

    # Application which had its status changed
    application = models.ForeignKey(
        JobApplication,
        on_delete=models.CASCADE,
        blank=False,
    )








