"""
Base notification model which encapsulates the basic functionality needed by any notification
Hence all notifications will inherit from this in some way
However, this class is not abstract, you can make a basic notification
"""

from django.db import models
from django.utils import timezone

from jobs.models.user_models import User

class Notification(models.Model):
    """Basic notification model, can be extended to support more specific notifications"""

    # User getting notification
    user_to_notify = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        blank=False,
    )

    # Header of notification to give user idea of what notification is about
    header = models.CharField(
        max_length=100,
        blank=False,
    )

    # Text informing user what notification is about
    description = models.CharField(
        max_length=200,
        blank=True,
    )

    # Date when notification created
    date = models.DateTimeField(
        blank=False,
        null=False,
        default=timezone.now,
    )

    # Link we redirect to when user wants to see what notification is referring to
    link = models.URLField(
        null=True,
        blank=True,
        default=None,
    )










