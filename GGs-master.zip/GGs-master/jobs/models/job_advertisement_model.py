from django.db import models
from django.core.validators import RegexValidator
from djmoney.models.fields import MoneyField

from jobs.models.user_models import Employer
from jobs.models.currency_model import CurrencyRate
from jobs.enums import *
from jobs.models.model_mixins import LocationMixin, ExchangeRateMixin
from jobs.models.notifications.base_notification_model import Notification
from djmoney.models.validators import MinMoneyValidator
from django.core.validators import MinValueValidator


class JobAdvertisement(LocationMixin, ExchangeRateMixin):
    """Models a job advertisement"""

    employer = models.ForeignKey(
        Employer,
        on_delete=models.CASCADE,
        blank=False,
    )

    job_title = models.CharField(
        blank = False,
        max_length = 100,
        null=True,
        unique=False,
    )

    job_description = models.CharField(
        blank = False,
        max_length = 200,
        null=True,
        unique=False,
    )

    start_date = models.DateTimeField(
        blank=False,
        null=True
    )

    salary_type = models.CharField(
        "Salary period",
        blank=False,
        choices= SALARY_TYPES,
        max_length=30,
        default="Hourly",
        null=False,
    )

    salary = MoneyField(
        max_digits=15, decimal_places=2, default_currency='EUR', default=0,
        blank = False,
        null=False,
        validators=[MinMoneyValidator(0)]
    )

    # Choice field to choose if the work is part-time or full time
    job_type = models.CharField(
        blank=True,
        choices= JOB_TYPES,
        max_length=30,
        default=None,
        null=True,
    )
    # Defines weekly working hours
    hours = models.IntegerField(
        blank=False,
        null=True,
        validators=[MinValueValidator(0)]
    )

    # Ie are they working remotely or in person
    remote_work = models.BooleanField(
        blank=False,
        null=True
    )

    website = models.URLField(
        blank=False,
        null=True
    )

    benefits = models.JSONField(
        blank=True,
        default=None,
        null=True,
        validators=[RegexValidator(
            regex=r'^(\w+ ?)*(, ?(\w+ ?)+)*$',
            message='Separate your benefits with commas, with at most a single space between them'
                   ' Ie "good salary, company pension, free food" '
        )]
    )

    # These fields are only relevant to the adminsite, please ignore them
    # Their values are automatically assigned when you save an instance of this model
    employer_first_name = models.CharField(verbose_name='Creator first name', max_length=100, blank=False, null=True)
    employer_last_name = models.CharField(verbose_name='Creator surname', max_length=100, blank=False, null=True)
    employer_email = models.CharField(verbose_name='Creator email', max_length=100, blank=False, null=True)
    employer_company = models.CharField(verbose_name='Company', max_length=100, blank=False, null=True)

    class Meta:
        abstract = False

    def save(self, *args, **kwargs):
        """Save additional information relevant to the job advertisement model"""
        if self.employer:
            self.employer_first_name = self.employer.user.first_name
            self.employer_last_name = self.employer.user.last_name
            self.employer_email = self.employer.user.email
            self.employer_company = self.employer.company

        if self.salary != None:
            self.exchange_rate = CurrencyRate.objects.get(currency=self.salary.currency).exchange_rate

        super().save(*args, **kwargs)

    def __str__(self):
        return f"Advert {self.id}"
    
    def generate_notification(self, is_expired):
        """Create a relevant notification tailored to the employer advert event"""
        if is_expired:
            msg_hdr = f"Your advert for {self.job_title} has expired and been removed!"
            msg_txt = f"Your {self.job_title} advert with id {self.id} has been deleted due to its start date expiring."
        else:
            msg_hdr = f"Your advert for {self.job_title} was deleted by an admin!"
            msg_txt = f"Admin have deleted your {self.job_title} advert with id {self.id}."

        Notification.objects.create(
            user_to_notify=self.employer.user,
            header=msg_hdr,
            description=msg_txt,
        )

    def delete(self, *args, is_admin=True, is_expired=False, **kwargs):
        """
        When invoking this method pass 'is_admin=False' as a keyword arguement
        Example: JobAdvertisement.objects.get(id=2).delete(is_admin=False)
        """
        if is_admin:
            if self.employer != None:
                self.generate_notification(is_expired)

        super().delete(*args, **kwargs)
            


