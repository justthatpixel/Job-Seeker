from django.db import models
from django.utils import timezone
from jobs.models.user_models import User


class MessageChannel(models.Model):
    """A channel which users can send messages to"""

    # All users in the channel
    # Usually will be between two users but more can be added
    users = models.ManyToManyField(User)

    # datetime of when last message was sent to channel
    last_updated = models.DateTimeField(
        blank=False,
        default=timezone.now,
    )

    @property
    def preview_message(self):
        """
        Return the text and sender name of the most recent messages sent to this channel
        If no messages have been sent to this channel then return the empty string
        """
        if Message.objects.filter(message_channel=self).exists():
            message_to_preview = Message.objects.filter(message_channel=self).last()
            return f'{message_to_preview.sender.first_name} {message_to_preview.sender.last_name} - {message_to_preview.message_text}'
        else:
            return ''

    @property
    def users_in_channel(self):
        """Returns all the users in this channel as a list"""
        return self.users.all()


class Message(models.Model):
    """Model that represents a user message"""

    message_text = models.CharField(
        max_length=500,
        blank=False,
    )

    date = models.DateTimeField(
        blank=False,
    )

    sender = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        blank=False,
    )

    message_channel = models.ForeignKey(
        MessageChannel,
        on_delete=models.CASCADE,
        blank=False,
    )




