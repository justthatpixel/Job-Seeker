from django.db import models

from jobs.models.user_models import JobSeeker
from jobs.models.job_advertisement_model import JobAdvertisement

class JobApplication(models.Model):
    """Models a job application by a job seeker"""

    # Advertisement/posting being applied to
    advertisement = models.ForeignKey(
        JobAdvertisement,
        on_delete=models.CASCADE,
        blank=False,
    )

    # Applicant
    job_seeker = models.ForeignKey(
        JobSeeker,
        on_delete=models.CASCADE,
        blank=False,
    )

    application_date = models.DateTimeField(
        blank=False
    )

    status = models.CharField(
        default="Pending",
        blank=False,
        max_length=50
    )



