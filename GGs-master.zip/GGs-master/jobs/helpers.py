from django.shortcuts import redirect

from job_hiring.settings import BASE_DIR
from jobs.models import JobApplication, ReportGroup, JobAdvertisementReport, CurrencyRate

import os
import requests


def login_prohibited(function):
    """Wrapper to prevent any logged in users from accessing this page"""
    def wrap(request, *args, **kwargs):
        if request.user.is_authenticated:
            """After log in the user is redirected to their respective parts of the website"""
            if request.user.user_type == 'job_seeker':
                return redirect('job_seeker_home')
            elif request.user.user_type == 'employer':
                return redirect('employer_home')
            else:
                return redirect('admin:index')
        else:
            return function(request, *args, **kwargs)

    wrap.__doc__ = function.__doc__
    wrap.__name__ = function.__name__
    return wrap


def user_access(function):
    """
    Wrapper to allow all types of logged-in users to access a view
    Will prevent users not logged in from accessing page
    """
    def wrap(request, *args, **kwargs):
        if request.user.is_authenticated:
            return function(request, *args, **kwargs)
        return redirect('home')

    return wrap


def job_seeker_access(function):
    """Wrapper to allow only job seeker users to access view"""
    def wrap(request, *args, **kwargs):
        if request.user.is_authenticated:
            if request.user.user_type == 'job_seeker':
                return function(request, *args, **kwargs)
        return redirect('home')

    return wrap


def employer_access(function):
    """Wrapper to allow only employer users to access view"""
    def wrap(request, *args, **kwargs):
        if request.user.is_authenticated:
            if request.user.user_type == 'employer':
                return function(request, *args, **kwargs)
        return redirect('home')

    return wrap


def difference(string1, string2):
    # Split both strings into list items
    string1 = string1.split()
    string2 = string2.split()

    A = set(string1)  # Store all string1 list items in set A
    B = set(string2)  # Store all string2 list items in set B

    str_diff = A.symmetric_difference(B)
    isEmpty = (len(str_diff) == 0)

    if isEmpty:
        print("No Difference. Both Strings Are Same")
    else:
        print("The Difference Between Two Strings: ")
        print(str_diff)

    print('The programs runs successfully.')


def save_bin(filename, user):
    """Convert file to binary"""
    path = os.path.join(BASE_DIR, "media", filename)
    f = open(path, 'rb')
    user.cv = f.read()
    user.save()
    f.close()
    os.remove(path)


def is_ajax(request):
    """Returns if a request is an AJAX request or not"""
    return request.headers.get('x-requested-with') == 'XMLHttpRequest'


def has_applied(job_seeker, job_advertisement):
    """Returns True if job seeker has applied for advertisement, False otherwise"""
    return JobApplication.objects.filter(advertisement=job_advertisement, job_seeker=job_seeker).exists()


def has_reported(user, job_advertisement):
    """Returns True if user has reported job advertisement, False otherwise"""
    report_group = ReportGroup.objects.filter(job_advertisement=job_advertisement)
    return report_group and \
           JobAdvertisementReport.objects.filter(reporter=user, report_group=ReportGroup.objects.get(
               job_advertisement=job_advertisement)).exists()

def updateExchangeRates(currency_in):
    """Update the exchange rate of the currency to dollars in the database"""
    try:
        url = f'https://api.exchangerate.host/convert?from={currency_in}&to=USD'
        response = requests.get(url).json()
        c_rate = CurrencyRate.objects.get(currency=currency_in)
        c_rate.exchange_rate = str(response['result'])
        c_rate.save()
    except:
        pass

def estimate_yearly_salary(ad, seeker):
    """ Generate an yearly salary estimate of the ad using the salary data of the ad and the seeker"""
    ad_salary_amount = float(ad.salary.amount)
    ad_exchange_rate = float(ad.exchange_rate)
    job_seeker_exchange_rate = float(seeker.exchange_rate)
    estimate = 0
    match ad.salary_type:
        case 'Hourly':
            estimate = (ad_salary_amount*ad.hours*52*ad_exchange_rate)/job_seeker_exchange_rate
        case 'Monthly':
            estimate = (ad_salary_amount*12*ad_exchange_rate)/job_seeker_exchange_rate
        case 'Yearly':
            estimate = (ad_salary_amount*ad_exchange_rate)/job_seeker_exchange_rate
    return estimate
