from django.contrib import admin
from django.contrib.auth.admin import UserAdmin as DjangoUserAdmin
from django.contrib.auth.models import Group

from .models.user_models import User, Employer, JobSeeker
from .models.job_advertisement_report_models import ReportGroup, JobAdvertisementReport
from .models.job_advertisement_model import JobAdvertisement

# Changing the default text of the admin site
admin.site.site_header = "Jobs records"
admin.site.index_title = "Jobs records administration"
admin.site.site_title = "admin site"
admin.site.site_url = ""

admin.site.unregister(Group)

class InlinePermissionsMixin:
    def has_delete_permission(self, request, obj=None):
        return False

    def has_add_permission(self, request, obj=None):
        return True

    def has_view_permission(self, request, obj=None):
        return True

    def has_change_permission(self, request, obj=None):
        return True

class EmployerInline(InlinePermissionsMixin, admin.StackedInline):
    """Define the employer inline for the user admin model"""
    model = Employer
    can_delete = False
    verbose_name_plural = 'employer'

class JobSeekerInline(InlinePermissionsMixin, admin.StackedInline):
    """Define the job seeker inline for the user admin model"""
    model = JobSeeker
    can_delete = False
    verbose_name_plural = 'job seeker'

def has_permission(request, obj):
    if obj:
        if obj.is_director:
            return False
        elif obj.is_staff:
            if request.user.is_director:
                return True
            else:
                return False
        else:
            return True
    return True

class StaffPermissionsMixin:
    def has_delete_permission(self, request, obj=None):
        return has_permission(request, obj)

    def has_add_permission(self, request, obj=None):
        return True

    def has_view_permission(self, request, obj=None):
        return True

    def has_change_permission(self, request, obj=None):
        return True


@admin.register(User)
class UserAdmin(StaffPermissionsMixin, DjangoUserAdmin):
    """
    Define the admin models for users
    User hierrarchy: directors > administrators
        . directors can create employers, jobseekers and adminstrators but not other directors
        . Administrators can create employers and jobseekers but not other administrators
    Once the user has been assigned a user_type its type cannot be changed
    The personal information and user_type specific information of the user can be changed though
    Only 'default' users can be administrators or directors (job seekers and employees cannot be staff)
    """

    list_display = ('email', 'first_name', 'last_name', 'user_type', 'is_staff', 'is_director', 'is_active')
    list_filter = ('is_staff', 'is_director', 'is_active')
    search_fields = ('email', 'first_name', 'last_name')
    ordering = ('email',)

    inlines = []

    # Restrict the fields that are shown at the add and view stages depending on what the form is on and who the user is
    def get_fieldsets(self, request, obj=None):
        # Change view
        if obj:
            fieldsets = (
                ('Personal Info', {'fields': ('email', 'first_name', 'last_name'),}),
                ('Status', {'fields': ('user_type', 'is_active', ('is_staff', 'is_director'))})
            )
            # If obj is an employer user display the employer inline which allows the client to insert additional information about the employer
            if obj.user_type == 'employer':
                self.inlines = [EmployerInline]
            # If obj is a job seeker then display the job seeker inline
            elif obj.user_type == 'job_seeker':
                self.inlines = [JobSeekerInline]
            # If the obj is a default user then there is no additional information to be displayed
            else:
                self.inlines = []

        # Add view
        else:
            fieldsets = (
                (None, {
                    'classes': ('wide',),
                    'fields': ('email', 'password1', 'password2', 'user_type',),
                }),
            )
            self.inlines = []
        return fieldsets
    
    # Restrict the editability of certain fields within the form
    def get_form(self, request, obj=None, **kwargs):
        form = super().get_form(request, obj, **kwargs)
        # Change view
        if obj:
            form.base_fields['user_type'].disabled = True
            form.base_fields['is_director'].disabled = True
            if obj.user_type != 'default':
                form.base_fields['is_staff'].disabled = True
            else:
                if not request.user.is_director:
                    form.base_fields['is_staff'].disabled = True
                    if (not obj.email == request.user.email) and obj.is_staff == True:
                        for _ in form.base_fields:
                            form.base_fields[_].disabled = True
                else:
                    if obj.is_director:
                        form.base_fields['is_staff'].disabled = True
                        if not obj.email == request.user.email:
                            for _ in form.base_fields:
                                form.base_fields[_].disabled = True
        return form


class ReportPermissionsMixin:
    def has_delete_permission(self, request, obj=None):
        return True

    def has_add_permission(self, request, obj=None):
        return False

    def has_view_permission(self, request, obj=None):
        return True

    def has_change_permission(self, request, obj=None):
        return False


class JobAdvertisementReportInline(ReportPermissionsMixin, admin.StackedInline):
    """Define ad report inline for the report group admin model"""
    model = JobAdvertisementReport
    verbose_name_plural = 'Advert reports'
    can_delete = True
    fields = ['report_date', 'reporter_email', 'report_text']


@admin.register(ReportGroup)
class ReportGroupAdmin(ReportPermissionsMixin, admin.ModelAdmin):
    """
    Defines the admin model for report groups.
    A report group can't be changed by admin, it can be deleted.
    When a report group is deleted, all of its related reports are deleted as well.
    The advert it is tied to is not deleted.
    """
    list_display = ['ad_employer_email', 'ad_company', 'ad_id', 'count']
    search_fields = ('ad_id', 'ad_employer_email', 'ad_company')
    ordering = ('-count',)
    inlines = [JobAdvertisementReportInline]
    fieldsets = (
        ('Creator info', {'fields': ('ad_employer_email', 'ad_employer_first_name', 'ad_employer_last_name', 'ad_company')}),
        ('Advert info', {'fields': ('ad_id', 'count')})         
    )

@admin.register(JobAdvertisement)
class JobAdvertisementAdmin(ReportPermissionsMixin, admin.ModelAdmin):
    """
    Defins the admin models for advertisements.
    An advertisement can't be edited by admin, it can only be deleted.
    Deleting an advertisement deletes its associated report group.
    """
    list_display = ['employer_email', 'employer_company', 'id', 'job_title', 'salary', 'start_date', 'remote_work']
    search_fields = ('employer_email', 'employer_company', 'id', 'job_title')
    list_filter = ('remote_work',)
    ordering = ('start_date',)
    fieldsets = (
        ('Creator info', {'fields': ('employer_email', 'employer_first_name', 'employer_last_name', 'employer_company', 'website')}),
        ('Advert info', {'fields': ('job_title', 'job_description', 'salary_type', 'salary', 'start_date', 'job_type', 'hours', 'remote_work', 'benefits')})
    )