from django import template

register = template.Library()

@register.filter
def return_item(collection, index):
    """
    Get the item at the specified index in the collection

    Args:
        collection<T>: The collection to be accessed
        index (int): The index that specifies the location of the sought after item in the collection

    Returns:
        T: The item at the given index
    """
    try:
        return collection[index]
    except:
        return None

@register.filter
def has_length_one(collection):
    """
    Check whether the passed collection has length one

    Args:
        collection<T>: The collection to be checked

    Returns:
        bool: Boolean representing whether the collection has length one or not 
    """
    if len(collection) == 1:
        return True
    else:
        return False