from django import forms

from jobs.models import Message
from jobs.enums import *


class GoToMessageChannelForm(forms.Form):
    """Form for a user to start/enter a message channel with another user
    USED IN MESSAGE HOME AND SO ONLY FOR TESTING, TO BE REMOVED AFTER IMPLEMENTED WITH EMPLOYER SEEING APPLICANTS"""

    receiver = forms.EmailField(label="Email of person you want to message", required=True)


class SendMessageForm(forms.ModelForm):
    """Form for a user to send a message to a message channel"""

    class Meta:
        model = Message
        fields = ['message_text']

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['message_text'].widget.attrs.update({'id' : 'message-to-send'})
        self.fields['message_text'].label = ''




