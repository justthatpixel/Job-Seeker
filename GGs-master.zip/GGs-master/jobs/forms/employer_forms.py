from django import forms
from django.core.validators import RegexValidator

from .authentication_forms import UserForm
import datetime
from jobs.enums import *
import requests
from jobs.models import User, Employer, JobAdvertisement
from job_hiring.settings import GEOAPIFY_API_KEY
from jobs.helpers import updateExchangeRates

class AdvertisementForm(forms.ModelForm):
    """Form for creating a job advertisement"""
    class Meta:
        model = JobAdvertisement
        fields = ['job_title', 'job_description', 'start_date', 'salary_type', 'salary', 'country', 'state', 'city',
                  'street', 'postcode', 'job_type', 'hours', 'remote_work', 'website', 'benefits']

    benefits = forms.CharField(label='Job Benefits (separate benefits with commas)', required=False,
                               validators=[RegexValidator(
                                   regex=r'^(\w+ ?)*(, ?(\w+ ?)+)*$',
                                   message='Seperate your benefits with commas, with at most a single space between them'
                                           ' Ie "good salary, company pension, free food"'
                                           ' You can only use letters and numbers '
                               )]
                               )
    hours = forms.IntegerField(label='Select Hours of work (per week)',min_value=1)
    job_type = forms.CharField(label='Select type of work', widget=forms.Select(choices=JOB_TYPES))
    start_date = forms.CharField(label='Select start date', widget=forms.DateInput(
        attrs={'type': 'date', 'min': datetime.date.today(),
               'max': datetime.date.today() + datetime.timedelta(days=365)}))

    def clean(self, *args, **kwargs):
        """
        Extra validation for location and salary fields
        The API calls to GEOAPIFY and exchangehost are made here
        """
        super().clean(*args, **kwargs)
        country = self.cleaned_data['country']
        state = self.cleaned_data['state']
        city = self.cleaned_data['city']
        street = self.cleaned_data['street']
        postcode = self.cleaned_data['postcode']
        match (country, state, city, street, postcode):
            case (None, None, None, None, None):
                pass
            case (_, _, _, _, None):
                self.raise_location_errors()
            case (_, _, _, None, _):
                self.raise_location_errors()
            case (_, _, None, _, _):
                self.raise_location_errors()
            case (_, None, _, _, _):
                self.raise_location_errors()
            case (None, _, _, _, _):
                self.raise_location_errors()
            case (_, _, _, _, _):
                results = self.callAPI(
                    f"https://api.geoapify.com/v1/geocode/search?country={country}&state={state}&city={city}&street={street}&postcode={postcode}&format=json&apiKey={GEOAPIFY_API_KEY}")
                if results != None:
                    if len(results) == 0:
                        self.add_error("country",
                                       "This country may not be recognised, check for mispellings and avoid abreviations.")
                        self.add_error("state",
                                       "This state may not be recognised, check for mispellings and avoid abreviations.")
                        self.add_error("city",
                                       "This city may not be recognised, check for mispellings and avoid abreviations.")
                        self.add_error("street",
                                       "This street may not be recognised, check for mispellings and avoid abreviations.")
                        self.add_error("postcode",
                                       "This postcode may not be recognised, check for mispellings and avoid abreviations.")
                    else:
                        # Normalise the values of the fields here with the response data
                        try:
                            self.cleaned_data['country'] = results[0]['country']
                        except:
                            self.cleaned_data['country'] = None
                        try:
                            self.cleaned_data['state'] = results[0]['state']
                        except:
                            self.cleaned_data['state'] = None
                        try:
                            self.cleaned_data['city'] = results[0]['city']
                        except:
                            self.cleaned_data['city'] = None
                        try:
                            self.cleaned_data['street'] = results[0]['street']
                        except:
                            self.cleaned_data['street'] = None
                        try:
                            self.cleaned_data['postcode'] = results[0]['postcode']
                        except:
                            self.cleaned_data['postcode'] = None
        
        try:
            salary = self.cleaned_data['salary']
        except:
            salary = None
        if salary != None:
            updateExchangeRates(salary.currency)
        
        return self.cleaned_data
        

    def raise_location_errors(self):
        """Generate a batch of location errors"""
        self.add_error("country", "Please specify either all or none of the job location details.")
        self.add_error("state", "Please specify either all or none of the job location details.")
        self.add_error("city", "Please specify either all or none of the job location details.")
        self.add_error("street", "Please specify either all or none of the job location details.")
        self.add_error("postcode", "Please specify either all or none of the job location details.")

    def save(self, commit=True):
        """Saves the advertisement with the benefits changes"""
        instance = super(AdvertisementForm, self).save(commit=False)

        # Format benefits so they're stored as a JSON array
        benefits = self.cleaned_data.get('benefits')
        if benefits == "" or benefits is None:
            benefits = None
        else:
            benefits = benefits.split(",")  # Split benefits into array

        instance.benefits = benefits
        if commit:
            instance.save()
        return instance

    def callAPI(self, url):
        """GEOPIFY is called with the location data from the form"""
        # If we've used up our number of daily requests to the API then there could be an error which will
        # presenet itself as a status code != 200
        response = requests.get(url)
        if response.status_code != 200:
            self.add_error("country", "The job location details cannot be specified at the moment.")
            return None
        else:
            return response.json()['results']


class EmployerProfileForm(UserForm):
    """Form to update employer profiles."""

    company = forms.CharField(max_length=50, required=True)

    def __init__(self, employer, *args, **kwargs):
        """Initialise the employer field of the form"""
        self.employer = employer
        super().__init__(*args, user=employer.user, **kwargs)

    def save(self):
        """Update the employer's profile data"""
        Employer.objects.filter(user=self.employer.user).update(company=self.cleaned_data['company'])

        User.objects.filter(email=self.employer.user.email).update(
            first_name=self.cleaned_data['first_name'],
            last_name=self.cleaned_data['last_name'],
            email=self.cleaned_data['email']
        )
