from django import forms
import requests
from jobs.models import User, JobSeeker, JobAdvertisementReport
from .authentication_forms import UserForm
from jobs.enums import *
from job_hiring.settings import GEOAPIFY_API_KEY
from jobs.helpers import updateExchangeRates



class JobAdvertisementReportForm(forms.ModelForm):
    """Form for a job seeker to report a job advertisement"""
    report_text = forms.CharField(label="Report", widget=forms.Textarea, required=False)

    class Meta:
        model = JobAdvertisementReport
        fields = ['report_text']


class JobSeekerProfileForm(UserForm):
    """Form to update job seeker profiles."""

    bio = forms.CharField(widget=forms.Textarea, required=False)
    file = forms.FileField(required=False, label='CV')

    def __init__(self, job_seeker, *args, **kwargs):
        """Initialise the job_seeker field of the form"""
        self.job_seeker = job_seeker
        super().__init__(*args, user=job_seeker.user, **kwargs)

    def save(self):
        """Update the job seeker's profile data"""
        JobSeeker.objects.filter(user=self.job_seeker.user).update(
            bio=self.cleaned_data['bio']
        )
        User.objects.filter(email=self.job_seeker.user.email).update(
            first_name=self.cleaned_data['first_name'],
            last_name=self.cleaned_data['last_name'],
            email=self.cleaned_data['email'],
            phone_number=self.cleaned_data['phone_number']
        )
        


class JobSeekerSearchPreferenceForm(forms.ModelForm):
    """Form for specifying the search criteria that is used by the site's matching algorithm"""
    class Meta:
        model = JobSeeker
        fields = ['country','state','city','type','hours','min_salary','job_title','remote']

    def clean(self, *args, **kwargs):
        """Extra validation for the location and salary data of the form"""
        super().clean(*args, **kwargs)
        country = self.cleaned_data['country']
        state = self.cleaned_data['state']
        city = self.cleaned_data['city']
        match (country, state, city):
            # In this case it will be assumed that the seeker is searching for jobs world wide
            case (None, None, None):
                pass
            case (None, None, _):
                self.add_error("country", "Input the country the city below belongs to.")
                self.add_error("state", "Input the state/region the city below belongs to.")
            case (None, _, None):
                self.add_error("country", "Input the country the state below belongs to.")
            case (None, _, _):
                self.add_error("country", "Input the country the state and city below belong to.")
            case (_, None, None):
                results = self.callAPI(f"https://api.geoapify.com/v1/geocode/search?country={country}&format=json&apiKey={GEOAPIFY_API_KEY}")
                # If the results were None then that implies the status_code of the response was not the expected 200 and we skip the logic below
                if results != None:
                    # If the API returns no results then this means the search query wasn't adequate
                    if len(results) == 0:
                        self.add_error("country", "This country isn't recognised, check for mispellings and avoid abreviations.")
                    else:
                        # Normalise the values of the fields here with the response data
                        try:
                            self.cleaned_data['country'] = results[0]['country']
                        except:
                            self.add_error("country", "The location criteria specified isn't recognised.")
            case (_, _, None):
                results = self.callAPI(f"https://api.geoapify.com/v1/geocode/search?country={country}&state={state}&format=json&apiKey={GEOAPIFY_API_KEY}")
                if results != None:
                    if len(results) == 0:
                        self.add_error("country", "This country may not be recognised, check for mispellings and avoid abreviations.")
                        self.add_error("state", "This state may not be recognised, check for mispellings and avoid abreviations.")
                    else:
                        # Normalise the values of the fields here with the response data
                        try:
                            self.cleaned_data['country'] = results[0]['country']
                            self.cleaned_data['state'] = results[0]['state']
                        except:
                            self.add_error("country", "The location criteria specified isn't recognised.")
            case (None, _, _):
                self.add_error("country", "Input the country the state and city below belong to.")
            case (_, _, _):
                results = self.callAPI(f"https://api.geoapify.com/v1/geocode/search?country={country}&state={state}&city={city}&format=json&apiKey={GEOAPIFY_API_KEY}")
                if results != None:
                    if len(results) == 0:
                        self.add_error("country", "This country may not be recognised, check for mispellings and avoid abreviations.")
                        self.add_error("state", "This state may not be recognised, check for mispellings and avoid abreviations.")
                        self.add_error("city", "This city may not be recognised, check for mispellings and avoid abreviations.")
                    else:
                        # Normalise the values of the fields here with the response data
                        try:
                            self.cleaned_data['country'] = results[0]['country']
                            self.cleaned_data['state'] = results[0]['state']
                            self.cleaned_data['city'] = results[0]['city']
                        except:
                            self.add_error("country", "The location criteria specified isn't recognised.")

        salary = self.cleaned_data['min_salary']
        if salary != None:
            updateExchangeRates(salary.currency)

        return self.cleaned_data
    
        # GEOAPI is currently used only for normalising location names, I will keep the long and lat fields
        # in the models for future, but they will not be used for matching.
        # I will match via location names.
        # Also, I will not use the autocomplete feature for now since it will send a lot of api requests
        # and potentially use up our request limit

    def callAPI(self, url):
        """GEOAPIFY's API is requested here with the form's location data"""
        # If we've used up our number of daily requests to the API then there could be an error which will
        # presenet itself as a status code != 200
        response = requests.get(url)
        if response.status_code != 200:
            self.add_error("country", "Your location search criteria cannot be updated at the moment.")
            return None
        else:
            return response.json()['results']
        
