"""Helper methods for test files"""

from django.urls import reverse
from django.utils import timezone
from djmoney.money import Money
from jobs.models import User, JobApplication, JobAdvertisement, MessageChannel
from datetime import timedelta


def create_message_channels(user, from_count, to_count):
    """
    Create unique numbered message channels for testing purposes
    These will be associated with the passed in users
    """
    for count in range(from_count, to_count):
        message_channel = MessageChannel.objects.create()
        message_channel.users.add(user)
        second_user_in_channel = User.objects.create(
            email=f'name{count}@example.org',
            password=f'password',
            first_name=f'first_name{count}',
            last_name=f'last_name{count}',
            user_type='job_seeker'
        )
        message_channel.users.add(second_user_in_channel)
        message_channel.save()


def create_job_advertisements(employer, from_count, to_count):
    """
    Create unique numbered job advertisements for testing purposes
    These will be associated with the passed in employer
    """
    for count in range(from_count, to_count):
        ad = JobAdvertisement(
            employer=employer,
            job_title=f"{count}",
            job_description="As the director of print statements you will be responsible fro make sure all print statements are of the correct syntax and that the terminal is kept in a tidy state",
            start_date=timezone.now()+timedelta(days=4),
            salary_type="Yearly",
            salary=Money(100000, 'USD'),
            remote_work=False,
            hours=40,
            website="https://docs.oracle.com/en/java/",

        )
        ad.save()


def create_job_applications(job_seeker, advertisements):
    """
    Create unique numbered job applications for testing purposes
    These will be associated with the passed in job seeker
    """
    for ad in advertisements:
        application = JobApplication(
            advertisement=ad,
            job_seeker=job_seeker,
            application_date=timezone.now(),
        )
        application.save()


def reverse_with_next(url_name, next_url):
    url = reverse(url_name)
    url += f"?next={next_url}"
    return url


class LogInTester:
    """Tests if the user is logged in"""

    def _is_logged_in(self):
        return '_auth_user_id' in self.client.session.keys()

    def login(self, user):
        self.client.force_login(user)

    def log_out(self):
        url = reverse('log_out')
        self.client.get(url)
