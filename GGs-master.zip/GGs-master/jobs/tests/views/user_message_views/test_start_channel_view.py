from django.test import TestCase
from django.urls import reverse
from jobs.models import User, Employer, JobSeeker, MessageChannel


class StartChannelTestCase(TestCase):
    """Tests for 'start channel' view"""

    fixtures = [
        'jobs/tests/fixtures/default_job_seekers.json',
        'jobs/tests/fixtures/default_employers.json',
    ]

    def setUp(self):
        super(TestCase, self).setUp()

        self.job_seeker = JobSeeker.objects.get(user_id=(User.objects.get(email="john.doe@example.org").id))
        self.employer = Employer.objects.get(user_id=User.objects.get(email="james.jamison@example.org"))
        self.employer_user = User.objects.get(email="james.jamison@example.org")
        self.job_seeker_user = User.objects.get(email="john.doe@example.org")

        self.url = reverse('start_message_channel', kwargs={'receiver_id': self.employer_user.id})


    def test_request_url(self):
        self.assertEqual(self.url, f'/messages/start_channel/{self.employer_user.id}/')

    def test_get_request(self):
        self.client.force_login(self.job_seeker_user)
        response = self.client.get(self.url,
                                   data={'receiver_id': f'{self.employer_user.id}'},
                                   )
        self.assertEqual(response.status_code, 302)

    def test_not_logged_in_get_request(self):
        self.client.logout()
        redirect_url = reverse('home')
        response = self.client.get(self.url, follow=True)
        self.assertRedirects(response, redirect_url, status_code=302, target_status_code=200)

    def test_page_successfully_creates_new_message_channel(self):
        self.client.force_login(self.job_seeker_user)
        before_count = MessageChannel.objects.count()
        response = self.client.get(self.url, data={'receiver_id':self.employer_user.id})
        after_count = MessageChannel.objects.count()
        self.assertEqual(before_count+1,after_count)

    def test_view_does_not_create_message_channel_if_there_is_already_one_like_it(self):
        self.message_channel = MessageChannel.objects.create()
        self.message_channel.users.add(self.job_seeker_user)
        self.message_channel.users.add(self.employer_user)

        self.client.force_login(self.job_seeker_user)
        before_count = MessageChannel.objects.count()
        response = self.client.get(self.url, data={'receiver_id':self.employer_user.id})
        after_count = MessageChannel.objects.count()
        self.assertEqual(before_count,after_count)



