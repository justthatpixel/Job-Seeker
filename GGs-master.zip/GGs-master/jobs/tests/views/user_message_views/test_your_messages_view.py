from django.test import TestCase
from django.urls import reverse
from jobs.models import User, Employer, JobSeeker, MessageChannel, MessageNotification, Message
from jobs.tests.helpers import create_message_channels


class YourMessagesTestCase(TestCase):
    """Tests for 'your messages' view"""

    fixtures = [
        'jobs/tests/fixtures/default_job_seekers.json',
        'jobs/tests/fixtures/default_employers.json',
    ]

    def setUp(self):
        super(TestCase, self).setUp()

        self.job_seeker = JobSeeker.objects.get(user_id=(User.objects.get(email="john.doe@example.org").id))
        self.employer = Employer.objects.get(user_id=User.objects.get(email="james.jamison@example.org"))
        self.employer_user = User.objects.get(email="james.jamison@example.org")
        self.job_seeker_user = User.objects.get(email="john.doe@example.org")

        self.url = reverse('your_messages')
        self.send_message_url = reverse('send_message')


    def send_message_to_channel(self, sender, message_text, message_channel):
        """
        Sends a message to passed in message channel
        YOU MUST BE LOGGED IN AS THE SENDER BEFORE USING THIS OR IT WON'T WORK
        """
        send_response = self.client.post(
            self.send_message_url,
            data={'sender': f'{sender.id}',
                  'message_channel': f'{message_channel.id}',
                  'message': message_text},
        )
        return send_response

    def test_request_url(self):
        self.assertEqual(self.url, '/messages/your_messages/')

    def test_get_request(self):
        self.client.force_login(User.objects.get(id=self.job_seeker.user_id))
        response = self.client.get(self.url)
        self.assertEqual(response.status_code, 200)
        self.assertTemplateUsed(response, "user_messaging/your_messages.html")


    def test_page_shows_message_channels(self):
        start_channel_number, end_channel_number = 100, 105
        self.client.force_login(User.objects.get(id=self.employer.user_id))
        create_message_channels(self.employer_user, start_channel_number, end_channel_number)
        response = self.client.get(self.url)
        for channel_number in range(start_channel_number, end_channel_number):
            self.assertContains(response, channel_number)

    def test_page_shows_messages_of_chosen_message_channel(self):
        self.client.force_login(User.objects.get(id=self.employer.user_id))

        new_message_channel = MessageChannel.objects.create()
        new_message_channel.users.add(self.employer_user)
        new_message_channel.users.add(self.job_seeker_user)

        # Send some messages to the channel
        first_message_text = "Hi There!"
        self.send_message_to_channel(self.employer_user, first_message_text, new_message_channel)
        second_message_text = "Greeting!"
        self.send_message_to_channel(self.job_seeker_user, second_message_text, new_message_channel)

        # Make a get request with the chosen channel
        response = self.client.get(
            self.url,
            data={'channel_id': f'{new_message_channel.id}'},
            HTTP_X_REQUESTED_WITH='XMLHttpRequest'
        )

        self.assertContains(response, self.job_seeker_user.first_name)
        self.assertContains(response, self.job_seeker_user.last_name)
        self.assertContains(response, first_message_text)
        self.assertContains(response, second_message_text)

