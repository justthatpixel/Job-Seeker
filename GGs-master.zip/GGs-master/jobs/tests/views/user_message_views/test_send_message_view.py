from django.test import TestCase
from django.urls import reverse
from jobs.models import User, Employer, JobSeeker, MessageChannel, Message


class SendMessageTestCase(TestCase):
    """Tests for 'send message' view"""

    fixtures = [
        'jobs/tests/fixtures/default_job_seekers.json',
        'jobs/tests/fixtures/default_employers.json',
    ]

    def setUp(self):
        super(TestCase, self).setUp()

        self.job_seeker = JobSeeker.objects.get(user_id=(User.objects.get(email="john.doe@example.org").id))
        self.employer = Employer.objects.get(user_id=User.objects.get(email="james.jamison@example.org"))
        self.employer_user = User.objects.get(email="james.jamison@example.org")
        self.job_seeker_user = User.objects.get(email="john.doe@example.org")

        self.your_messages_url = reverse('your_messages')
        self.send_message_url = reverse('send_message')

        self.message_channel = MessageChannel.objects.create()
        self.message_channel.users.add(self.job_seeker_user)
        self.message_channel.users.add(self.employer_user)

    def send_message_to_channel(self, sender, message_text, message_channel):
        """
        Sends a message to passed in message channel
        YOU MUST BE LOGGED IN AS THE SENDER BEFORE USING THIS OR IT WON'T WORK
        """
        send_response = self.client.post(
            self.send_message_url,
            data={'sender': f'{sender.id}',
                  'message_channel': f'{message_channel.id}',
                  'message': message_text},
        )
        return send_response

    def test_request_url(self):
        self.assertEqual(self.send_message_url, '/messages/send/')

    def test_get_request(self):
        self.client.force_login(User.objects.get(id=self.employer_user.id))
        message_text = "Hello There!"
        response = self.client.post(self.send_message_url,
                                   data={'sender': f'{self.employer_user.id}',
                                         'message_channel': f'{self.message_channel.id}',
                                         'message': message_text},
                                   )
        self.assertEqual(response.status_code, 200)


    def test_page_successfully_sends_message(self):
        self.client.force_login(User.objects.get(id=self.employer_user.id))
        message_text = "Hello There!"
        self.send_message_to_channel(self.employer_user,message_text,self.message_channel)
        self.assertTrue(Message.objects.filter(sender=self.employer_user,message_text=message_text,message_channel=self.message_channel).exists())



