from django.test import TestCase
from django.urls import reverse
from jobs.models import User, Employer, JobSeeker, MessageChannel
from django.http import HttpResponse

class GetMessagesInChannelTestCase(TestCase):
    """Tests for 'get messages in channel' view"""

    fixtures = [
        'jobs/tests/fixtures/default_job_seekers.json',
        'jobs/tests/fixtures/default_employers.json',
    ]

    def setUp(self):
        super(TestCase, self).setUp()

        self.job_seeker = JobSeeker.objects.get(user_id=(User.objects.get(email="john.doe@example.org").id))
        self.job_seeker2 = JobSeeker.objects.get(user_id=(User.objects.get(email="jane.doe@example.org").id))
        self.employer = Employer.objects.get(user_id=User.objects.get(email="james.jamison@example.org"))
        self.employer_user = User.objects.get(email="james.jamison@example.org")
        self.job_seeker_user = User.objects.get(email="john.doe@example.org")
        self.job_seeker_user2 = User.objects.get(email="jane.doe@example.org")

        self.your_messages_url = reverse('your_messages')
        self.send_message_url = reverse('send_message')
        self.get_messages_in_channel_url = reverse('get_messages_in_channel')

        self.message_channel = MessageChannel.objects.create()
        self.message_channel.users.add(self.job_seeker_user)
        self.message_channel.users.add(self.employer_user)

    def send_message_to_channel(self, sender, message_text, message_channel):
        """
        Sends a message to passed in message channel
        YOU MUST BE LOGGED IN AS THE SENDER BEFORE USING THIS OR IT WON'T WORK
        """
        send_response = self.client.post(
            self.send_message_url,
            data={'sender': f'{sender.id}',
                  'message_channel': f'{message_channel.id}',
                  'message': message_text},
        )
        return send_response

    def test_request_url(self):
        self.assertEqual(self.get_messages_in_channel_url, '/messages/get/')

    def test_get_request(self):
        self.client.force_login(User.objects.get(id=self.employer_user.id))
        response = self.client.get(self.get_messages_in_channel_url,
                                   data={'channel_id': f'{self.message_channel.id}',
                                         'user_id': f'{self.employer_user.id}'},
                                   )
        self.assertEqual(response.status_code, 200)


    def test_messages_update_in_message_channel(self):
        self.client.force_login(User.objects.get(id=self.employer.user_id))

        # Send some messages to the channel
        first_message_text = "Hi There!"
        self.send_message_to_channel(self.employer_user, first_message_text, self.message_channel)
        second_message_text = "Greeting!"
        self.send_message_to_channel(self.job_seeker_user, second_message_text, self.message_channel)


        get_response = self.client.get(
            self.get_messages_in_channel_url,
            data={'channel_id': f'{self.message_channel.id}',
                  'user_id': f'{self.employer.user_id}'},
        )

        self.assertContains(get_response, self.job_seeker_user.first_name)
        self.assertContains(get_response, self.job_seeker_user.last_name)
        self.assertContains(get_response, first_message_text)
        self.assertContains(get_response, second_message_text)
        
    def test_get_messages_in_channel_with_no_id(self):
        self.client.force_login(self.job_seeker_user)
        with self.assertRaises(AttributeError):
            response = self.client.get(self.get_messages_in_channel_url)
            
    def test_get_messages_in_channel_with_no_id_and_no_existing_channel(self):
        self.client.force_login(self.job_seeker_user2)
        response = self.client.get(self.get_messages_in_channel_url)
        self.assertIsInstance(response, HttpResponse)
            
    def test_get_channel_id_is_question_mark(self):
        self.client.force_login(User.objects.get(id=self.employer_user.id))
        response = self.client.get(self.get_messages_in_channel_url,
                                   data={'channel_id': '?',
                                         'user_id': f'{self.employer_user.id}'},
                                   )
        self.assertEqual(response.status_code, 200)
        self.assertIsInstance(response, HttpResponse)
        
    def test_non_existing_channel_id(self):
        self.client.force_login(User.objects.get(id=self.employer_user.id))
        response = self.client.get(self.get_messages_in_channel_url,
                                   data={'channel_id': '124124',
                                         'user_id': f'{self.employer_user.id}'},
                                   )
        self.assertEqual(response.status_code, 200)
        self.assertIsInstance(response, HttpResponse)



