from django.test import TestCase
from django.urls import reverse
from jobs.models import User, Employer, JobSeeker, MessageChannel


class MessageHomeTestCase(TestCase):
    """Tests for message home"""

    fixtures = [
        'jobs/tests/fixtures/default_job_seekers.json',
        'jobs/tests/fixtures/default_employers.json',
    ]

    def setUp(self):
        super(TestCase, self).setUp()

        self.job_seeker = JobSeeker.objects.get(user_id=(User.objects.get(email="john.doe@example.org").id))
        self.employer = Employer.objects.get(user_id=User.objects.get(email="james.jamison@example.org"))
        self.employer_user = User.objects.get(email="james.jamison@example.org")
        self.job_seeker_user = User.objects.get(email="john.doe@example.org")

        self.url = reverse('message_home')
        self.send_message_url = reverse('send_message')


   

    def test_request_url(self):
        self.assertEqual(self.url, '/message_home/')

    def test_get_request(self):
        self.client.force_login(User.objects.get(id=self.job_seeker.user_id))
        response = self.client.get(self.url)
        self.assertEqual(response.status_code, 200)
        self.assertTemplateUsed(response, "user_messaging/message_home.html")
        
    def test_channel_created_on_post(self):
        self.client.force_login(self.job_seeker_user)
        data = {'receiver': self.employer_user.email}
        response = self.client.post(self.url, data)
        self.assertRedirects(response, reverse('your_messages'))
        channel_exists = MessageChannel.objects.filter(users=self.job_seeker_user).filter(users=self.employer_user).exists()
        self.assertTrue(channel_exists)
        
    def test_receiver_email_not_existing(self):
        self.client.force_login(self.job_seeker_user)
        data = {'receiver': 'fake_mail@example.org'}
        response = self.client.post(self.url, data)
        channel_exists = MessageChannel.objects.filter(users=self.job_seeker_user).filter(users=self.employer_user).exists()
        self.assertFalse(channel_exists)
        messages_list = list(response.context['messages'])
        self.assertEqual(len(messages_list), 1)
        self.assertEqual(str(messages_list[0]), 'No user with that email exists')
        self.assertTemplateUsed(response, "user_messaging/message_home.html")
        
    def test_channel_already_exists(self):
        self.message_channel = MessageChannel.objects.create()
        self.message_channel.users.add(self.job_seeker_user)
        self.message_channel.users.add(self.employer_user)
        self.client.force_login(self.job_seeker_user)
        data = {'receiver': self.employer_user.email}
        response = self.client.post(self.url, data)
        messages_list = list(response.context['messages'])
        self.assertEqual(len(messages_list), 1)
        self.assertEqual(str(messages_list[0]), 'You are already in a channel with this person')
        self.assertTemplateUsed(response, "user_messaging/message_home.html")
        channel_exists = MessageChannel.objects.filter(users=self.job_seeker_user).filter(users=self.employer_user).exists()
        self.assertTrue(channel_exists)
        

   