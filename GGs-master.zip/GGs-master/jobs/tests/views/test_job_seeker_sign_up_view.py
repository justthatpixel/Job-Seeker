from django.contrib.auth.hashers import check_password
from django.test import TestCase
from django.urls import reverse
from jobs.forms.authentication_forms import JobSeekerSignUpForm
from jobs.models.user_models import User, JobSeeker
from jobs.tests.helpers import LogInTester


class JobSeekerSignUpViewTestCase(TestCase, LogInTester):
    """Tests for the sign up view"""
    fixtures = ['jobs/tests/fixtures/default_employers.json',
                'jobs/tests/fixtures/default_job_seekers.json',
                'jobs/tests/fixtures/default_staff.json']

    def setUp(self):
        self.url = reverse('job_seeker_sign_up')
        self.form_input = {
            'first_name': 'Adam',
            'last_name': 'Johnson',
            'email': 'adam.johnson@example.com',
            'new_password': 'Password123',
            'confirmation_password': 'Password123',
            'bio': 'I specialise in the trade of cheese',
            'phone_number_0': 'US',
            'phone_number_1': '6044011234'
        }

    def test_sign_up_url(self):
        self.assertEqual(self.url, '/job_seeker_sign_up/')

    def test_get_sign_up(self):
        response = self.client.get(self.url)
        self.assertEqual(response.status_code, 200)
        self.assertTemplateUsed(response, 'auth_pages/sign_up_job_seeker.html')
        form = response.context['form']
        self.assertTrue(isinstance(form, JobSeekerSignUpForm))
        self.assertFalse(form.is_bound)

    def test_unsuccessful_sign_up(self):
        self.form_input['email'] = 'badEmail'
        before_count = User.objects.count()
        response = self.client.post(self.url, self.form_input)
        after_count = User.objects.count()
        self.assertEqual(after_count, before_count)
        self.assertEqual(response.status_code, 200)
        self.assertTemplateUsed(response, 'auth_pages/sign_up_job_seeker.html')
        form = response.context['form']
        self.assertTrue(isinstance(form, JobSeekerSignUpForm))
        self.assertTrue(form.is_bound)
        self.assertFalse(self._is_logged_in())

    def test_successful_sign_up(self):
        before_count = User.objects.count()
        response = self.client.post(self.url, self.form_input, follow=True)
        after_count = User.objects.count()
        self.assertEqual(after_count, before_count + 1)
        response_url = reverse('job_seeker_home')
        self.assertRedirects(response, response_url, status_code=302, target_status_code=200)
        self.assertTemplateUsed(response, 'home_pages/home_job_seeker.html')
        user = User.objects.get(email='adam.johnson@example.com')
        self.assertEqual(user.first_name, 'Adam')
        self.assertEqual(user.last_name, 'Johnson')
        self.assertEqual(user.email, 'adam.johnson@example.com')
        self.assertEqual(user.user_type, 'job_seeker')
        is_password_correct = check_password('Password123', user.password)
        self.assertTrue(is_password_correct)
        self.assertTrue(self._is_logged_in())

        job_seeker_details = JobSeeker.objects.get(user=user)
        self.assertTrue(job_seeker_details.bio, 'I specialise in the trade of cheese')

    def test_logged_in_employer_tries_to_access_employer_sign_up_page(self):
        self.client.login(email='james.jamison@example.org', password='Password123')
        self.assertTrue(self._is_logged_in())
        response = self.client.get(self.url, follow=True)
        response_url = reverse('employer_home')
        self.assertRedirects(response, response_url, status_code=302, target_status_code=200)
        self.assertTemplateUsed(response, 'home_pages/home_employer.html')

    def test_logged_in_job_seeker_tries_to_access_employer_sign_up_page(self):
        self.client.login(email='john.doe@example.org', password='Password123')
        self.assertTrue(self._is_logged_in())
        response = self.client.get(self.url, follow=True)
        response_url = reverse('job_seeker_home')
        self.assertRedirects(response, response_url, status_code=302, target_status_code=200)
        self.assertTemplateUsed(response, 'home_pages/home_job_seeker.html')

    def test_logged_in_staff_tries_to_access_employer_sign_up_page(self):
        self.client.login(email='wallace.walnut@example.org', password='Password123')
        self.assertTrue(self._is_logged_in())
        response = self.client.get(self.url, follow=True)
        response_url = reverse('admin:index')
        self.assertRedirects(response, response_url, status_code=302, target_status_code=200)
        self.assertTemplateUsed(response, 'admin/index.html')
