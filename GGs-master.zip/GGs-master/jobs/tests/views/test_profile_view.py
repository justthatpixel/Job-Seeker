"""Tests for the profile view."""
from django.test import TestCase
from django.urls import reverse

from jobs.forms.authentication_forms import UserForm
from jobs.models import User,Employer,JobSeeker


class ProfileViewTest(TestCase):
    """Test suite for the profile view."""

    fixtures = [
        'jobs/tests/fixtures/default_job_seekers.json',
        'jobs/tests/fixtures/default_employers.json',
    ]

    def setUp(self):
        self.user = User.objects.get(email='john.doe@example.org')
        self.job_seeker = JobSeeker.objects.get(user_id=(User.objects.get(email="john.doe@example.org").id))
        self.employer = Employer.objects.get(user_id=User.objects.get(email="james.jamison@example.org"))
        self.employer_user = User.objects.get(email="james.jamison@example.org")
        self.job_seeker_user = User.objects.get(email="john.doe@example.org")
        self.url = reverse('profile')
        self.form_input = {
            'first_name': 'John2',
            'last_name': 'Doe2',
            'email': 'john.doe2@example.org',
            'phone_number_0': 'US',
            'phone_number_1': '6044011234',
            'company':'BrickLayers',
}

    def test_profile_url(self):
        self.assertEqual(self.url, '/profile/')
        
       

    def test_get_profile(self):
        self.client.login(email=self.user.email, password='Password123')
        response = self.client.get(self.url)
        self.assertEqual(response.status_code, 200)
        self.assertTemplateUsed(response, 'profile.html')
        form = response.context['form']
        self.assertTrue(isinstance(form, UserForm))
        
    def test_get_employer_profile(self):
        self.client.force_login(User.objects.get(id=self.employer_user.id))
        response = self.client.get(self.url)
        self.assertEqual(response.status_code, 200)
        self.assertTemplateUsed(response, 'profile.html')
        form = response.context['form']
        self.assertTrue(isinstance(form, UserForm))
        self.assertEqual(form.initial['company'], 'Java Inc')

    def test_get_profile_redirects_when_not_logged_in(self):
        redirect_url = reverse('home')
        response = self.client.get(self.url)
        self.assertRedirects(response, redirect_url, status_code=302, target_status_code=200)

    def test_unsuccesful_profile_update(self):
        self.client.login(email=self.user.email, password='Password123')
        self.form_input['email'] = 'BAD_EMAIL'
        before_count = User.objects.count()
        response = self.client.post(self.url, self.form_input)
        after_count = User.objects.count()
        self.assertEqual(after_count, before_count)
        self.assertEqual(response.status_code, 200)
        self.assertTemplateUsed(response, 'profile.html')
        form = response.context['form']
        self.assertTrue(isinstance(form, UserForm))
        self.assertTrue(form.is_bound)
        self.user.refresh_from_db()
        self.assertEqual(self.user.first_name, 'John')
        self.assertEqual(self.user.last_name, 'Doe')
        self.assertEqual(self.user.email, 'john.doe@example.org')

    
    def test_succesful_profile_update(self):
        self.client.force_login(User.objects.get(id=self.job_seeker_user.id))
        before_count = User.objects.count()
        response = self.client.post(self.url, self.form_input, follow=True)
        after_count = User.objects.count()
        self.assertEqual(after_count, before_count)
        response_url = reverse('job_seeker_home')
        self.assertEqual(response.status_code, 200)
        self.assertTemplateUsed(response, 'profile.html')
        messages_list = list(response.context['messages'])
        self.user.refresh_from_db()
        self.assertEqual(self.user.first_name, 'John2')
        self.assertEqual(self.user.last_name, 'Doe2')
        self.assertEqual(self.user.email, 'john.doe2@example.org')
        
    def test_succesful_profile_update(self):
        self.client.force_login(User.objects.get(id=self.employer_user.id))
        before_count = User.objects.count()
        response = self.client.post(self.url, self.form_input, follow=True)
        after_count = User.objects.count()
        self.assertEqual(after_count, before_count)
        response_url = reverse('job_seeker_home')
        self.assertEqual(response.status_code, 200)
        self.assertTemplateUsed(response, 'home_pages/home_employer.html')
        messages_list = list(response.context['messages'])
        self.employer.refresh_from_db()
        self.assertEqual(self.employer.company, 'BrickLayers')
