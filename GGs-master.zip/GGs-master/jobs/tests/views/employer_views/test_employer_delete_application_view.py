from django.test import TestCase
from django.urls import reverse
from django.utils import timezone
from djmoney.money import Money
from jobs.models import JobAdvertisement, User, Employer, JobSeeker, JobApplication, CurrencyRate


class EmployerDeleteApplicationTestCase(TestCase):
    """Tests for the reject application view"""

    fixtures = [
        'jobs/tests/fixtures/default_job_seekers.json',
        'jobs/tests/fixtures/default_employers.json',
    ]

    def setUp(self):
        super(TestCase, self).setUp()

        self.job_seeker = JobSeeker.objects.get(user_id=(User.objects.get(email="john.doe@example.org").id))
        self.employer = Employer.objects.get(user_id=User.objects.get(email="james.jamison@example.org"))

        CurrencyRate.objects.create(currency='USD', exchange_rate=1)

        self.job_advertisement = JobAdvertisement.objects.create(
            employer=self.employer,
            job_title="Director of Print Statements",
            job_description="As the director of print statements you will be responsible fro make sure all print statements are of the correct syntax and that the terminal is kept in a tidy state",
            start_date=timezone.now(),
            salary_type="Yearly",
            salary=Money(100000, 'USD'),
            remote_work=False,
            hours=40,
            website="https://docs.oracle.com/en/java/",
        )

        self.job_application = JobApplication.objects.create(
            advertisement=self.job_advertisement,
            job_seeker=self.job_seeker,
            application_date=timezone.now(),
        )

        self.url = reverse('reject_application', kwargs={'application_id': self.job_application.id})

    def test_request_url(self):
        self.assertEqual(self.url, f'/employer/view_applications/reject/{self.job_application.id}/')
    
    def test_get_invalid_application(self):
        """Test if user tries to reject a request that doesn't exist"""
        self.client.force_login(User.objects.get(id=self.employer.user_id))
        url = reverse('reject_application', kwargs={'application_id': 9999})
        redirect_url = reverse('view_applications')
        response = self.client.get(url)
        self.assertRedirects(response, redirect_url, status_code=302, target_status_code=200)
    
    def test_reject_job_seeker_access(self):
        self.client.force_login(User.objects.get(id=self.job_seeker.user_id))
        redirect_url = reverse("job_seeker_home")
        response = self.client.get(self.url, follow=True)
        self.assertRedirects(response, redirect_url, status_code=302, target_status_code=200)