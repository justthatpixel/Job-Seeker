from django.test import TestCase
from django.urls import reverse
from django.utils import timezone

from jobs.forms.employer_forms import AdvertisementForm
from jobs.models.user_models import User, JobSeeker, Employer, CurrencyRate
from jobs.models.job_advertisement_model import JobAdvertisement
import pytz






class CreateAdvertisementsTestCase(TestCase):
    """Tests for the create advertisement view"""
    
    fixtures = [
        'jobs/tests/fixtures/default_job_seekers.json',
        'jobs/tests/fixtures/default_employers.json',
    ]

    def setUp(self):
        CurrencyRate.objects.create(currency='USD', exchange_rate=1)

        self.url = reverse('create_advertisement')
        self.job_seeker = JobSeeker.objects.get(user_id=(User.objects.get(email="john.doe@example.org").id))
        self.employer = Employer.objects.get(user_id=User.objects.get(email="james.jamison@example.org"))
 
        CurrencyRate.objects.create(currency='EUR', exchange_rate=1)

        self.form_input = {
            'job_title': 'Web developer',
            'job_description': 'develop a job application website',
            'start_date': timezone.datetime(year=2023, month=12, day=14, tzinfo=pytz.UTC),
            'salary_type': 'Yearly',
            'salary_0': '100000.00',
            'salary_1': 'EUR',
            'hours': '60',
            'job_type': 'Part-time',
            'remote_work': 'No',
            'website':' https://www.computerhope.com'
        }
        self.false_input = {
            'job_title': 'Web developer',
            'job_description': 'develop a job application website',
            'start_date': timezone.datetime(year=2023, month=12, day=14, tzinfo=pytz.UTC),
            'salary':'100',
            'hours': '60',
            'job_type': 'Part-time',
            'remote_work': 'No',
            'website':' https://www.computerhope.com'
        }

    def test_advertisement_url(self):
        self.assertEqual(self.url, '/employer/create_advertisement/')

    def test_get_request_dashboard(self):
        self.client.force_login(User.objects.get(id=self.employer.user_id))
        response = self.client.get(self.url, follow=True)
        self.assertEqual(response.status_code, 200)
        self.assertTemplateUsed(response, 'create_advertisement.html')
        form = response.context['form']
        self.assertTrue(isinstance(form, AdvertisementForm))
        messages_list = list(response.context['messages'])
        self.assertEqual(len(messages_list), 0)

    def test_advertisement_is_created(self):
        self.client.force_login(User.objects.get(id=self.employer.user_id))
        response = self.client.get(self.url, follow=True)
        before_count = JobAdvertisement.objects.all().count()
        response = self.client.post(self.url, self.form_input, follow=True)
        after_count = JobAdvertisement.objects.all().count()
        self.assertEqual(after_count, before_count + 1)
        self.assertEqual(response.status_code, 200)
        
        messages_list = list(response.context['messages'])
        self.assertEqual(len(messages_list), 1)
        self.assertEqual(str(messages_list[0]), 'Advertisement Created!')
        self.assertTemplateUsed(response, 'home_pages/home_employer.html')
        redirect_url = reverse('employer_home')
        self.assertRedirects(response, redirect_url, status_code=302, target_status_code=200)
        
    def test_invalid_form_input(self):
        self.client.force_login(User.objects.get(id=self.employer.user_id))
        response = self.client.get(self.url, follow=True)
        response = self.client.post(self.url, self.false_input, follow=True)
        messages_list = list(response.context['messages'])
        self.assertEqual(len(messages_list), 1)
        self.assertEqual(str(messages_list[0]), 'invalid form input')

