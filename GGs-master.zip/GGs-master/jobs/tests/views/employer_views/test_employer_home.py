from django.test import TestCase
from django.urls import reverse
from django.utils import timezone
from djmoney.money import Money
from jobs.models import JobAdvertisement, User, Employer, JobSeeker, CurrencyRate


class EmployerHomeTestCase(TestCase):
    """Tests for the Employer home view"""

    fixtures = [
        'jobs/tests/fixtures/default_job_seekers.json',
        'jobs/tests/fixtures/default_employers.json',
    ]

    def setUp(self):
        super(TestCase, self).setUp()

        self.job_seeker = JobSeeker.objects.get(user_id=(User.objects.get(email="john.doe@example.org").id))
        self.employer = Employer.objects.get(user_id=User.objects.get(email="james.jamison@example.org"))

        CurrencyRate.objects.create(currency='USD', exchange_rate=1)

        self.job_advertisement = JobAdvertisement.objects.create(
            employer=self.employer,
            job_title="Director of Print Statements",
            job_description="As the director of print statements you will be responsible fro make sure all print statements are of the correct syntax and that the terminal is kept in a tidy state",
            start_date=timezone.now(),
            salary_type="Yearly",
            salary=Money(100000, 'USD'),
            remote_work=False,
            hours=40,
            website="https://docs.oracle.com/en/java/",
        )
        self.url = reverse('employer_home')

    def test_request_url(self):
        self.assertEqual(self.url, '/employer/home/')

    def test_get_request(self):
        self.client.force_login(User.objects.get(id=self.employer.user_id))
        response = self.client.get(self.url)
        self.assertEqual(response.status_code, 200)
        self.assertTemplateUsed(response, "home_pages/home_employer.html")
        
    def test_display_advertisements(self):
        self.client.force_login(User.objects.get(id=self.employer.user_id))
        response = self.client.get(self.url, {'advertisement_id': self.job_advertisement.id}, HTTP_X_REQUESTED_WITH='XMLHttpRequest')
        self.assertEqual(response.status_code, 200)
        
        
    