from django.test import TestCase
from django.urls import reverse
from django.utils import timezone

from jobs.models import JobAdvertisement, User, Employer, JobSeeker, JobApplication, CurrencyRate
from jobs.tests.helpers import create_job_advertisements, create_job_applications

from djmoney.money import Money


class EmployerListApplicationsTestCase(TestCase):
    """Tests for the employer view applications view"""

    fixtures = [
        'jobs/tests/fixtures/default_job_seekers.json',
        'jobs/tests/fixtures/default_employers.json',
    ]

    def setUp(self):
        super(TestCase, self).setUp()

        self.job_seeker = JobSeeker.objects.get(user_id=(User.objects.get(email="john.doe@example.org").id))
        self.employer = Employer.objects.get(user_id=User.objects.get(email="james.jamison@example.org"))

        CurrencyRate.objects.create(currency='USD', exchange_rate=1)

        self.job_advertisement = JobAdvertisement.objects.create(
            employer=self.employer,
            job_title="Director of Print Statements",
            job_description="As the director of print statements you will be responsible fro make sure all print statements are of the correct syntax and that the terminal is kept in a tidy state",
            start_date=timezone.now(),
            salary_type="Yearly",
            salary=Money(100000, 'USD'),
            remote_work=False,
            hours=40,
            website="https://docs.oracle.com/en/java/",
        )

        self.job_application = JobApplication.objects.create(
            advertisement=self.job_advertisement,
            job_seeker=self.job_seeker,
            application_date=timezone.now(),
            status="Pending"
        )

        self.url = reverse('view_applications')

    def test_request_url(self):
        self.assertEqual(self.url, '/employer/view_applications/')
    
    def test_get_request(self):
        self.client.force_login(User.objects.get(id=self.employer.user_id))
        response = self.client.get(self.url)
        self.assertEqual(response.status_code, 200)
        self.assertTemplateUsed(response, "employer_applications.html")
    
    def test_reject_job_seeker_access(self):
        self.client.force_login(User.objects.get(id=self.job_seeker.user_id))
        redirect_url = reverse("job_seeker_home")
        response = self.client.get(self.url, follow=True)
        self.assertRedirects(response, redirect_url, status_code=302, target_status_code=200)
    
    def test_page_shows_applications_received(self):
        start_application_number, end_application_number = 100, 105
        self.client.force_login(User.objects.get(id=self.employer.user_id))
        create_job_advertisements(self.employer, start_application_number, end_application_number)
        advertisements = JobAdvertisement.objects.all()
        create_job_applications(self.job_seeker, advertisements)
        response = self.client.get(self.url)
        for application_number in range(start_application_number, end_application_number):
            self.assertContains(response, application_number)
    
    def test_page_shows_details_of_chosen_job_application(self):
        self.client.force_login(User.objects.get(id=self.employer.user_id))

        response = self.client.get(
            self.url,
            data={'application_id': f'{self.job_application.id}'},
            HTTP_X_REQUESTED_WITH='XMLHttpRequest'
        )

        self.assertContains(response, self.job_application.job_seeker.user.first_name)
        self.assertContains(response, self.job_application.job_seeker.user.last_name)
        self.assertContains(response, self.job_application.job_seeker.user.email)
        self.assertContains(response, self.job_application.status)
        