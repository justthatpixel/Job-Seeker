from django.test import TestCase
from django.urls import reverse
from django.utils import timezone
from jobs.views.employer_views import PreviewAdvertisement
from jobs.models import User, JobSeeker, Employer
import pytz


class UpdateAdvertisementsTestCase(TestCase):
    
    fixtures = [
        'jobs/tests/fixtures/default_job_seekers.json',
        'jobs/tests/fixtures/default_employers.json',
    ]

    def setUp(self):
        self.url = reverse('update_advertisement_preview')
        self.job_seeker = JobSeeker.objects.get(user_id=(User.objects.get(email="john.doe@example.org").id))
        self.employer = Employer.objects.get(user_id=User.objects.get(email="james.jamison@example.org"))
        self.advertisement = PreviewAdvertisement()
        
        
    def test_request_url(self):
        self.assertEqual(self.url, '/employer/update_advertisement_preview/')
        
    def test_salary(self):
        self.client.force_login(User.objects.get(id=self.employer.user_id))
        data = {
            'job_title': 'Web developer',
            'job_description': 'develop a job application website',
            'start_date': timezone.datetime(year=2023, month=12, day=14, tzinfo=pytz.UTC),
            'salary_type':'Hourly',
            'salary_0': '100.00',
            'salary_1': 'EUR',
            'hours': '60',
            'country':'United Kingdom',
            'state':'London',
            'city':'London',
            'street':'117 wilmington avenue',
            'postcode':'IG11 8AG',
            'job_type': 'Part-time',
            'remote_work': 'No',
            'website':' https://www.computerhope.com',
            'benefits':'free food, free healthcare'
        }
        response = self.client.post(self.url, data)
        self.assertEqual(response.status_code, 200)
        
    def test_blank_salary(self):
        self.client.force_login(User.objects.get(id=self.employer.user_id))
        data = {
            'job_title': 'Web developer',
            'job_description': 'develop a job application website',
            'start_date': timezone.datetime(year=2023, month=12, day=14, tzinfo=pytz.UTC),
            'salary_type':'Hourly',
            'salary_0': "",
            'salary_1': "",
            'hours': '60',
            'country':'United Kingdom',
            'state':'London',
            'city':'London',
            'street':'117 wilmington avenue',
            'postcode':'IG11 8AG',
            'job_type': 'Part-time',
            'remote_work': 'No',
            'website':' https://www.computerhope.com',
            'benefits':'free food, free healthcare'
        }
        response = self.client.post(self.url, data)
        self.assertEqual(response.status_code, 200)
        
        