from jobs.models import JobAdvertisement, User, JobSeeker, Employer, CurrencyRate
from django.utils import timezone
from djmoney.money import Money
from django.test import TestCase
from django.urls import reverse


class DeletedvertisementsTestCase(TestCase):
    """Tests to delete advertisement view"""
    
    fixtures = [
        'jobs/tests/fixtures/default_job_seekers.json',
        'jobs/tests/fixtures/default_employers.json',
    ]
    
    def setUp(self):
        # self.url = reverse('delete_advertisement')
        self.job_seeker = JobSeeker.objects.get(user_id=(User.objects.get(email="john.doe@example.org").id))
        self.employer = Employer.objects.get(user_id=User.objects.get(email="james.jamison@example.org"))

        CurrencyRate.objects.create(currency='USD', exchange_rate=1)

        self.job_advertisement = JobAdvertisement.objects.create(
            employer=self.employer,
            job_title="Director of Print Statements",
            job_description="As the director of print statements you will be responsible fro make sure all print statements are of the correct syntax and that the terminal is kept in a tidy state",
            start_date=timezone.now(),
            salary_type="Yearly",
            salary=Money(100000, 'USD'),
            remote_work=False,
            hours=40,
            website="https://docs.oracle.com/en/java/",
        )
        
        self.url = reverse('delete_advertisement', kwargs={'advertisement_id': self.job_advertisement.id})
        
    def test_request_url(self):
        self.assertEqual(self.url, f'/employer/delete_advertisement/{self.job_advertisement.id}/')
        
    def test_delete_advertisement(self):
        self.client.force_login(User.objects.get(id=self.employer.user_id))
        before_count = JobAdvertisement.objects.count()
        response = self.client.post(self.url, follow=True)
        after_count = JobAdvertisement.objects.count()
        self.assertEqual(after_count, before_count-1)
        messages_list = list(response.context['messages'])
        self.assertEqual(len(messages_list), 1)
        self.assertEqual(str(messages_list[0]), 'Advertisement deleted successfully!')
        redirect_url = reverse('employer_home')
        self.assertRedirects(response, redirect_url, status_code=302, target_status_code=200)