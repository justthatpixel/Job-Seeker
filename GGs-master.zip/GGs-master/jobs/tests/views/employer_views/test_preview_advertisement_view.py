from django.test import TestCase
from django.urls import reverse
from jobs.views.employer_views import PreviewAdvertisement
from jobs.models import User, JobSeeker, Employer


class PreviewAdvertisementsTestCase(TestCase):
    
    fixtures = [
        'jobs/tests/fixtures/default_job_seekers.json',
        'jobs/tests/fixtures/default_employers.json',
    ]

    def setUp(self):
        self.url = reverse('update_advertisement_preview')
        self.job_seeker = JobSeeker.objects.get(user_id=(User.objects.get(email="john.doe@example.org").id))
        self.employer = Employer.objects.get(user_id=User.objects.get(email="james.jamison@example.org"))
        self.advertisement = PreviewAdvertisement()
        
        
    def test_request_url(self):
        self.assertEqual(self.url, '/employer/update_advertisement_preview/')
        
        
    def test_advertisement_fields(self):
        self.client.force_login(User.objects.get(id=self.employer.user_id))
        self.assertIsNone(self.advertisement.job_title)
        self.assertIsNone(self.advertisement.job_description)
        self.assertIsNone(self.advertisement.start_date)
        self.assertIsNone(self.advertisement.salary_type)
        self.assertIsNone(self.advertisement.salary)
        self.assertIsNone(self.advertisement.job_type)
        self.assertIsNone(self.advertisement.hours)
        self.assertIsNone(self.advertisement.website)
        self.assertIsNone(self.advertisement.benefits)
        self.assertIsNone(self.advertisement.country)
        self.assertIsNone(self.advertisement.state)
        self.assertIsNone(self.advertisement.city)
        self.assertIsNone(self.advertisement.street)
        self.assertIsNone(self.advertisement.postcode)
        
    def test_remote_work(self):
        self.client.force_login(User.objects.get(id=self.employer.user_id))
        self.advertisement = PreviewAdvertisement(remote_work='true')
        self.assertTrue(self.advertisement.remote_work)

        self.advertisement = PreviewAdvertisement(remote_work='false')
        self.assertFalse(self.advertisement.remote_work)
        
    def test_benefits(self):
        self.client.force_login(User.objects.get(id=self.employer.user_id))
        self.advertisement = PreviewAdvertisement(benefits="")
        self.assertIsNone(self.advertisement.benefits)
        self.advertisement = PreviewAdvertisement(benefits="free food, free benefits")
        self.assertEqual(self.advertisement.benefits,['free food', ' free benefits'])
        
    
        
        
        
    
        
       
        
        