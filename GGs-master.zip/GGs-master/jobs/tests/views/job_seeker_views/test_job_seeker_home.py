from django.test import TestCase
from django.urls import reverse
from jobs.models import User, Employer, JobSeeker, CurrencyRate


class JobSeekerHomeTestCase(TestCase):
    """Tests for the job seeker home view"""

    fixtures = [
        'jobs/tests/fixtures/default_job_seekers.json',
        'jobs/tests/fixtures/default_employers.json',
    ]

    def setUp(self):
        super(TestCase, self).setUp()

        self.job_seeker = JobSeeker.objects.get(user_id=(User.objects.get(email="john.doe@example.org").id))
        self.employer = Employer.objects.get(user_id=User.objects.get(email="james.jamison@example.org"))

        CurrencyRate.objects.create(currency='EUR', exchange_rate=1)

        self.form_input = {
            'country': 'United Kingdom',
            'state': 'England',
            'city': 'London',
            'hours': 40,
            'type': 'Full-time',
            'job_title': 'Accountant',
            'remote': False
        }
        


        self.url = reverse('job_seeker_home')

    def test_request_url(self):
        self.assertEqual(self.url, '/job_seeker/home/')

    def test_get_request(self):
        self.client.force_login(User.objects.get(id=self.job_seeker.user_id))
        response = self.client.get(self.url)
        self.assertEqual(response.status_code, 200)
        self.assertTemplateUsed(response, "home_pages/home_job_seeker.html")
        
    def test_job_seeker_preference_form(self):
        self.client.force_login(User.objects.get(id=self.job_seeker.user_id))
        response = self.client.post(self.url, self.form_input, follow=True)
        self.assertEqual(response.status_code, 200)
        self.job_seeker.refresh_from_db()
        self.assertEqual(self.job_seeker.country,'United Kingdom')
        self.assertEqual(self.job_seeker.state,'England')
        self.assertEqual(self.job_seeker.hours,40)
        self.assertEqual(self.job_seeker.type,'Full-time')
        self.assertEqual(self.job_seeker.job_title,'Accountant')
        self.assertEqual(self.job_seeker.remote,False)
        messages_list = list(response.context['messages'])
        self.assertEqual(len(messages_list), 1)
        self.assertEqual(str(messages_list[0]), 'Search criteria updated!')

        
        
    