from django.test import TestCase
from django.urls import reverse
from jobs.models import User, Employer, JobSeeker


class ViewPdfTestCase(TestCase):
    """Tests for the pdf view"""

    fixtures = [
        'jobs/tests/fixtures/default_job_seekers.json',
        'jobs/tests/fixtures/default_employers.json',
    ]

    def setUp(self):
        super(TestCase, self).setUp()

        self.job_seeker = JobSeeker.objects.get(user_id=(User.objects.get(email="john.doe@example.org").id))
        self.employer = Employer.objects.get(user_id=User.objects.get(email="james.jamison@example.org"))
        


        self.url = reverse('view_pdf')

    def test_request_url(self):
        self.assertEqual(self.url, '/view_pdf/')

    def test_upload_cv(self):    
        self.client.force_login(User.objects.get(id=self.job_seeker.user_id))
        self.job_seeker.cv = b'Test cv' 
        self.job_seeker.save()
        response = self.client.get(self.url)
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response['Content-Type'], 'application/pdf')
        self.assertIn(b'Test cv', response.content)
        
    def test_no_cv(self):    
        self.client.force_login(User.objects.get(id=self.job_seeker.user_id))
        self.job_seeker.cv = None
        self.job_seeker.save()
        response = self.client.get(self.url)
        response_url = reverse("home")
        self.assertRedirects(response, response_url, status_code=302, target_status_code=302)
        
        
    def test_employer_redirects_to_home(self):    
        self.client.force_login(User.objects.get(id=self.employer.user_id))
        response = self.client.get(self.url)
        response_url = reverse("home")
        self.assertRedirects(response, response_url, status_code=302, target_status_code=302)