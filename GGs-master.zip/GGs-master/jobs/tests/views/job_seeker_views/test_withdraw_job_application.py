from django.test import TestCase
from django.urls import reverse
from django.utils import timezone
from djmoney.money import Money
from jobs.models import JobAdvertisement, User, Employer, JobSeeker, JobApplication, CurrencyRate


class WithdrawApplicationTestCase(TestCase):
    """Tests for the withdraw application  view"""

    fixtures = [
        'jobs/tests/fixtures/default_job_seekers.json',
        'jobs/tests/fixtures/default_employers.json',
    ]

    def setUp(self):
        super(TestCase, self).setUp()

        self.job_seeker = JobSeeker.objects.get(user_id=(User.objects.get(email="john.doe@example.org").id))
        self.employer = Employer.objects.get(user_id=User.objects.get(email="james.jamison@example.org"))

        CurrencyRate.objects.create(currency='USD', exchange_rate=1)

        self.job_advertisement = JobAdvertisement.objects.create(
            employer=self.employer,
            job_title="Director of Print Statements",
            job_description="As the director of print statements you will be responsible fro make sure all print statements are of the correct syntax and that the terminal is kept in a tidy state",
            start_date=timezone.now(),
            salary_type="Yearly",
            salary=Money(100000, 'USD'),
            remote_work=False,
            hours=40,
            website="https://docs.oracle.com/en/java/",
        )
        self.job_application = JobApplication.objects.create(
            advertisement=self.job_advertisement,
            job_seeker=self.job_seeker,
            application_date=timezone.now(),
        )

        self.url = reverse('withdraw_job_application', kwargs={'advertisement_id': self.job_advertisement.id})

    def test_request_url(self):
        self.assertEqual(self.url, f'/job_seeker/job_listings/withdraw_job_application/{self.job_advertisement.id}/')
        
    def test_withdraw_job_application_(self):
        before_count = JobApplication.objects.count()
        self.client.force_login(User.objects.get(id=self.job_seeker.user_id))
        response = self.client.get(self.url)

        after_count = JobApplication.objects.count()

        self.assertEqual(before_count, after_count+1)


    def test_reject_employer_access(self):
        self.client.force_login(User.objects.get(id=self.employer.user_id))
        redirect_url = reverse("employer_home")
        response = self.client.get(self.url, follow=True)
        self.assertRedirects(response, redirect_url, status_code=302, target_status_code=200)