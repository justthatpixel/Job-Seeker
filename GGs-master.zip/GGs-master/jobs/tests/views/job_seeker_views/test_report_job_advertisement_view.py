from django.test import TestCase
from django.urls import reverse
from django.utils import timezone
from djmoney.money import Money
from jobs.models import JobAdvertisement, User, Employer, JobSeeker, JobAdvertisementReport, ReportGroup, CurrencyRate
from jobs.forms.job_seeker_forms import JobAdvertisementReportForm
from datetime import timedelta


class JobAdvertisementViewTestCase(TestCase):
    """Tests for the report job advertisement view"""

    fixtures = [
        'jobs/tests/fixtures/default_job_seekers.json',
        'jobs/tests/fixtures/default_employers.json',
    ]

    def setUp(self):
        super(TestCase, self).setUp()

        self.form_input = {
            'report_text': 'Not appropriate',
        }

        self.job_seeker = JobSeeker.objects.get(user_id=(User.objects.get(email="john.doe@example.org").id))
        self.employer = Employer.objects.get(user_id=User.objects.get(email="james.jamison@example.org"))

        CurrencyRate.objects.create(currency='USD', exchange_rate=1)

        self.job_advertisement = JobAdvertisement.objects.create(
            employer=self.employer,
            job_title="Director of Print Statements",
            job_description="As the director of print statements you will be responsible fro make sure all print statements are of the correct syntax and that the terminal is kept in a tidy state",
            start_date=timezone.now()+timedelta(days=4),
            salary_type="Yearly",
            salary=Money(100000, 'USD'),
            remote_work=False,
            hours=40,
            website="https://docs.oracle.com/en/java/",
        )

        self.url = reverse('report_job_advertisement', kwargs={'advertisement_id': self.job_advertisement.id})

    def test_request_url(self):
        self.assertEqual(self.url, f'/job_seeker/job_listings/report_job_advertisement/{self.job_advertisement.id}/')

    def test_get_request(self):
        self.client.force_login(User.objects.get(id=self.job_seeker.user_id))
        response = self.client.get(self.url, follow=True)
        self.assertEqual(response.status_code, 200)
        self.assertTemplateUsed(response, "submit_job_advertisement_report.html")

        form = response.context['form']
        self.assertTrue(isinstance(form, JobAdvertisementReportForm))
        messages_list = list(response.context['messages'])
        self.assertEqual(len(messages_list), 0)

    def test_report_is_created(self):
        self.client.force_login(User.objects.get(id=self.job_seeker.user_id))
        response = self.client.get(self.url, follow=True)
        before_count = JobAdvertisementReport.objects.count()
        response = self.client.post(self.url, self.form_input, follow=True)
        after_count = JobAdvertisementReport.objects.count()
        self.assertEqual(after_count, before_count + 1)
        self.assertEqual(response.status_code, 200)
        self.assertTemplateUsed(response, 'job_seeker_job_listings.html')

    def test_report_group_is_created_with_report(self):
        self.client.force_login(User.objects.get(id=self.job_seeker.user_id))
        response = self.client.get(self.url, follow=True)
        before_count = ReportGroup.objects.count()
        response = self.client.post(self.url, self.form_input, follow=True)
        after_count = ReportGroup.objects.count()
        self.assertEqual(after_count, before_count + 1)
        self.assertEqual(response.status_code, 200)
        self.assertTemplateUsed(response, 'job_seeker_job_listings.html')

    def test_report_group_not_created_if_already_exists_for_advertisement(self):
        report_group = ReportGroup.objects.create(
            job_advertisement=self.job_advertisement
        )

        job_advertisement_report = JobAdvertisementReport.objects.create(
            report_group=report_group,
            report_date=timezone.now(),
            reporter=self.job_seeker,
            report_text="Not an actual job posting"
        )

        self.client.force_login(User.objects.get(id=self.job_seeker.user_id))
        response = self.client.get(self.url, follow=True)
        before_count = ReportGroup.objects.count()
        response = self.client.post(self.url, self.form_input, follow=True)
        after_count = ReportGroup.objects.count()
        self.assertEqual(after_count, before_count)
        self.assertEqual(response.status_code, 200)
        self.assertTemplateUsed(response, 'job_seeker_job_listings.html')


    def test_reject_employer_access(self):
        self.client.force_login(User.objects.get(id=self.employer.user_id))
        redirect_url = reverse("employer_home")
        response = self.client.get(self.url, follow=True)
        self.assertRedirects(response, redirect_url, status_code=302, target_status_code=200)
