from django.test import TestCase
from django.urls import reverse
from django.utils import timezone
from djmoney.money import Money
from jobs.models import JobAdvertisement, User, Employer, JobSeeker, CurrencyRate
from jobs.tests.helpers import create_job_advertisements, create_job_applications

class JobSeekerJobListingsTestCase(TestCase):
    """Tests for the job seeker applications view"""

    fixtures = [
        'jobs/tests/fixtures/default_job_seekers.json',
        'jobs/tests/fixtures/default_employers.json',
    ]

    def setUp(self):
        super(TestCase, self).setUp()

        self.job_seeker = JobSeeker.objects.get(user_id=(User.objects.get(email="john.doe@example.org").id))
        self.employer = Employer.objects.get(user_id=User.objects.get(email="james.jamison@example.org"))

        CurrencyRate.objects.create(currency='USD', exchange_rate=1)

        self.job_advertisement = JobAdvertisement.objects.create(
            employer=self.employer,
            job_title="Director of Print Statements",
            job_description="As the director of print statements you will be responsible fro make sure all print statements are of the correct syntax and that the terminal is kept in a tidy state",
            start_date=timezone.now(),
            salary_type="Yearly",
            salary=Money(100000, 'USD'),
            remote_work=False,
            hours=40,
            website="https://docs.oracle.com/en/java/",
        )

        self.url = reverse('job_seeker_applications')

    def test_request_url(self):
        self.assertEqual(self.url, '/job_seeker/applications/')

    def test_get_request(self):
        self.client.force_login(User.objects.get(id=self.job_seeker.user_id))
        response = self.client.get(self.url)
        self.assertEqual(response.status_code, 200)
        self.assertTemplateUsed(response, "job_seeker_applications.html")

    def test_reject_employer_access(self):
        self.client.force_login(User.objects.get(id=self.employer.user_id))
        redirect_url = reverse("employer_home")
        response = self.client.get(self.url, follow=True)
        self.assertRedirects(response, redirect_url, status_code=302, target_status_code=200)

    def test_page_shows_job_applications(self):
        """Tests page shows applications and that each application shows the job title of the applied position"""
        start_application_number, end_application_number = 100, 105
        self.client.force_login(User.objects.get(id=self.job_seeker.user_id))
        create_job_advertisements(self.employer, start_application_number, end_application_number)
        advertisements = JobAdvertisement.objects.all()
        create_job_applications(self.job_seeker, advertisements)
        response = self.client.get(self.url)
        for application_number in range(start_application_number, end_application_number):
            self.assertContains(response, application_number)
