from django.test import TestCase
from django.urls import reverse

from jobs.models import User, Employer, JobSeeker, Notification


class YourNotificationsViewTestCase(TestCase):
    """Tests for 'your notifications' view"""

    fixtures = [
        'jobs/tests/fixtures/default_job_seekers.json',
        'jobs/tests/fixtures/default_employers.json',
    ]

    def setUp(self):
        super(TestCase, self).setUp()

        self.job_seeker = JobSeeker.objects.get(user_id=(User.objects.get(email="john.doe@example.org").id))
        self.employer = Employer.objects.get(user_id=User.objects.get(email="james.jamison@example.org"))
        self.employer_user = User.objects.get(email="james.jamison@example.org")
        self.job_seeker_user = User.objects.get(email="john.doe@example.org")

        self.notification = Notification.objects.create(
            user_to_notify=self.employer_user,
            header="Notification!",
            description="You have a new notification!",
        )

        self.url = reverse('your_notifications')

    def test_request_url(self):
        self.assertEqual(self.url, '/notifications/')

    def test_get_request(self):
        self.client.force_login(User.objects.get(id=self.employer_user.id))
        response = self.client.get(self.url)
        self.assertEqual(response.status_code, 200)
        self.assertTemplateUsed(response, 'your_notifications.html')

    def test_not_logged_in_get_request(self):
        redirect_url = reverse('home')
        response = self.client.get(self.url, follow=True)
        self.assertRedirects(response, redirect_url, status_code=302, target_status_code=200)

    def test_your_notifications_shows_all_users_notifications(self):
        self.client.force_login(User.objects.get(id=self.employer.user_id))

        # Make a get request with the chosen channel
        response = self.client.get(self.url)

        self.assertContains(response, self.notification.header)
        self.assertContains(response, self.notification.description)


