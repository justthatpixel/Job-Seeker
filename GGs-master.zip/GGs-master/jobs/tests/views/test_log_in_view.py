from django.contrib import messages
from django.test import TestCase
from django.urls import reverse
from jobs.forms.authentication_forms import LogInForm
from jobs.models.user_models import User
from jobs.tests.helpers import LogInTester


class LogInViewTestCase(TestCase, LogInTester):
    """Test the log in view"""
    fixtures = ['jobs/tests/fixtures/default_employers.json',
                'jobs/tests/fixtures/default_job_seekers.json',
                'jobs/tests/fixtures/default_staff.json']

    def setUp(self):
        self.url = reverse('log_in')
        self.employer = User.objects.get(email='james.jamison@example.org')
        self.job_seeker = User.objects.get(email='john.doe@example.org')
        self.administrator = User.objects.get(email='wallace.walnut@example.org')
        self.super_user = User.objects.get(email='gromit.green@example.org')

    def test_log_in_url(self):
        self.assertEqual(self.url, '/log_in/')

    def test_get_log_in(self):
        response = self.client.get(self.url)
        self.assertEqual(response.status_code, 200)
        self.assertTemplateUsed(response, 'auth_pages/log_in.html')
        form = response.context['form']
        self.assertTrue(isinstance(form, LogInForm))
        self.assertFalse(form.is_bound)
        messages_list = list(response.context['messages'])
        self.assertEqual(len(messages_list), 0)

    def test_unsuccessful_log_in(self):
        form_input = {'email': 'adam.johnson@example.org', 'password': 'password'}
        response = self.client.post(self.url, form_input)
        self.assertEqual(response.status_code, 200)
        self.assertTemplateUsed(response, 'auth_pages/log_in.html')
        form = response.context['form']
        self.assertTrue(isinstance(form, LogInForm))
        self.assertFalse(form.is_bound)
        self.assertFalse(self._is_logged_in())
        messages_list = list(response.context['messages'])
        self.assertEqual(len(messages_list), 1)
        self.assertEqual(messages_list[0].level, messages.ERROR)

    def test_successful_log_in_by_employer(self):
        form_input = {'email': 'james.jamison@example.org', 'password': 'Password123'}
        response = self.client.post(self.url, form_input, follow=True)
        self.assertTrue(self._is_logged_in())
        response_url = reverse('employer_home')
        self.assertRedirects(response, response_url, status_code=302, target_status_code=200)
        self.assertTemplateUsed(response, 'home_pages/home_employer.html')
        messages_list = list(response.context['messages'])
        self.assertEqual(len(messages_list), 1)

    def test_successful_log_in_by_job_seeker(self):
        form_input = {'email': 'john.doe@example.org', 'password': 'Password123'}
        response = self.client.post(self.url, form_input, follow=True)
        self.assertTrue(self._is_logged_in())
        response_url = reverse('job_seeker_home')
        self.assertRedirects(response, response_url, status_code=302, target_status_code=200)
        self.assertTemplateUsed(response, 'home_pages/home_job_seeker.html')
        messages_list = list(response.context['messages'])
        self.assertEqual(len(messages_list), 1)
        
        

    def test_successful_log_in_by_administrator(self):
        form_input = {'email': 'wallace.walnut@example.org', 'password': 'Password123'}
        response = self.client.post(self.url, form_input, follow=True)
        self.assertTrue(self._is_logged_in())
        response_url = reverse('admin:index')
        self.assertRedirects(response, response_url, status_code=302, target_status_code=200)
        self.assertTemplateUsed(response, 'admin/index.html')
        messages_list = list(response.context['messages'])
        self.assertEqual(len(messages_list), 1)

    def test_successful_log_in_by_super_user(self):
        form_input = {'email': 'gromit.green@example.org', 'password': 'Password123'}
        response = self.client.post(self.url, form_input, follow=True)
        self.assertTrue(self._is_logged_in())
        response_url = reverse('admin:index')
        self.assertRedirects(response, response_url, status_code=302, target_status_code=200)
        self.assertTemplateUsed(response, 'admin/index.html')
        messages_list = list(response.context['messages'])
        self.assertEqual(len(messages_list), 1)

    def test_logged_in_employer_tries_to_access_log_in_page(self):
        self.client.login(email='james.jamison@example.org', password='Password123')
        self.assertTrue(self._is_logged_in())
        response = self.client.get(self.url, follow=True)
        response_url = reverse('employer_home')
        self.assertRedirects(response, response_url, status_code=302, target_status_code=200)
        self.assertTemplateUsed(response, 'home_pages/home_employer.html')

    def test_logged_in_job_seeker_tries_to_access_log_in_page(self):
        self.client.login(email='john.doe@example.org', password='Password123')
        self.assertTrue(self._is_logged_in())
        response = self.client.get(self.url, follow=True)
        response_url = reverse('job_seeker_home')
        self.assertRedirects(response, response_url, status_code=302, target_status_code=200)
        self.assertTemplateUsed(response, 'home_pages/home_job_seeker.html')

    def test_logged_in_administrator_tries_to_access_log_in_page(self):
        self.client.login(email='wallace.walnut@example.org', password='Password123')
        self.assertTrue(self._is_logged_in())
        response = self.client.get(self.url, follow=True)
        response_url = reverse('admin:index')
        self.assertRedirects(response, response_url, status_code=302, target_status_code=200)
        self.assertTemplateUsed(response, 'admin/index.html')

    def test_logged_in_director_tries_to_access_log_in_page(self):
        self.client.login(email='gromit.green@example.org', password='Password123')
        self.assertTrue(self._is_logged_in())
        response = self.client.get(self.url, follow=True)
        response_url = reverse('admin:index')
        self.assertRedirects(response, response_url, status_code=302, target_status_code=200)
        self.assertTemplateUsed(response, 'admin/index.html')

    # test bad inputs
    def test_log_in_with_blank_email(self):
        form_input = {'email': '', 'password': 'Password123'}
        response = self.client.post(self.url, form_input)
        self.assertEqual(response.status_code, 200)
        self.assertTemplateUsed(response, 'auth_pages/log_in.html')
        form = response.context['form']
        self.assertTrue(isinstance(form, LogInForm))
        self.assertFalse(form.is_bound)
        self.assertFalse(self._is_logged_in())
        messages_list = list(response.context['messages'])
        self.assertEqual(len(messages_list), 1)
        self.assertEqual(messages_list[0].level, messages.ERROR)

    def test_log_in_with_blank_password(self):
        form_input = {'email': 'johndoe@example.org', 'password': ''}
        response = self.client.post(self.url, form_input)
        self.assertEqual(response.status_code, 200)
        self.assertTemplateUsed(response, 'auth_pages/log_in.html')
        form = response.context['form']
        self.assertTrue(isinstance(form, LogInForm))
        self.assertFalse(form.is_bound)
        self.assertFalse(self._is_logged_in())
        messages_list = list(response.context['messages'])
        self.assertEqual(len(messages_list), 1)
        self.assertEqual(messages_list[0].level, messages.ERROR)

    # redirect tests
    def test_get_log_in_with_redirect(self):
        destination_url = reverse('job_seeker_home')
        response = self.client.get(self.url)
        self.assertEqual(response.status_code, 200)
        self.assertTemplateUsed(response, 'auth_pages/log_in.html')
        form = response.context['form']
        self.assertTrue(isinstance(form, LogInForm))
        self.assertFalse(form.is_bound)
        self.assertEqual('/job_seeker/home/', destination_url)
        messages_list = list(response.context['messages'])
        self.assertEqual(len(messages_list), 0)

    def test_get_log_in_redirects_when_logged_in(self):
        self.client.login(username='john.doe@example.org', password="Password123")
        response = self.client.get(self.url, follow=True)
        redirect_url = reverse('job_seeker_home')
        self.assertRedirects(response, redirect_url, status_code=302, target_status_code=200)
        self.assertTemplateUsed(response, 'home_pages/home_job_seeker.html')

    def test_successful_log_in_with_redirect(self):
        redirect_url = reverse('job_seeker_home')
        form_input = {'email': 'john.doe@example.org', 'password': 'Password123', 'next': redirect_url}
        response = self.client.post(self.url, form_input, follow=True)
        self.assertTrue(self._is_logged_in())
        self.assertRedirects(response, redirect_url, status_code=302, target_status_code=200)
        self.assertTemplateUsed(response, 'home_pages/home_job_seeker.html')
        messages_list = list(response.context['messages'])
        self.assertEqual(len(messages_list), 1)
