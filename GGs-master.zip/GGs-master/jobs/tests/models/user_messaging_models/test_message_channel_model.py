from django.core.exceptions import ValidationError
from django.test import TestCase
from django.utils import timezone
from django.urls import reverse
from jobs.models import User, JobSeeker, Employer, Message, MessageChannel


class MessageChannelTestCase(TestCase):
    """Unit tests for the message channel model"""

    fixtures = [
        'jobs/tests/fixtures/default_job_seekers.json',
        'jobs/tests/fixtures/default_employers.json',
    ]

    def setUp(self):
        self.send_message_url = reverse('send_message')

        self.job_seeker = JobSeeker.objects.get(user_id=(User.objects.get(email="john.doe@example.org").id))
        self.job_seeker_user = User.objects.get(email="john.doe@example.org")

        self.employer = Employer.objects.get(user_id=User.objects.get(email="james.jamison@example.org"))
        self.employer_user = User.objects.get(email="james.jamison@example.org")

        self.message_channel = MessageChannel.objects.create()
        self.message_channel.users.add(self.job_seeker_user)
        self.message_channel.users.add(self.employer_user)

        # Send an initial message to the channel
        self.initial_message_text = "Hello there!"
        self.client.force_login(User.objects.get(id=self.job_seeker_user.id))
        self.send_message_to_channel(self.job_seeker_user, self.initial_message_text, self.message_channel)
        self.client.logout()

    def send_message_to_channel(self, sender, message_text, message_channel):
        """
        Sends a message to passed in message channel
        YOU MUST BE LOGGED IN AS THE SENDER BEFORE USING THIS OR IT WON'T WORK
        """
        send_response = self.client.post(
            self.send_message_url,
            data={'sender': f'{sender.id}',
                  'message_channel': f'{message_channel.id}',
                  'message': message_text},
        )
        return send_response

    def _assert_message_channel_is_valid(self):
        try:
            self.message_channel.full_clean()
        except (ValidationError):
            self.fail("Test message channel should be valid")

    def _assert_message_channel_is_invalid(self):
        with self.assertRaises(ValidationError):
            self.message_channel.full_clean()

    def test_message_channel_is_valid(self):
        """Check if test message channel is originally valid"""
        self._assert_message_channel_is_valid()

    """
    --LAST UPDATED FIELD TESTS--
    """

    def test_last_updated_cannot_be_blank(self):
        self.message_channel.last_updated = ''
        self._assert_message_channel_is_invalid()

    def test_messages_can_be_sent_to_channel(self):
        self.assertEqual(Message.objects.filter(message_channel=self.message_channel).count(), 1)

        self.client.force_login(User.objects.get(id=self.employer_user.id))
        self.send_message_to_channel(self.employer_user, 'Hi there!', self.message_channel)
        self.assertEqual(Message.objects.filter(message_channel=self.message_channel).count(), 2)

    """
    --USERS FIELD TESTS--
    """

    def test_users_field_has_correct_number_added_initial_users(self):
        """Two users were added in setup, so we want to confirm these users are in the channel"""
        self.assertEqual(self.message_channel.users.count(), 2)

    def test_can_add_users_to_users_field(self):
        new_user = User.objects.get(email='jane.doe@example.org')

        before_count = self.message_channel.users.count()
        self.message_channel.users.add(new_user)
        after_count = self.message_channel.users.count()

        self.assertEqual(before_count + 1, after_count)

    """
    --PREVIEW MESSAGE TESTS--
    """

    def test_preview_message_returns_empty_string_for_empty_channels(self):
        empty_channel = MessageChannel.objects.create()
        self.assertEqual(empty_channel.preview_message,'')

    def test_preview_message_returns_text_and_name_of_sender_of_most_recent_message(self):
        preview_message = self.message_channel.preview_message

        self.assertIn(self.job_seeker_user.first_name,preview_message)
        self.assertIn(self.job_seeker_user.last_name,preview_message)
        self.assertIn(self.initial_message_text,preview_message)