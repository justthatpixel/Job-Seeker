from django.core.exceptions import ValidationError
from django.test import TestCase
from django.utils import timezone
from jobs.models import User,JobSeeker,Employer, Message, MessageChannel
import pytz


class MessageTestCase(TestCase):
    """Unit tests for the message model"""
    
    fixtures = [
        'jobs/tests/fixtures/default_job_seekers.json',
        'jobs/tests/fixtures/default_employers.json',
    ]

    def setUp(self):
        self.job_seeker = JobSeeker.objects.get(user_id=(User.objects.get(email="john.doe@example.org").id))
        self.job_seeker_user = User.objects.get(email="john.doe@example.org")

        self.employer = Employer.objects.get(user_id=User.objects.get(email="james.jamison@example.org"))

        self.message_channel = MessageChannel.objects.create()

        self.user_message = Message.objects.create(
            message_text="Hello there!",
            date=timezone.datetime(year=2023,month=12,day=1, tzinfo=pytz.UTC),
            sender=self.job_seeker_user,
            message_channel=self.message_channel
        )


    def _assert_message_is_valid(self):
        try:
            self.user_message.full_clean()
        except (ValidationError):
            self.fail("Test user message should be valid")

    def _assert_message_is_invalid(self):
        with self.assertRaises(ValidationError):
            self.user_message.full_clean()


    def test_message_is_valid(self):
        """Check if test message is originally valid"""
        self._assert_message_is_valid()


    """
    --MESSAGE TEXT TESTS--
    """
    def test_message_text_cannot_be_blank(self):
        self.user_message.message_text = ''
        self._assert_message_is_invalid()

    def test_message_text_does_not_have_to_be_unique(self):
        alt_message = Message.objects.create(
            message_text="Hello there!",
            date=timezone.datetime(year=2023,month=12,day=1,tzinfo=pytz.UTC),
            sender=self.job_seeker_user,
            message_channel=self.message_channel,
        )

        self.user_message.message_text = alt_message.message_text
        self._assert_message_is_valid()

    def test_message_text_can_be_500_characters(self):
        self.user_message.message_text = 'x' * 500
        self._assert_message_is_valid()

    def test_message_text_cannot_be_over_500_characters(self):
        self.user_message.message_text = 'x' * 501
        self._assert_message_is_invalid()


    """
    --SENDER FIELD TESTS--
    """
    def test_sender_cannot_be_blank(self):
        self.user_message.sender = None
        self._assert_message_is_invalid()

    def test_deleting_user_deletes_messages_as_well(self):
        before_size = Message.objects.count()
        self.job_seeker_user.delete()
        after_size = Message.objects.count()

        self.assertEqual(before_size,after_size+1)


    """
    --START DATE FIELD TESTS--
    """
    def test_advertisement_date_cannot_be_blank(self):
        self.user_message.date = ''
        self._assert_message_is_invalid()


    """
    --MESSAGE CHANNEL FIELD TESTS--
    """
    def test_message_channel_cannot_be_blank(self):
        self.user_message.message_channel = None
        self._assert_message_is_invalid()

    def test_deleting_message_channel_deletes_messages_as_well(self):
        before_size = Message.objects.count()
        self.message_channel.delete()
        after_size = Message.objects.count()

        self.assertEqual(before_size,after_size+1)















