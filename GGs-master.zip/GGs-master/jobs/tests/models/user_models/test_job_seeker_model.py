from django.core.exceptions import ValidationError
from django.test import TestCase
from jobs.models import User, JobSeeker


class JobSeekerModelTestCase(TestCase):
    fixtures = [
        'jobs/tests/fixtures/default_job_seekers.json',
    ]

    def setUp(self):
        super(TestCase, self).setUp()

        self.job_seeker = JobSeeker.objects.get(user_id=User.objects.get(email="john.doe@example.org").id)

    def _assert_job_seeker_is_valid(self):
        """Checks if self.job_seeker is valid"""
        try:
            self.job_seeker.full_clean()
        except (ValidationError):
            self.fail("self.job_seeker should be valid")

    def _assert_job_seeker_is_invalid(self):
        """Checks if self.job_seeker is invalid"""
        with self.assertRaises(ValidationError):
            self.job_seeker.full_clean()

    def test_job_seeker_is_valid(self):
        self._assert_job_seeker_is_valid()
        
    def test_job_seeker_str_method(self):
        self.assertEqual(str(self.job_seeker), 'details')
        


    """
    --BIO TESTS--
    """

    def test_bio_can_be_blank(self):
        self.job_seeker.bio = ''
        self._assert_job_seeker_is_valid()

    def test_bio_does_not_have_to_be_unique(self):
        alt_user = JobSeeker.objects.get(user_id=User.objects.get(email="jane.doe@example.org").id)
        self.job_seeker.bio = alt_user.bio
        self._assert_job_seeker_is_valid()

    """
    --USER FIELD TESTS--
    """

    def test_user_cannot_be_blank(self):
        self.job_seeker.user = None
        self._assert_job_seeker_is_invalid()

    def test_deleting_user_deletes_job_seeker_as_well(self):
        before_size = JobSeeker.objects.count()
        User.objects.get(id=self.job_seeker.user_id).delete()
        after_size = JobSeeker.objects.count()

        self.assertEqual(before_size, after_size + 1)
        
   