from django.core.exceptions import ValidationError
from django.test import TestCase
from jobs.models import User


class UserModelTestCase(TestCase):
    fixtures = [
        'jobs/tests/fixtures/default_job_seekers.json',
        'jobs/tests/fixtures/default_employers.json',
        'jobs/tests/fixtures/default_staff.json',
    ]

    def setUp(self):
        super(TestCase, self).setUp()

        # Holds the different kinds of users, will run tests for each of these
        self.job_seeker = User.objects.get(email="john.doe@example.org")
        self.employer = User.objects.get(email="james.jamison@example.org")
        self.staff = User.objects.get(email="wallace.walnut@example.org")

        self.users = [self.job_seeker, self.employer, self.staff]

    def _assert_user_is_valid(self, user):
        """Checks if passed in user is valid"""
        try:
            user.full_clean()
        except (ValidationError):
            self.fail("Passed in user should be valid")

    def _assert_user_is_invalid(self, user):
        """Checks if passed in user is invalid"""
        with self.assertRaises(ValidationError):
            user.full_clean()

    def test_users_are_valid(self):
        """Tests if users are valid"""
        for user in self.users:
            self._assert_user_is_valid(user)

    """
    --FIRST NAME TESTS--
    """

    def test_first_name_cannot_be_blank(self):
        for user in self.users:
            user.first_name = ''
            self._assert_user_is_invalid(user)

    def test_first_name_does_not_have_to_be_unique(self):
        alt_user = User.objects.get(email="jane.doe@example.org")
        for user in self.users:
            user.first_name = alt_user.first_name
            self._assert_user_is_valid(user)

    def test_first_name_can_be_50_characters(self):
        for user in self.users:
            user.first_name = 'x' * 50
            self._assert_user_is_valid(user)

    def test_first_name_cannot_be_over_50_characters(self):
        for user in self.users:
            user.first_name = 'x' * 51
            self._assert_user_is_invalid(user)

    """
    --LAST NAME TESTS--
    """

    def test_last_name_cannot_be_blank(self):
        for user in self.users:
            user.last_name = ''
            self._assert_user_is_invalid(user)

    def test_last_name_does_not_have_to_be_unique(self):
        alt_user = User.objects.get(email="jane.doe@example.org")
        for user in self.users:
            user.last_name = alt_user.last_name
            self._assert_user_is_valid(user)

    def test_last_name_can_be_50_characters(self):
        for user in self.users:
            user.last_name = 'x' * 50
            self._assert_user_is_valid(user)

    def test_last_name_cannot_be_over_50_characters(self):
        for user in self.users:
            user.last_name = 'x' * 51
            self._assert_user_is_invalid(user)

    """
    --EMAIL TESTS--
    """

    def test_email_must_be_unique(self):
        alt_user = User.objects.get(email="jane.doe@example.org")
        for user in self.users:
            user.email = alt_user.email
            self._assert_user_is_invalid(user)

    def test_email_must_not_be_blank(self):
        for user in self.users:
            user.email = ''
            self._assert_user_is_invalid(user)
            
    def test_email_must_not_be_none(self):
        with self.assertRaises(ValueError):
            User.objects._create_user(first_name="John", last_name="Ross", email=None,
                                     password="Password123")

    def test_email_must_contain_username(self):
        for user in self.users:
            user.email = '@example.org'
            self._assert_user_is_invalid(user)

    def test_email_needs_at_sign(self):
        for user in self.users:
            user.email = 'john.doe.exmaple.org'
            self._assert_user_is_invalid(user)

    def test_email_must_contain_domain_name(self):
        for user in self.users:
            user.email = 'john.doe@.org'
            self._assert_user_is_invalid(user)

    def test_email_must_contain_domain(self):
        for user in self.users:
            user.email = 'john.doe@example'
            self._assert_user_is_invalid(user)

    def test_email_must_not_contain_more_than_one_at(self):
        for user in self.users:
            user.email = 'johndoe@@example.org'
            self._assert_user_is_invalid(user)

    """
    --USER TYPE TESTS--
    """

    def test_job_seeker_has_correct_user_type(self):
        self.assertEqual(self.job_seeker.user_type, "job_seeker")

    def test_employer_has_correct_user_type(self):
        self.assertEqual(self.employer.user_type, "employer")

    def test_staff_has_correct_user_type(self):
        self.assertEqual(self.staff.user_type, "default")
        
        
    """
    --CREATE JOBSEEKER TESTS--
    """
    
    def test_create_non_director(self):
        self.user = User.objects._create_user(first_name="John", last_name="Ross", email="john_moss@mail.com",
                                             password="Password123",is_director= None)
        self.assertTrue(self.user.is_director == False)
        
    
    def test_jobseeker_can_be_created(self):
        self.user = User.objects.create_user(first_name="John", last_name="Ross", email="john_moss@mail.com",
                                             password="Password123")
        self.assertTrue(self.user.is_staff == False)
        self.assertTrue(self.user.is_active == True)
        self.assertTrue(self.user.is_superuser == False)
        self.assertTrue(self.user.user_type == 'default')
        self.assertTrue(self.user.is_director == False)

        
    def test_jobseeker_cannot_be_staff(self):
        with self.assertRaises(ValueError):
            User.objects.create_user(first_name="John", last_name="Ross", email=None,
                                     password="Password123", is_staff=True)
            
            
    def test_jobseeker_cannot_be_super_user(self):    
        with self.assertRaises(ValueError):
            User.objects.create_user(first_name="John", last_name="Ross", email=None,
                                     password="Password123", is_superuser=True)
            
            
    def test_jobseeker_type_must_be_default(self):        
        with self.assertRaises(ValueError):
            User.objects.create_user(first_name="John", last_name="Ross", email=None,
                                     password="Password123", user_type='employer') 
                   
            
    def test_jobseeker_cannot_be_director(self):
        with self.assertRaises(ValueError):
            User.objects.create_user(first_name="John", last_name="Ross", email=None,
                                     password="Password123", is_director=True)
            
                 
            
    """
    --CREATE STAFF TESTS--
    """       
    def test_staff_can_be_created(self):
        self.user = User.objects.create_staff(first_name="John", last_name="Ross", email="john_moss@mail.com",
                                             password="Password123")
        self.assertTrue(self.user.is_staff == True)
        self.assertTrue(self.user.is_active == True)
        self.assertTrue(self.user.is_superuser == True)
        self.assertTrue(self.user.user_type == 'default')
        self.assertTrue(self.user.is_director == False)

        
    def test_staff_must_be_staff(self):
        with self.assertRaises(ValueError):
            User.objects.create_staff(first_name="John", last_name="Ross", email=None,
                                     password="Password123", is_staff=False)
            
            
    def test_staff_must_be_super_user(self):    
        with self.assertRaises(ValueError):
            User.objects.create_staff(first_name="John", last_name="Ross", email="john_moss@mail.com",
                                     password="Password123", is_superuser=False)
            
            
    def test_staff_type_must_be_default(self):        
        with self.assertRaises(ValueError):
            User.objects.create_staff(first_name="John", last_name="Ross", email="john_moss@mail.com",
                                     password="Password123", user_type='employer') 
                   
            
    def test_staff_cannot_be_director(self):
        with self.assertRaises(ValueError):
            User.objects.create_staff(first_name="John", last_name="Ross", email=None,
                                     password="Password123", is_director=True)
            
            
            
    """
    --CREATE DIRECTOR TESTS--
    """         
            
    
    def test_director_can_be_created(self):
        self.user = User.objects.create_superuser(first_name="John", last_name="Ross", email="john_moss@mail.com",
                                             password="Password123")
        self.assertTrue(self.user.is_staff == True)
        self.assertTrue(self.user.is_active == True)
        self.assertTrue(self.user.is_superuser == True)
        self.assertTrue(self.user.user_type == 'default')
        self.assertTrue(self.user.is_director == True)

        
    def test_director_must_be_staff(self):
        with self.assertRaises(ValueError):
            User.objects.create_superuser(first_name="John", last_name="Ross", email=None,
                                     password="Password123", is_staff=False)
            
            
    def test_director_must_be_super_user(self):    
        with self.assertRaises(ValueError):
            User.objects.create_superuser(first_name="John", last_name="Ross", email=None,
                                     password="Password123", is_superuser=False)
            
            
    def test_director_type_must_be_default(self):        
        with self.assertRaises(ValueError):
            User.objects.create_superuser(first_name="John", last_name="Ross", email=None,
                                     password="Password123", user_type='employer') 
                   
            
    def test_director_must_be_director(self):
        with self.assertRaises(ValueError):
            User.objects.create_superuser(first_name="John", last_name="Ross", email=None,
                                     password="Password123", is_director=False)
            
    
    
    
        
        
