from django.core.exceptions import ValidationError
from django.test import TestCase
from jobs.models import User, Employer


class EmployerModelTestCase(TestCase):
    fixtures = [
        'jobs/tests/fixtures/default_employers.json',
    ]

    def setUp(self):
        super(TestCase, self).setUp()

        self.employer = Employer.objects.get(user_id=User.objects.get(email="james.jamison@example.org").id)

    def _assert_employer_is_valid(self):
        """Checks if self.employer is valid"""
        try:
            self.employer.full_clean()
        except (ValidationError):
            self.fail("self.employer should be valid")

    def _assert_employer_is_invalid(self):
        """Checks if self.employer is invalid"""
        with self.assertRaises(ValidationError):
            self.employer.full_clean()

    def test_employer_is_valid(self):
        self._assert_employer_is_valid()

    """
    --COMPANY TESTS--
    """

    def test_company_cannnot_be_blank(self):
        self.employer.company = ''
        self._assert_employer_is_invalid()

    def test_company_does_not_have_to_be_unique(self):
        alt_user = Employer.objects.get(user_id=User.objects.get(email="josh.jones@example.org").id)
        self.employer.company = alt_user.company
        self._assert_employer_is_valid()

    def test_company_can_be_50_characters(self):
        self.employer.company = 'x' * 50
        self._assert_employer_is_valid()

    def test_company_cannot_be_over_50_characters(self):
        self.employer.company = 'x' * 51
        self._assert_employer_is_invalid()

    """
    --USER FIELD TESTS--
    """

    def test_user_cannot_be_blank(self):
        self.employer.user = None
        self._assert_employer_is_invalid()

    def test_deleting_user_deletes_employer_as_well(self):
        before_size = Employer.objects.count()
        User.objects.get(id=self.employer.user_id).delete()
        after_size = Employer.objects.count()

        self.assertEqual(before_size, after_size + 1)
        
        
    def test_employer_str_method(self):
        user = User.objects.create(email='josh.jjones@example.org', password='Password123', user_type='default')
        employer = Employer.objects.create(user=user, company='Barclays')

        self.assertEqual(str(employer), 'details')
