from django.core.exceptions import ValidationError
from django.test import TestCase
from jobs.models import CurrencyRate

class CurrencyRateTestCase(TestCase):

    def setUp(self):
        self.currency_rate = CurrencyRate.objects.create(currency='USD', exchange_rate=1)

    def _assert_currency_rate_is_valid(self):
        try:
            self.currency_rate.full_clean()
        except (ValidationError):
            self.fail("Test currency should be valid")

    def _assert_currency_rate_is_invalid(self):
        with self.assertRaises(ValidationError):
            self.currency_rate.full_clean()


    def test_currency_rate_is_valid(self):
        """Check if test job application is originally valid"""
        self._assert_currency_rate_is_valid()

    def test_currency_can_be_no_more_than_three_characters(self):
        self.currency_rate.currency = 'BPNdS'
        self._assert_currency_rate_is_invalid()

    def test_currency_can_be_three_characters(self):
        self.currency_rate.currency = 'BPN'
        self._assert_currency_rate_is_valid()

    def test_currency_must_be_unique(self):
        CurrencyRate.objects.create(currency='EUR', exchange_rate=2)
        self.currency_rate.currency = 'EUR'
        self._assert_currency_rate_is_invalid()

    
    def test_exchange_rate_no_more_than_six_decimal_places(self):
        self.currency_rate.exchange_rate = "0.1234567"
        self._assert_currency_rate_is_invalid()
    
    def test_exchange_rate_accepts_six_decimal_places(self):
        self.currency_rate.exchange_rate = "0.123456"
        self._assert_currency_rate_is_valid()

    def test_exchange_rate_max_digits_is_13(self):
        self.currency_rate.exchange_rate = "12345678.123456"
        self._assert_currency_rate_is_invalid()

    def test_exchange_rate_accepts_13_digits(self):
        self.currency_rate.exchange_rate = "1234567.123456"
        self._assert_currency_rate_is_valid()