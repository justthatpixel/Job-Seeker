from django.core.exceptions import ValidationError
from django.test import TestCase
from django.utils import timezone
from django.urls import reverse
from jobs.models import User, JobSeeker, Employer, Message, MessageChannel, MessageNotification
import pytz


class MessageNotificationTestCase(TestCase):
    """Unit tests for the message notification model"""

    fixtures = [
        'jobs/tests/fixtures/default_job_seekers.json',
        'jobs/tests/fixtures/default_employers.json',
    ]

    def setUp(self):
        self.send_message_url = reverse('send_message')

        self.job_seeker = JobSeeker.objects.get(user_id=(User.objects.get(email="john.doe@example.org").id))
        self.job_seeker_user = User.objects.get(email="john.doe@example.org")

        self.employer = Employer.objects.get(user_id=User.objects.get(email="james.jamison@example.org"))
        self.employer_user = User.objects.get(email="james.jamison@example.org")

        self.message_channel = MessageChannel.objects.create()
        self.message_channel.users.add(self.job_seeker_user)
        self.message_channel.users.add(self.employer_user)

        self.user_message = Message.objects.create(
            message_text="Hello there!",
            date=timezone.datetime(year=2023,month=12,day=1, tzinfo=pytz.UTC),
            sender=self.job_seeker_user,
            message_channel=self.message_channel
        )

        self.message_notification = MessageNotification.objects.create(
            user_to_notify=self.employer_user,
            message=self.user_message,
            header="Received a message!",
            description=f"From {self.user_message.sender.first_name}"
        )


    def _assert_message_notification_is_valid(self):
        try:
            self.message_notification.full_clean()
        except (ValidationError):
            self.fail("Test message notification should be valid")

    def _assert_message_notification_is_invalid(self):
        with self.assertRaises(ValidationError):
            self.message_notification.full_clean()

    def test_message_notification_is_valid(self):
        """Check if test message notification is originally valid"""
        self._assert_message_notification_is_valid()

    """
    --MESSAGE FIELD TESTS--
    """
    def test_message_cannot_be_blank(self):
        self.message_notification.message = None
        self._assert_message_notification_is_invalid()

    def test_deleting_message_deletes_message_notifications_as_well(self):
        before_size = MessageNotification.objects.count()
        self.user_message.delete()
        after_size = MessageNotification.objects.count()

        self.assertEqual(before_size,after_size+1)
        
    def test_message_channel_function(self):
        self.assertEqual(self.message_channel,self.message_notification.message_channel)
