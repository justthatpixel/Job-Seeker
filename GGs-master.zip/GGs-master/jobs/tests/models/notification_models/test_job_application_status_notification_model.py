from django.core.exceptions import ValidationError
from django.test import TestCase
from django.utils import timezone
from django.urls import reverse
from djmoney.money import Money

from jobs.models import User, JobSeeker, Employer, JobApplication, JobApplicationStatusNotification, JobAdvertisement, CurrencyRate


class JobApplicationStatusNotificationTestCase(TestCase):
    """Unit tests for the job application status notification"""

    fixtures = [
        'jobs/tests/fixtures/default_job_seekers.json',
        'jobs/tests/fixtures/default_employers.json',
    ]

    def setUp(self):
        self.send_message_url = reverse('send_message')

        self.job_seeker = JobSeeker.objects.get(user_id=(User.objects.get(email="john.doe@example.org").id))
        self.job_seeker_user = User.objects.get(email="john.doe@example.org")

        self.employer = Employer.objects.get(user_id=User.objects.get(email="james.jamison@example.org"))
        self.employer_user = User.objects.get(email="james.jamison@example.org")

        CurrencyRate.objects.create(currency='USD', exchange_rate=1)

        self.job_advertisement = JobAdvertisement.objects.create(
            employer=self.employer,
            job_title="Director of Print Statements",
            job_description="As the director of print statements you will be responsible fro make sure all print statements are of the correct syntax and that the terminal is kept in a tidy state",
            start_date=timezone.now(),
            salary_type="Yearly",
            salary=Money(100000, 'USD'),
            remote_work=False,
            hours=40,
            website="https://docs.oracle.com/en/java/",
        )

        self.job_application = JobApplication.objects.create(
            job_seeker=self.job_seeker,
            advertisement=self.job_advertisement,
            application_date=timezone.now()
        )


        self.status_notification = JobApplicationStatusNotification.objects.create(
            user_to_notify=self.employer_user,
            application=self.job_application,
            header="Received a change in status on a job application",
            description=f"You were accepted!"
        )


    def _assert_application_status_notification_is_valid(self):
        try:
            self.status_notification.full_clean()
        except (ValidationError):
            self.fail("Test message notification should be valid")

    def _assert_application_status_notification_is_invalid(self):
        with self.assertRaises(ValidationError):
            self.status_notification.full_clean()

    def test_application_status_is_valid(self):
        """Check if test message notification is originally valid"""
        self._assert_application_status_notification_is_valid()

    """
    --APPLICATION FIELD TESTS--
    """
    def test_application_cannot_be_blank(self):
        self.status_notification.application = None
        self._assert_application_status_notification_is_invalid()

    def test_deleting_application_deletes_status_notifications_as_well(self):
        before_size = JobApplicationStatusNotification.objects.count()
        self.job_application.delete()
        after_size = JobApplicationStatusNotification.objects.count()

        self.assertEqual(before_size,after_size+1)
