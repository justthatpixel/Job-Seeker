from django.core.exceptions import ValidationError
from django.test import TestCase
from django.utils import timezone
from django.urls import reverse

from jobs.models import User, JobSeeker, Notification
import pytz


class NotificationModelTestCase(TestCase):
    """Unit tests for the notification model"""

    fixtures = [
        'jobs/tests/fixtures/default_job_seekers.json',
        'jobs/tests/fixtures/default_employers.json',
    ]

    def setUp(self):
        self.send_message_url = reverse('send_message')

        self.job_seeker = JobSeeker.objects.get(user_id=(User.objects.get(email="john.doe@example.org").id))
        self.job_seeker_user = User.objects.get(email="john.doe@example.org")

        self.notification = Notification.objects.create(
            user_to_notify=self.job_seeker_user,
            header="Notification!",
            description="You have a new notification!",
            date=timezone.datetime(year=2023,month=12,day=1, tzinfo=pytz.UTC),
        )


    def _assert_notification_is_valid(self):
        try:
            self.notification.full_clean()
        except (ValidationError):
            self.fail("Test notification should be valid")

    def _assert_notification_is_invalid(self):
        with self.assertRaises(ValidationError):
            self.notification.full_clean()

    def test_notification_is_valid(self):
        """Check if test notification is originally valid"""
        self._assert_notification_is_valid()

    """
    --USER TO NOTIFY FIELD TESTS--
    """
    def test_user_to_notify_cannot_be_blank(self):
        self.notification.user_to_notify = None
        self._assert_notification_is_invalid()

    def test_deleting_user_deletes_notification_as_well(self):
        before_size = Notification.objects.count()
        self.job_seeker_user.delete()
        after_size = Notification.objects.count()

        self.assertEqual(before_size,after_size+1)

    """
    --- HEADER FIELD TESTS
    """

    def test_header_cannot_be_blank(self):
        self.notification.header = ''
        self._assert_notification_is_invalid()

    def test_header_does_not_have_to_be_unique(self):
        alt_notification = Notification.objects.create(
            user_to_notify=self.job_seeker_user,
            header="Another Notification!",
            description="You have another new notification!",
            date=timezone.datetime(year=2023, month=12, day=2, tzinfo=pytz.UTC),
        )
        self.notification.header = alt_notification.header
        self._assert_notification_is_valid()

    def test_header_can_be_100_characters(self):
        self.notification.header = 'x' * 100
        self._assert_notification_is_valid()

    def test_header_cannot_be_over_100_characters(self):
        self.notification.header = 'x' * 101
        self._assert_notification_is_invalid()


    """
    --- DESCRIPTION FIELD TESTS
    """

    def test_description_can_be_blank(self):
        self.notification.description = ''
        self._assert_notification_is_valid()

    def test_description_does_not_have_to_be_unique(self):
        alt_notification = Notification.objects.create(
            user_to_notify=self.job_seeker_user,
            header="Another Notification!",
            description="You have another new notification!",
            date=timezone.datetime(year=2023, month=12, day=2, tzinfo=pytz.UTC),
        )
        self.notification.description = alt_notification.description
        self._assert_notification_is_valid()

    def test_description_can_be_200_characters(self):
        self.notification.description = 'x' * 200
        self._assert_notification_is_valid()

    def test_description_cannot_be_over_200_characters(self):
        self.notification.description = 'x' * 201
        self._assert_notification_is_invalid()

    """
    --DATE FIELD TESTS--
    """
    def test_notification_date_cannot_be_blank(self):
        self.notification.date = ''
        self._assert_notification_is_invalid()
