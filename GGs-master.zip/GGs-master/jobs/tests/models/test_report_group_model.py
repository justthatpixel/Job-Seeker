from django.core.exceptions import ValidationError
from django.test import TestCase
from django.utils import timezone
from djmoney.money import Money
from jobs.models import User, JobSeeker, JobAdvertisement, Employer, JobAdvertisementReport, ReportGroup, CurrencyRate


class JobAdvertisementReportTestCase(TestCase):
    """Unit tests for report group model"""

    fixtures = [
        'jobs/tests/fixtures/default_job_seekers.json',
        'jobs/tests/fixtures/default_employers.json',
        'jobs/tests/fixtures/default_staff.json',
    ]

    def setUp(self):
        self.job_seeker = JobSeeker.objects.get(user_id=(User.objects.get(email="john.doe@example.org").id))
        self.employer = Employer.objects.get(user_id=User.objects.get(email="james.jamison@example.org"))

        CurrencyRate.objects.create(currency='USD', exchange_rate=1)

        self.job_advertisement = JobAdvertisement.objects.create(
            employer=self.employer,
            job_title="Director of Print Statements",
            job_description="As the director of print statements you will be responsible fro make sure all print statements are of the correct syntax and that the terminal is kept in a tidy state",
            start_date=timezone.now(),
            salary_type="Yearly",
            salary=Money(100000, 'USD'),
            remote_work=False,
            hours=40,
            website="https://docs.oracle.com/en/java/",
        )

        self.report_group = ReportGroup.objects.create(
            job_advertisement=self.job_advertisement
        )

        self.job_advertisemen_report = JobAdvertisementReport.objects.create(
            report_group=self.report_group,
            report_date=timezone.now(),
            reporter=self.job_seeker,
            report_text="Not an actual job posting"
        )

    def _assert_report_group_is_valid(self):
        try:
            self.report_group.full_clean()
        except (ValidationError):
            self.fail("Test report group should be valid")

    def _assert_report_group_is_invalid(self):
        with self.assertRaises(ValidationError):
            self.report_group.full_clean()

    def test_job_advertisement_report_is_valid(self):
        """Check if test report group is originally valid"""
        self._assert_report_group_is_valid()

    """
    --JOB ADVERTISEMENT FIELD TESTS--
    """

    def test_job_advertisement_cannot_be_blank(self):
        self.report_group.job_advertisement = None
        self._assert_report_group_is_invalid()

    def test_deleting_job_advertisement_deletes_report_group_as_well(self):
        before_size = ReportGroup.objects.count()
        self.job_advertisement.delete()
        after_size = ReportGroup.objects.count()

        self.assertEqual(before_size, after_size + 1)

    """
    --REPORTS PROPERTY TESTS--
    """

    def test_reports_property_returns_all_reports_belonging_to_group(self):
        reports = self.report_group.reports
        self.assertTrue(reports.filter(id=self.job_advertisemen_report.id).exists())

        new_report = JobAdvertisementReport.objects.create(
            report_group=self.report_group,
            report_date=timezone.now(),
            reporter=self.job_seeker,
            report_text="Not appropriate"
        )

        reports = self.report_group.reports
        self.assertTrue(reports.filter(id=new_report.id).exists())

    """
    --REPORTS PROPERTY TESTS--
    """

    def test_reports_count_property_returns_correct_number(self):
        reports = self.report_group.reports
        self.assertEqual(1, self.report_group.reports_count)

        new_report = JobAdvertisementReport.objects.create(
            report_group=self.report_group,
            report_date=timezone.now(),
            reporter=self.job_seeker,
            report_text="Not appropriate"
        )

        reports = self.report_group.reports
        self.assertEqual(2, self.report_group.reports_count)
        
    """
    --TEST STRING METHOD--
    """  
        
    def test_job_advertisement_str_method(self):
        self.assertEqual(str(self.report_group),f"Advert {self.report_group.id}")
