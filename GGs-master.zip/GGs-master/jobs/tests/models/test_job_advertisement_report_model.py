from django.core.exceptions import ValidationError
from django.test import TestCase
from django.utils import timezone
from djmoney.money import Money
from jobs.models import User, JobSeeker, JobAdvertisement, Employer, JobAdvertisementReport, ReportGroup, CurrencyRate


class JobAdvertisementReportTestCase(TestCase):
    """Unit tests for job advertisement report model"""

    fixtures = [
        'jobs/tests/fixtures/default_job_seekers.json',
        'jobs/tests/fixtures/default_employers.json',
    ]

    def setUp(self):
        self.job_seeker = JobSeeker.objects.get(user_id=(User.objects.get(email="john.doe@example.org").id))
        self.employer = Employer.objects.get(user_id=User.objects.get(email="james.jamison@example.org"))

        CurrencyRate.objects.create(currency='USD', exchange_rate=1)

        self.job_advertisement = JobAdvertisement.objects.create(
            employer=self.employer,
            job_title="Director of Print Statements",
            job_description="As the director of print statements you will be responsible fro make sure all print statements are of the correct syntax and that the terminal is kept in a tidy state",
            start_date=timezone.now(),
            salary_type="Yearly",
            salary=Money(100000, 'USD'),
            remote_work=False,
            hours=40,
            website="https://docs.oracle.com/en/java/",
        )

        self.report_group = ReportGroup.objects.create(
            job_advertisement=self.job_advertisement
        )

        self.job_advertisement_report = JobAdvertisementReport.objects.create(
            report_group=self.report_group,
            report_date=timezone.now(),
            reporter=self.job_seeker,
            report_text="Not an actual job posting"
        )

    def _assert_job_advertisement_report_is_valid(self):
        try:
            self.job_advertisement_report.full_clean()
        except (ValidationError):
            self.fail("Test report should be valid")

    def _assert_advertisement_report_is_invalid(self):
        with self.assertRaises(ValidationError):
            self.job_advertisement_report.full_clean()

    def test_job_advertisement_report_is_valid(self):
        """Check if test job advertisement report is originally valid"""
        self._assert_job_advertisement_report_is_valid()

    """
    --REPORT GROUP FIELD TESTS--
    """

    def test_report_group_cannot_be_blank(self):
        self.job_advertisement_report.report_group = None
        self._assert_advertisement_report_is_invalid()

    def test_deleting_report_group_deletes_report_as_well(self):
        before_size = JobAdvertisementReport.objects.count()
        self.report_group.delete()
        after_size = JobAdvertisementReport.objects.count()

        self.assertEqual(before_size, after_size + 1)

    """
    --REPORT DATE FIELD TESTS--
    """

    def test_report_date_cannot_be_blank(self):
        self.job_advertisement_report.report_date = None
        self._assert_advertisement_report_is_invalid()

    """
    --REPORTER FIELD TESTS--
    """

    def test_reporter_cannot_be_blank(self):
        self.job_advertisement_report.reporter = None
        self._assert_advertisement_report_is_invalid()

    def test_deleting_reporter_deletes_report_as_well(self):
        before_size = JobAdvertisementReport.objects.count()
        self.job_seeker.delete()
        after_size = JobAdvertisementReport.objects.count()

        self.assertEqual(before_size, after_size + 1)

    """
    --REPORT TEXT FIELD TESTS--
    """

    def test_report_text_can_be_blank(self):
        self.job_advertisement_report.report_text = None
        self._assert_job_advertisement_report_is_valid()

    def test_report_text_can_be_200_characters(self):
        self.job_advertisement_report.report_text = "x" * 200
        self._assert_job_advertisement_report_is_valid()

    def test_report_text_cannot_be_over_200_characters(self):
        self.job_advertisement_report.report_text = "x" * 201
        self._assert_advertisement_report_is_invalid()
        
    """
    --TEST STRING METHOD--
    """  
        
    def test_job_advertisement_REPORTstr_method(self):
        self.assertEqual(str(self.job_advertisement_report),f'{self.job_advertisement_report.id}')
