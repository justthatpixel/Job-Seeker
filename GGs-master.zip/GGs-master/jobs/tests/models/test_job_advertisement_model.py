from django.core.exceptions import ValidationError
from django.test import TestCase
from jobs.matchers import delete_expired_adverts
from django.utils import timezone
from datetime import timedelta
from djmoney.money import Money

from jobs.models import User, JobSeeker, JobAdvertisement, Employer, Notification, CurrencyRate

class JobAdvertisementTestCase(TestCase):
    """Unit tests for job advertisement model"""
    
    fixtures = [
        'jobs/tests/fixtures/default_job_seekers.json',
        'jobs/tests/fixtures/default_employers.json',
        'jobs/tests/fixtures/default_staff.json',
    ]

    def setUp(self):
        self.job_seeker = JobSeeker.objects.get(user_id=(User.objects.get(email="john.doe@example.org").id))
        self.employer = Employer.objects.get(user_id=User.objects.get(email="james.jamison@example.org"))

        CurrencyRate.objects.create(currency='USD', exchange_rate=1)

        self.job_advertisement = JobAdvertisement.objects.create(
            employer=self.employer,
            job_title="Director of Print Statements",
            job_description="As the director of print statements you will be responsible fro make sure all print statements are of the correct syntax and that the terminal is kept in a tidy state",
            start_date=timezone.now(),
            salary_type="Yearly",
            salary=Money(100000, 'USD'),
            city="London",
            remote_work=False,
            hours=40,
            website="https://docs.oracle.com/en/java/",
        )


    def _assert_advertisement_is_valid(self):
        try:
            self.job_advertisement.full_clean()
        except (ValidationError):
            self.fail("Test job advertisement should be valid")

    def _assert_advertisement_is_invalid(self):
        with self.assertRaises(ValidationError):
            self.job_advertisement.full_clean()


    def test_job_advertisement_is_valid(self):
        """Check if test job application is originally valid"""
        self._assert_advertisement_is_valid()

    """
    --EMPLOYER FIELD TESTS--
    """
    def test_employer_cannot_be_blank(self):
        self.job_advertisement.employer = None
        self._assert_advertisement_is_invalid()

    def test_deleting_employer_deletes_advertisements_as_well(self):
        before_size = JobAdvertisement.objects.count()
        self.employer.delete()
        after_size = JobAdvertisement.objects.count()

        self.assertEqual(before_size,after_size+1)


    """
    --JOB TITLE TESTS--
    """

    def test_job_title_cannot_be_blank(self):
        self.job_advertisement.job_title = ''
        self._assert_advertisement_is_invalid()

    def test_job_title_does_not_have_to_be_unique(self):
        alt_advertisement = JobAdvertisement.objects.create(
            employer=self.employer,
            job_title="title",
            job_description="desc",
            start_date=timezone.now(),
            salary_type="Yearly",
            salary=Money(100000, 'USD'),
            city="city",
            remote_work=False,
            hours=50,
            website="https://google.com",
        )
        self.job_advertisement.job_title = alt_advertisement.job_title
        self._assert_advertisement_is_valid()

    def test_job_title_can_be_100_characters(self):
        self.job_advertisement.job_title = 'x' * 100
        self._assert_advertisement_is_valid()

    def test_job_title_cannot_be_over_100_characters(self):
        self.job_advertisement.job_title = 'x' * 101
        self._assert_advertisement_is_invalid()


    """
    --JOB DESCRIPTION TESTS--
    """

    def test_job_description_cannot_be_blank(self):
        self.job_advertisement.job_description = ''
        self._assert_advertisement_is_invalid()

    def test_job_description_does_not_have_to_be_unique(self):
        alt_advertisement = JobAdvertisement.objects.create(
            employer=self.employer,
            job_title="title",
            job_description="desc",
            start_date=timezone.now(),
            salary_type="Yearly",
            salary=Money(100000, 'USD'),
            city="city",
            remote_work=False,
            hours=50,
            website="https://google.com",
        )
        self.job_advertisement.job_description = alt_advertisement.job_description
        self._assert_advertisement_is_valid()

    def test_job_description_can_be_200_characters(self):
        self.job_advertisement.job_description = 'x' * 200
        self._assert_advertisement_is_valid()

    def test_job_description_cannot_be_over_200_characters(self):
        self.job_advertisement.job_description = 'x' * 201
        self._assert_advertisement_is_invalid()

    """
    --START DATE FIELD TESTS--
    """
    def test_advertisement_date_cannot_be_blank(self):
        self.job_advertisement.start_date = ''
        self._assert_advertisement_is_invalid()

    """
    --SALARY FIELD TESTS--
    """

    """
    --DELETE NOTIFICATIONS TESTS--
    """
    def test_notification_generated_when_admin_delete_an_advertisement(self):
        self.job_advertisement.delete()
        self.assertEqual(1, Notification.objects.all().filter(user_to_notify=User.objects.get(email="james.jamison@example.org")).count())

    def test_notification_not_generated_when_standard_users_delete_an_advertisement(self):
        self.job_advertisement.delete(is_admin=False)
        self.assertEqual(0, Notification.objects.all().filter(user_to_notify=User.objects.get(email="james.jamison@example.org")).count())
    
    def test_advertisement_is_deleted_when_its_start_date_expires(self):
        self.job_advertisement.start_date = timezone.now()+timedelta(days=-2)
        self.job_advertisement.save()
        delete_expired_adverts()
        self.assertEqual(0, JobAdvertisement.objects.all().count())
    
    def test_notification_generated_when_advertisement_start_date_expires(self):
        self.job_advertisement.start_date = timezone.now()+timedelta(days=-2)
        self.job_advertisement.save()
        delete_expired_adverts()
        self.assertEqual(1, Notification.objects.all().filter(user_to_notify=User.objects.get(email="james.jamison@example.org")).count())
    
    def test_job_advertisement_str_method(self):
        self.assertEqual(str(self.job_advertisement),f"Advert {self.job_advertisement.id}")
    

    """
    --JOB TYPE FIELD TESTS--
    """
    def test_job_type_can_be_blank(self):
        self.job_advertisement.job_type = ''
        self._assert_advertisement_is_valid()

    """
    --HOURS FIELD TESTS--
    """
    def test_hours_cannot_be_blank(self):
        self.job_advertisement.hours = ''
        self._assert_advertisement_is_invalid()

    """
    --REMOTE WORK FIELD TESTS--
    """
    def test_remote_work_cannot_be_blank(self):
        self.job_advertisement.remote_work = ''
        self._assert_advertisement_is_invalid()

    """
    --WEBSITE FIELD TESTS--
    """
    def test_website_cannot_be_blank(self):
        self.job_advertisement.website = ''
        self._assert_advertisement_is_invalid()

    """
    --BENEFITS FIELD TESTS--
    """
    def test_benefits_can_be_blank(self):
        self.job_advertisement.benefits = ''
        self._assert_advertisement_is_valid()


















