from django.core.exceptions import ValidationError
from django.test import TestCase
from django.utils import timezone
from djmoney.money import Money
from jobs.models import User, JobSeeker, JobApplication, JobAdvertisement, Employer, CurrencyRate



class JobApplicationTestCase(TestCase):
    """Unit tests for job application model"""

    fixtures = [
        'jobs/tests/fixtures/default_job_seekers.json',
        'jobs/tests/fixtures/default_employers.json',
        'jobs/tests/fixtures/default_staff.json',
    ]

    def setUp(self):
        self.job_seeker = JobSeeker.objects.get(user_id=(User.objects.get(email="john.doe@example.org").id))
        self.employer = Employer.objects.get(user_id=User.objects.get(email="james.jamison@example.org"))

        CurrencyRate.objects.create(currency='USD', exchange_rate=1)

        self.job_advertisement = JobAdvertisement.objects.create(
            employer=self.employer,
            job_title="Director of Print Statements",
            job_description="As the director of print statements you will be responsible fro make sure all print statements are of the correct syntax and that the terminal is kept in a tidy state",
            start_date=timezone.now(),
            salary_type="Yearly",
            salary=Money(100000, 'USD'),
            remote_work=False,
            hours=40,
            website="https://docs.oracle.com/en/java/",
        )

        self.job_application = JobApplication.objects.create(
            job_seeker=self.job_seeker,
            advertisement=self.job_advertisement,
            application_date=timezone.now()
        )

    def _assert_application_is_valid(self):
        try:
            self.job_application.full_clean()
        except (ValidationError):
            self.fail("Test job application should be valid")

    def _assert_application_is_invalid(self):
        with self.assertRaises(ValidationError):
            self.job_application.full_clean()

    def test_job_application_is_valid(self):
        """Check if test job application is originally valid"""
        self._assert_application_is_valid()

    """
    --ADVERTISEMENT FIELD TESTS--
    """

    def test_advertisement_cannot_be_blank(self):
        self.job_application.advertisement = None
        self._assert_application_is_invalid()

    def test_deleting_advertisement_deletes_application_as_well(self):
        before_size = JobApplication.objects.count()
        self.job_advertisement.delete()
        after_size = JobApplication.objects.count()

        self.assertEqual(before_size, after_size + 1)

    """
    --JOB SEEKER FIELD TESTS--
    """

    def test_job_seeker_cannot_be_blank(self):
        self.job_application.job_seeker = None
        self._assert_application_is_invalid()

    def test_deleting_job_seeker_deletes_application_as_well(self):
        before_size = JobApplication.objects.count()
        self.job_seeker.delete()
        after_size = JobApplication.objects.count()

        self.assertEqual(before_size, after_size + 1)

    """
    --APPLICATION DATE FIELD TESTS--
    """

    def test_application_date_cannot_be_blank(self):
        self.job_application.application_date = ''
        self._assert_application_is_invalid()
