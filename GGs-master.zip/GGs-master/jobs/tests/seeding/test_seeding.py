# #TODO Uncomment this when want to test seeder

# from django.test import TestCase
# from jobs.models import User, JobSeeker, Employer, JobAdvertisement, JobApplication, JobAdvertisementReport, ReportGroup
# from django.core.management import call_command
# from django.db import transaction
# from django.conf import settings
# from django.contrib.auth.hashers import check_password


# class SeederUnseederTestCase(TestCase):
#     """
#     NOTE TO ANYONE RUNNING THESE TEST CASES
#     Each of these cases will seed the database before running
#     Therefore the more entities you have the seeder seed, the longer it will take
#     So I recommend you go to the project settings file and lower teh number of seeded values
#     You can change it back afterwards
#     """

#     def setUp(self):
#         super(TestCase, self).setUp()

#         # Seed database so tests can be run on it
#         with transaction.atomic():
#             call_command('seed')

#     def test_seeding_creates_expected_number_of_users(self):
#         job_seeker_count = JobSeeker.objects.count()
#         employer_count = Employer.objects.count()
#         self.assertEqual(job_seeker_count, settings.RANDOM_JOB_SEEKER_COUNT+2)
#         self.assertEqual(employer_count, settings.RANDOM_EMPLOYER_COUNT+2)

#     def test_seeding_creates_expected_number_of_job_advertisements(self):
#         advertisement_count = JobAdvertisement.objects.count()
#         # Adding 4 as there will be 4 pre-defined entities seeded in addition to the random ones
#         self.assertEqual(advertisement_count, settings.RANDOM_JOB_ADVERTISEMENT_COUNT+4)

#     def test_seeding_creates_expected_number_of_job_applications(self):
#         application_count = JobApplication.objects.count()
#         # Adding 6 as there will be 6 pre-defined entities seeded in addition to the random ones
#         self.assertEqual(application_count, settings.RANDOM_JOB_APPLICATION_COUNT+6)

#     def test_seeding_creates_pre_defined_applications(self):
#         # Check to see if application for 'Java Specialist' by 'John Doe' application has been seeded
#         applied_to_advertisement = JobAdvertisement.objects.get(job_title="Java Developer")
#         applicant = JobSeeker.objects.get(user_id=User.objects.get(email="john.doe@example.org").id)
#         self.assertTrue(JobApplication.objects.filter(advertisement=applied_to_advertisement,job_seeker=applicant).exists())

#         # Check to see if application for 'Scala Enjoyer' by 'Jane Doe' application has been seeded
#         applied_to_advertisement = JobAdvertisement.objects.get(job_title="Scala Developer")
#         applicant = JobSeeker.objects.get(user_id=User.objects.get(email="jane.doe@example.org").id)
#         self.assertTrue(JobApplication.objects.filter(advertisement=applied_to_advertisement,job_seeker=applicant).exists())


#     def test_unseeding_clears_employers(self):
#         call_command('unseed')
#         self.assertEqual(0,Employer.objects.count())
