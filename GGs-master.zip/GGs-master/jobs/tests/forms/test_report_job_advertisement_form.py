from django import forms
from django.test import TestCase
from jobs.forms.job_seeker_forms import JobAdvertisementReportForm


class JobAdvertisementReportFormTestCase(TestCase):
    """Test the job advertisement report form"""

    def setUp(self):
        super(TestCase, self).setUp()

        self.form_input = {
            'report_text': 'Not appropriate',
        }

    def test_form_contains_required_fields(self):
        form = JobAdvertisementReportForm()
        self.assertIn('report_text', form.fields)

    def test_form_uses_correct_fields_and_widgets(self):
        form = JobAdvertisementReportForm()

        report_text_field = form.fields['report_text']
        self.assertTrue(isinstance(report_text_field, forms.CharField))
        text_area_widget = form.fields['report_text'].widget
        self.assertTrue(isinstance(text_area_widget, forms.Textarea))

    def test_form_uses_model_validation(self):
        self.form_input['report_text'] = 'x' * 201
        form = JobAdvertisementReportForm(data=self.form_input)
        self.assertFalse(form.is_valid())

    def test_form_accepts_valid_input(self):
        form = JobAdvertisementReportForm(data=self.form_input)
        self.assertTrue(form.is_valid())
