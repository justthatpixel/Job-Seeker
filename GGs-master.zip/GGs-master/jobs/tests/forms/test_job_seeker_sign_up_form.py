from jobs.forms.authentication_forms import JobSeekerSignUpForm
from jobs.models.user_models import User, JobSeeker
from django.test import TestCase
from django.contrib.auth.hashers import check_password


class SignUpFormTestCase(TestCase):
    """
    Tests for the employer sign up form
    Tests relevant to the SignUpForm aren't repeated in this test case
    """

    def setUp(self):
        self.form_input = {
            'first_name': 'Adam',
            'last_name': 'Johnson',
            'email': 'adam.johnson@example.com',
            'new_password': 'Password123',
            'confirmation_password': 'Password123',
            'bio': 'I specialise in the trade of cheese',
            'phone_number_0': 'US',
            'phone_number_1': '6044011234'
        }

    def test_valid_sign_up_form(self):
        form = JobSeekerSignUpForm(data=self.form_input)
        self.assertTrue(form.is_valid())

    def test_form_has_necessary_fields(self):
        form = JobSeekerSignUpForm()
        self.assertIn('bio', form.fields)

    def test_form_saves_correctly(self):
        form = JobSeekerSignUpForm(data=self.form_input)
        before_save_count = User.objects.count()
        # is_valid() must be called before save() since it generates the cleaned_data
        form.is_valid()
        form.save()
        after_save_count = User.objects.count()
        self.assertEqual(after_save_count, before_save_count + 1)

        user = User.objects.get(email='adam.johnson@example.com')
        job_seeker_details = JobSeeker.objects.get(user=user)
        self.assertEqual(job_seeker_details.bio, 'I specialise in the trade of cheese')
        self.assertEqual(user.first_name, 'Adam')
        self.assertEqual(user.last_name, 'Johnson')
        self.assertEqual(user.user_type, 'job_seeker')
        is_password_correct = check_password('Password123', user.password)
        self.assertTrue(is_password_correct)
