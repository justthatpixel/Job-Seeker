from django.test import TestCase
from jobs.forms import JobSeekerSearchPreferenceForm
from job_hiring.settings import GEOAPIFY_API_KEY


class JobSeekerPreferenceTestCase(TestCase):
    """Tests for the Job seeker preference form"""

    fixtures = ['jobs/tests/fixtures/default_job_seekers.json']

    def setUp(self):
        super(TestCase, self).setUp()
        self.form_input = {
            'country': 'United Kingdom',
            'state': 'London',
            'city': 'London',
            'hours': 40,
            'type': 'Full-time',
            'job_title': 'Accountant',
            'remote': False
        }

    def test_valid_job_seeker_preference_form(self):
        form = JobSeekerSearchPreferenceForm(data=self.form_input)
        self.assertTrue(form.is_valid())
        
    
    def test_form_has_necessary_fields(self):
        form = JobSeekerSearchPreferenceForm()
        self.assertIn('country', form.fields)
        self.assertIn('state', form.fields)
        self.assertIn('city', form.fields)
        self.assertIn('hours', form.fields)
        self.assertIn('type', form.fields)
        self.assertIn('job_title', form.fields)
        self.assertIn('remote', form.fields)
        
        
    def test_pass_on_missing_country_state_and_city(self):
        form_data = {
            'hours': 40,
            'type': 'Full-time',
            'job_title': 'Accountant',
            'remote': False
        }
        form = JobSeekerSearchPreferenceForm(data=form_data)
        self.assertTrue(form.is_valid())
        
        
    def test_fail_on_missing_country_state(self):
        form_data = {
            'hours': 40,
            'city':'London',
            'type': 'Full-time',
            'job_title': 'Accountant',
            'remote': False
        }
        form = JobSeekerSearchPreferenceForm(data=form_data)
        self.assertFalse(form.is_valid())
        self.assertEqual(form.errors['country'], ['Input the country the city below belongs to.'])
        self.assertEqual(form.errors['state'], ['Input the state/region the city below belongs to.'])
    
    def test_fail_on_missing_country_city(self):
        form_data = {
            'hours': 40,
            'state':'London',
            'type': 'Full-time',
            'job_title': 'Accountant',
            'remote': False
        }
        form = JobSeekerSearchPreferenceForm(data=form_data)
        self.assertFalse(form.is_valid())
        self.assertEqual(form.errors['country'], ['Input the country the state below belongs to.'])
        
    def test_fail_on_missing_country_city(self):
        form_data = {
            'hours': 40,
            'state':'London',
            'type': 'Full-time',
            'job_title': 'Accountant',
            'remote': False
        }
        form = JobSeekerSearchPreferenceForm(data=form_data)
        self.assertFalse(form.is_valid())
        self.assertEqual(form.errors['country'], ['Input the country the state below belongs to.'])
        
        
    def test_fail_on_missing_country(self):
        form_data = {
            'hours': 40,
            'state':'London',
            'city':'London',
            'type': 'Full-time',
            'job_title': 'Accountant',
            'remote': False
        }
        form = JobSeekerSearchPreferenceForm(data=form_data)
        self.assertFalse(form.is_valid())
        self.assertEqual(form.errors['country'], ['Input the country the state and city below belong to.'])
        
        
    def test_pass_on_real_country(self):
        form_data = {
            'hours': 40,
            'country':'United Kingdom',
            'type': 'Full-time',
            'job_title': 'Accountant',
            'remote': False
        }
        form = JobSeekerSearchPreferenceForm(data=form_data)
        self.assertTrue(form.is_valid())
        self.assertEqual(form.cleaned_data['country'], 'United Kingdom')
        
    def test_fail_on_fake_country(self):
        form_data = {
            'hours': 40,
            'country':'FakeCountry',
            'type': 'Full-time',
            'job_title': 'Accountant',
            'remote': False
        }
        form = JobSeekerSearchPreferenceForm(data=form_data)
        self.assertFalse(form.is_valid())
        self.assertEqual(form.errors['country'], ["This country isn't recognised, check for mispellings and avoid abreviations."])
        
    def test_pass_on_fail_on_fake__country_and_state(self):
        form_data = {
            'hours': 40,
            'country':'asfasfsdafasf',
            'state':'asdfasfasdasf',
            'type': 'Full-time',
            'job_title': 'Accountant',
            'remote': False
        }
        form = JobSeekerSearchPreferenceForm(data=form_data)
        self.assertFalse(form.is_valid())
        self.assertEqual(form.errors['country'], ["This country may not be recognised, check for mispellings and avoid abreviations."])
        self.assertEqual(form.errors['state'], ["This state may not be recognised, check for mispellings and avoid abreviations."])
        
        
    def test_pass_on_correct_country_and_state(self):
        form_data = {
            'hours': 40,
            'country':'United Kingdom',
            'state':'London',
            'type': 'Full-time',
            'job_title': 'Accountant',
            'remote': False
        }
        form = JobSeekerSearchPreferenceForm(data=form_data)
        self.assertTrue(form.is_valid())
        self.assertEqual(form.cleaned_data['country'], 'United Kingdom')
        self.assertEqual(form.cleaned_data['state'], 'England')
    
    def test_pass_on_correct_country_state_city(self):
        form_data = {
            'hours': 40,
            'country':'United Kingdom',
            'state':'London',
            'city':'London',
            'type': 'Full-time',
            'job_title': 'Accountant',
            'remote': False
        }
        form = JobSeekerSearchPreferenceForm(data=form_data)
        self.assertTrue(form.is_valid())
        self.assertEqual(form.cleaned_data['country'], 'United Kingdom')
        self.assertEqual(form.cleaned_data['state'], 'England')
        self.assertEqual(form.cleaned_data['city'], 'London')
    
    def test_fail_on_incorrect_country_state_city(self):
        form_data = {
            'hours': 40,
            'country':'asdfdsa',
            'state':'asdfsafsa',
            'city':'asfadfsafsf',
            'type': 'Full-time',
            'job_title': 'Accountant',
            'remote': False
        }
        form = JobSeekerSearchPreferenceForm(data=form_data)
        self.assertFalse(form.is_valid())
        self.assertEqual(form.errors['country'], ["This country may not be recognised, check for mispellings and avoid abreviations."])
        self.assertEqual(form.errors['state'], ["This state may not be recognised, check for mispellings and avoid abreviations."])
        self.assertEqual(form.errors['city'], ["This city may not be recognised, check for mispellings and avoid abreviations."])
        
    def test_call_api(self):
        country = "United Kingdom"
        state = "England"
        city = "London"
        form = JobSeekerSearchPreferenceForm()
        response = form.callAPI(f"https://api.geoapify.com/v1/geocode/search?country={country}&state={state}&city={city}&format=json&apiKey={GEOAPIFY_API_KEY}")
        self.maxDiff = None
        self.assertEqual(response,[{'datasource': {'sourcename': 'openstreetmap', 
                                                   'attribution': '© OpenStreetMap contributors',
                                                   'license': 'Open Database License', 'url': 'https://www.openstreetmap.org/copyright'},
                                                   'name': 'London', 'country': 'United Kingdom',
                                                   'country_code': 'gb',
                                                   'state': 'England',
                                                   'county': 'Greater London',
                                                   'city': 'London',
                                                   'lon': -0.1276474,
                                                   'lat': 51.5073219,
                                                   'state_code': 'ENG',
                                                   'formatted': 'London, ENG, United Kingdom',
                                                   'address_line1': 'London', 'address_line2': 'ENG, United Kingdom',
                                                   'category': 'populated_place', 'timezone': {'name': 'Europe/London',
                                                                                               'offset_STD': '+00:00',
                                                                                               'offset_STD_seconds': 0,
                                                                                               'offset_DST': '+01:00',
                                                                                               'offset_DST_seconds': 3600,
                                                                                               'abbreviation_STD': 'GMT',
                                                                                               'abbreviation_DST': 'BST'},
                                                   'result_type': 'city',
                                                   'rank': {'importance': 1.2507827616237295,
                                                            'popularity': 9.988490181891963,
                                                            'confidence': 1, 'confidence_city_level': 1,
                                                            'match_type': 'full_match'},
                                                   'place_id': '51e5af3500c056c0bf59b5858cecefc04940f00101f9014600010000000000c002089203064c6f6e646f6e',
                                                   'bbox': {'lon1': -0.5103751,
                                                            'lat1': 51.2867601,
                                                            'lon2': 0.3340155,
                                                            'lat2': 51.6918741}},
                                   {'datasource': {'sourcename': 'openstreetmap',
                                                   'attribution': '© OpenStreetMap contributors',
                                                   'license': 'Open Database License',
                                                   'url': 'https://www.openstreetmap.org/copyright'},
                                    'name': 'Chelsea', 'country': 'United Kingdom',
                                    'country_code': 'gb',
                                    'state': 'England',
                                    'county': 'Greater London',
                                    'city': 'London',
                                    'postcode': 'SW3 5UA',
                                    'district': 'Royal Borough of Kensington and Chelsea',
                                    'suburb': 'Chelsea',
                                    'lon': -0.1687007,
                                    'lat': 51.4875167,
                                    'state_code': 'ENG',
                                    'formatted': 'Chelsea, London, ENG, United Kingdom',
                                    'address_line1': 'Chelsea',
                                    'address_line2': 'London, ENG, United Kingdom',
                                    'category': 'populated_place',
                                    'timezone': {'name': 'Europe/London',
                                                 'offset_STD': '+00:00',
                                                 'offset_STD_seconds': 0,
                                                 'offset_DST': '+01:00',
                                                 'offset_DST_seconds': 3600,
                                                 'abbreviation_STD': 'GMT',
                                                 'abbreviation_DST': 'BST'},
                                    'result_type': 'suburb',
                                    'rank': {'importance': 0.951974775475308,
                                             'popularity': 7.931098190097296,
                                             'confidence': 1,
                                             'confidence_city_level': 1,
                                             'match_type': 'full_match'},
                                    'place_id': '51aff9a70afc97c5bf597e607df266be4940f00103f9013b1da30100000000c002059203074368656c736561',
                                    'bbox': {'lon1': -0.1887007, 'lat1': 51.4675167,
                                             'lon2': -0.1487007, 'lat2': 51.5075167}},
                                   {'datasource': {'sourcename': 'openstreetmap',
                                                   'attribution': '© OpenStreetMap contributors',
                                                   'license': 'Open Database License',
                                                   'url': 'https://www.openstreetmap.org/copyright'},
                                    'name': 'Vauxhall',
                                    'country': 'United Kingdom',
                                    'country_code': 'gb',
                                    'state': 'England',
                                    'county': 'Greater London',
                                    'city': 'London',
                                    'postcode': 'SE11 5AW',
                                    'district': 'London Borough of Lambeth',
                                    'suburb': 'Vauxhall',
                                    'lon': -0.1229297,
                                    'lat': 51.4874834,
                                    'state_code': 'ENG',
                                    'formatted': 'Vauxhall, London, ENG, United Kingdom',
                                    'address_line1': 'Vauxhall',
                                    'address_line2': 'London, ENG, United Kingdom',
                                    'category': 'populated_place',
                                    'timezone': {'name': 'Europe/London',
                                                 'offset_STD': '+00:00',
                                                 'offset_STD_seconds': 0,
                                                 'offset_DST': '+01:00',
                                                 'offset_DST_seconds': 3600,
                                                 'abbreviation_STD': 'GMT',
                                                 'abbreviation_DST': 'BST'},
                                    'result_type': 'suburb',
                                    'rank': {'importance': 0.8518394385016999,
                                             'popularity': 8.513913724003835,
                                             'confidence': 1,
                                             'confidence_city_level': 1,
                                             'match_type': 'full_match'},
                                    'place_id': '51ee0335215278bfbf59e42b26db65be4940f00103f901ab6fa40100000000c002059203085661757868616c6c',
                                    'bbox': {'lon1': -0.1429297, 'lat1': 51.4674834, 'lon2': -0.1029297, 'lat2': 51.5074834}},
                                   {'datasource': {'sourcename': 'openstreetmap', 'attribution': '© OpenStreetMap contributors',
                                                   'license': 'Open Database License', 'url': 'https://www.openstreetmap.org/copyright'},
                                    'name': 'National Gallery', 'country': 'United Kingdom', 'country_code': 'gb', 'state': 'England',
                                    'county': 'Greater London',
                                    'city': 'London',
                                    'postcode': 'WC2N 5DN',
                                    'district': 'Seven Dials',
                                    'suburb': 'Covent Garden',
                                    'street': 'Orange Street',
                                    'lon': -0.1283741501862351,
                                    'lat': 51.50888405, 'state_code': 'ENG', 'formatted': 'National Gallery, Orange Street, London, WC2N 5DN, United Kingdom', 'address_line1': 'National Gallery', 'address_line2': 'Orange Street, London, WC2N 5DN, United Kingdom', 'category': 'entertainment.culture.gallery', 'timezone': {'name': 'Europe/London', 'offset_STD': '+00:00', 'offset_STD_seconds': 0, 'offset_DST': '+01:00', 'offset_DST_seconds': 3600, 'abbreviation_STD': 'GMT', 'abbreviation_DST': 'BST'}, 'result_type': 'amenity', 'rank': {'importance': 0.9836382548891894, 'popularity': 8.988490181891963, 'confidence': 1, 'confidence_city_level': 1, 'match_type': 'inner_part'}, 'place_id': '5164d0596c906ec0bf595f1ad01c23c14940f00102f90122b6420000000000c002019203104e6174696f6e616c2047616c6c657279', 'bbox': {'lon1': -0.1301357, 'lat1': 51.5082611, 'lon2': -0.1273245, 'lat2': 51.5095106}}, {'datasource': {'sourcename': 'openstreetmap', 'attribution': '© OpenStreetMap contributors', 'license': 'Open Database License', 'url': 'https://www.openstreetmap.org/copyright'}, 'name': 'Hyde Park', 'country': 'United Kingdom', 'country_code': 'gb', 'state': 'England', 'county': 'Greater London', 'city': 'London', 'postcode': 'W2 2JN', 'suburb': 'Paddington', 'street': 'Hyde Park Street', 'lon': -0.16223668308067218, 'lat': 51.5074889, 'state_code': 'ENG', 'formatted': 'Hyde Park Street, London, W2 2JN, United Kingdom', 'address_line1': 'Hyde Park Street', 'address_line2': 'London, W2 2JN, United Kingdom', 'category': 'tourism.attraction', 'timezone': {'name': 'Europe/London', 'offset_STD': '+00:00', 'offset_STD_seconds': 0, 'offset_DST': '+01:00', 'offset_DST_seconds': 3600, 'abbreviation_STD': 'GMT', 'abbreviation_DST': 'BST'}, 'result_type': 'amenity', 'rank': {'importance': 0.9621581195339993, 'popularity': 8.943778675205616, 'confidence': 1, 'confidence_city_level': 1, 'match_type': 'inner_part'}, 'place_id': '51248105f02bc4c4bf59a04a7265f5c04940f00102f901a0273b1600000000c0020192030948796465205061726b', 'bbox': {'lon1': -0.1748251, 'lat1': 51.5018452, 'lon2': -0.151304, 'lat2': 51.5129739}}])
        
        
        
        