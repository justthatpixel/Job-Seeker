from django.test import TestCase
from jobs.forms.employer_forms import AdvertisementForm
import datetime


class RequestTestCase(TestCase):

    fixtures = [
        'jobs/tests/fixtures/default_employers.json'
    ]

    def setUp(self):
        super(TestCase, self).setUp()
        self.form_input = {
            'job_title': 'Accountant',
            'job_description': 'develop a job application website',
            'start_date': datetime.date(2023, 10, 10),
            'salary_type':'Hourly',
            'salary_0': '100.00',
            'salary_1': 'EUR',
            'country': 'United Kingdom',
            'state': 'England',
            'city': 'London',
            'street': '117 wilmington gardens',
            'postcode': 'IG11 9TR',
            'hours': 60,
            'remote_work': True,
            'job_type': 'Part-time',
            'website':'https://www.computerhope.com',
        }

    def test_form_contains_required_fields(self):
        form = AdvertisementForm()
        self.assertIn('job_title', form.fields)
        self.assertIn('job_description', form.fields)
        self.assertIn('start_date', form.fields)
        self.assertIn('salary_type', form.fields)
        self.assertIn('salary', form.fields)
        self.assertIn('country', form.fields)
        self.assertIn('state', form.fields)
        self.assertIn('city', form.fields)
        self.assertIn('street', form.fields)
        self.assertIn('postcode', form.fields)
        self.assertIn('hours', form.fields)
        self.assertIn('job_type', form.fields)
        self.assertIn('remote_work', form.fields)
        self.assertIn('website', form.fields)
        self.assertIn('benefits', form.fields)
        
    def test_fail_on_missing_postcode(self):
        self.form_input = {
            'job_title': 'Accountant',
            'job_description': 'develop a job application website',
            'start_date': datetime.date(2023, 10, 10),
            'salary_type':'Hourly',
            'salary_0': '100.00',
            'salary_1': 'EUR',
            'country': 'United Kingdom',
            'state': 'England',
            'city': 'London',
            'street': '117 wilmington gardens',
            'hours': 60,
            'remote_work': True,
            'job_type': 'Part-time',
            'website':'https://www.computerhope.com',
        }
        form = AdvertisementForm(data=self.form_input)
        self.assertFalse(form.is_valid())
        self.assertEqual(form.errors['country'], ['Please specify either all or none of the job location details.'])
        self.assertEqual(form.errors['state'], ['Please specify either all or none of the job location details.'])
        self.assertEqual(form.errors['city'], ['Please specify either all or none of the job location details.'])
        self.assertEqual(form.errors['street'], ['Please specify either all or none of the job location details.'])
        self.assertEqual(form.errors['postcode'], ['Please specify either all or none of the job location details.'])
        
    def test_fail_on_missing_street(self):
        self.form_input = {
            'job_title': 'Accountant',
            'job_description': 'develop a job application website',
            'start_date': datetime.date(2023, 10, 10),
            'salary_type':'Hourly',
            'salary_0': '100.00',
            'salary_1': 'EUR',
            'country': 'United Kingdom',
            'state': 'England',
            'city': 'London',
            'postcode': 'Ig11 9tr',
            'hours': 60,
            'remote_work': True,
            'job_type': 'Part-time',
            'website':'https://www.computerhope.com',
        }
        form = AdvertisementForm(data=self.form_input)
        self.assertFalse(form.is_valid())
        self.assertEqual(form.errors['country'], ['Please specify either all or none of the job location details.'])
        self.assertEqual(form.errors['state'], ['Please specify either all or none of the job location details.'])
        self.assertEqual(form.errors['city'], ['Please specify either all or none of the job location details.'])
        self.assertEqual(form.errors['street'], ['Please specify either all or none of the job location details.'])
        self.assertEqual(form.errors['postcode'], ['Please specify either all or none of the job location details.'])
        
    def test_fail_on_missing_city(self):
        self.form_input = {
            'job_title': 'Accountant',
            'job_description': 'develop a job application website',
            'start_date': datetime.date(2023, 10, 10),
            'salary_type':'Hourly',
            'salary_0': '100.00',
            'salary_1': 'EUR',
            'country': 'United Kingdom',
            'state': 'England',
            'street': '117 wilmington gardens',
            'postcode': 'Ig11 9tr',
            'hours': 60,
            'remote_work': True,
            'job_type': 'Part-time',
            'website':'https://www.computerhope.com',
        }
        form = AdvertisementForm(data=self.form_input)
        self.assertFalse(form.is_valid())
        self.assertEqual(form.errors['country'], ['Please specify either all or none of the job location details.'])
        self.assertEqual(form.errors['state'], ['Please specify either all or none of the job location details.'])
        self.assertEqual(form.errors['city'], ['Please specify either all or none of the job location details.'])
        self.assertEqual(form.errors['street'], ['Please specify either all or none of the job location details.'])
        self.assertEqual(form.errors['postcode'], ['Please specify either all or none of the job location details.'])
        
    def test_fail_on_missing_state(self):
        self.form_input = {
            'job_title': 'Accountant',
            'job_description': 'develop a job application website',
            'start_date': datetime.date(2023, 10, 10),
            'salary_type':'Hourly',
            'salary_0': '100.00',
            'salary_1': 'EUR',
            'country': 'United Kingdom',
            'city': 'London',
            'street': '117 wilmington gardens',
            'postcode': 'Ig11 9tr',
            'hours': 60,
            'remote_work': True,
            'job_type': 'Part-time',
            'website':'https://www.computerhope.com',
        }
        form = AdvertisementForm(data=self.form_input)
        self.assertFalse(form.is_valid())
        self.assertEqual(form.errors['country'], ['Please specify either all or none of the job location details.'])
        self.assertEqual(form.errors['state'], ['Please specify either all or none of the job location details.'])
        self.assertEqual(form.errors['city'], ['Please specify either all or none of the job location details.'])
        self.assertEqual(form.errors['street'], ['Please specify either all or none of the job location details.'])
        self.assertEqual(form.errors['postcode'], ['Please specify either all or none of the job location details.'])
        
    def test_fail_on_missing_country(self):
        self.form_input = {
            'job_title': 'Accountant',
            'job_description': 'develop a job application website',
            'start_date': datetime.date(2023, 10, 10),
            'salary_type':'Hourly',
            'salary_0': '100.00',
            'salary_1': 'EUR',
            'state': 'England',
            'city': 'London',
            'street': '117 wilmington gardens',
            'postcode': 'Ig11 9tr',
            'hours': 60,
            'remote_work': True,
            'job_type': 'Part-time',
            'website':'https://www.computerhope.com',
        }
        form = AdvertisementForm(data=self.form_input)
        self.assertFalse(form.is_valid())
        self.assertEqual(form.errors['country'], ['Please specify either all or none of the job location details.'])
        self.assertEqual(form.errors['state'], ['Please specify either all or none of the job location details.'])
        self.assertEqual(form.errors['city'], ['Please specify either all or none of the job location details.'])
        self.assertEqual(form.errors['street'], ['Please specify either all or none of the job location details.'])
        self.assertEqual(form.errors['postcode'], ['Please specify either all or none of the job location details.'])
        
    def test_fail_on_non_existing_location(self):
        self.form_input = {
            'job_title': 'Accountant',
            'job_description': 'develop a job application website',
            'start_date': datetime.date(2023, 10, 10),
            'salary_type':'Hourly',
            'salary_0': '100.00',
            'salary_1': 'EUR',
            'country':'ASDASFSAF',
            'state': 'asfsafasfasf',
            'city': 'asfasfadfadf',
            'street': 'asfdafadfasf',
            'postcode': 'asfdafafsasf',
            'hours': 60,
            'remote_work': True,
            'job_type': 'Part-time',
            'website':'https://www.computerhope.com',
        }
        form = AdvertisementForm(data=self.form_input)
        self.assertFalse(form.is_valid())
        self.assertEqual(form.errors['country'], ['This country may not be recognised, check for mispellings and avoid abreviations.'])
        self.assertEqual(form.errors['state'], ['This state may not be recognised, check for mispellings and avoid abreviations.'])
        self.assertEqual(form.errors['city'], ['This city may not be recognised, check for mispellings and avoid abreviations.'])
        self.assertEqual(form.errors['street'], ['This street may not be recognised, check for mispellings and avoid abreviations.'])
        self.assertEqual(form.errors['postcode'], ['This postcode may not be recognised, check for mispellings and avoid abreviations.'])
        
        
    def test_return_location(self):
        form = AdvertisementForm(data=self.form_input)
        self.assertTrue(form.is_valid())
        self.assertEqual(form.cleaned_data['country'], 'United Kingdom')
        self.assertEqual(form.cleaned_data['state'], 'England')
        self.assertEqual(form.cleaned_data['city'], 'London')
        self.assertEqual(form.cleaned_data['street'], 'Wilmington Gardens')
        self.assertEqual(form.cleaned_data['postcode'], 'IG11 9TR')
        
    
    #Can't test for country being None as if its none, then an location errors are returned instead    
    def test_return_none(self):
        self.form_input = {
            'job_title': 'Accountant',
            'job_description': 'develop a job application website',
            'start_date': datetime.date(2023, 10, 10),
            'salary_type':'Hourly',
            'salary_0': '100.00',
            'salary_1': 'EUR',
            'country': 'United Kingdom',
            'state': 'asdasf',
            'city': 'asfasfasf',
            'street': 'asfsafasfas',
            'postcode': 'asfsafasfadf',
            'hours': 60,
            'remote_work': True,
            'job_type': 'Part-time',
            'website':'https://www.computerhope.com',
        }
        form = AdvertisementForm(data=self.form_input)
        self.assertTrue(form.is_valid())
        self.assertEqual(form.cleaned_data['country'], 'United Kingdom')
        self.assertEqual(form.cleaned_data['state'], None)
        self.assertEqual(form.cleaned_data['city'], None)
        self.assertEqual(form.cleaned_data['street'], None)
        self.assertEqual(form.cleaned_data['postcode'], None)
        
    def test_form_saves_correctly(self):
        self.form_input = {
            'job_title': 'Accountant',
            'job_description': 'develop a job application website',
            'start_date': datetime.date(2023, 10, 10),
            'salary_type':'Hourly',
            'salary_0': '100.00',
            'salary_1': 'EUR',
            'country': 'United Kingdom',
            'state': 'England',
            'city': 'London',
            'street': '117 wilmington gardens',
            'postcode': 'IG11 9TR',
            'hours': 60,
            'remote_work': True,
            'job_type': 'Part-time',
            'website':'https://www.computerhope.com',
            'benefits':'Free food, free healthcare',
        }
        
        form = AdvertisementForm(data=self.form_input)
        self.assertTrue(form.is_valid())
        advertisement = form.save(commit=False)  
        
    def test_form_accepts_blank_benefits(self):
        self.form_input['benefits'] = ''
        form = AdvertisementForm(data=self.form_input)
        self.assertTrue(form.is_valid())
    
    def test_form_accepts_single_benefit(self):
        self.form_input['benefits'] = 'good salary'
        form = AdvertisementForm(data=self.form_input)
        self.assertTrue(form.is_valid())
    
        self.form_input['benefits'] = 'food'
        form = AdvertisementForm(data=self.form_input)
        self.assertTrue(form.is_valid())
    
    
    def test_form_reject_benefits_not_in_correct_form(self):
        self.form_input['benefits'] = 'company,pension,,free food,,good salary'
        form = AdvertisementForm(data=self.form_input)
        self.assertFalse(form.is_valid())
    
    def test_form_reject_benefits_with_illegal_characters(self):
        self.form_input['benefits'] = '{}?!'
        form = AdvertisementForm(data=self.form_input)
        self.assertFalse(form.is_valid())
    
        self.form_input['benefits'] = 'Food?'
        form = AdvertisementForm(data=self.form_input)
        self.assertFalse(form.is_valid())
    
        self.form_input['benefits'] = 'Food!,Food!,Food!'
        form = AdvertisementForm(data=self.form_input)
        self.assertFalse(form.is_valid())
        
    def test_blank_benefits_returns_nothing(self):
        self.form_input = {
            'job_title': 'Accountant',
            'job_description': 'develop a job application website',
            'start_date': datetime.date(2023, 10, 10),
            'salary_type':'Hourly',
            'salary_0': '100.00',
            'salary_1': 'EUR',
            'country': 'United Kingdom',
            'state': 'England',
            'city': 'London',
            'street': '117 wilmington gardens',
            'postcode': 'IG11 9TR',
            'hours': 60,
            'remote_work': True,
            'job_type': 'Part-time',
            'website':'https://www.computerhope.com',
            'benefits':'Free food, free healthcare',
        }
        
        form = AdvertisementForm(data=self.form_input)
        self.assertTrue(form.is_valid())
        advertisement = form.save(commit=False)
        form.cleaned_data['benefits'] = ''
        advertisement = form.save(commit=False)
        self.assertIsNone(advertisement.benefits)
        
    def test_no_benefits_returns_nothing(self):
        self.form_input = {
            'job_title': 'Accountant',
            'job_description': 'develop a job application website',
            'start_date': datetime.date(2023, 10, 10),
            'salary_type':'Hourly',
            'salary_0': '100.00',
            'salary_1': 'EUR',
            'country': 'United Kingdom',
            'state': 'England',
            'city': 'London',
            'street': '117 wilmington gardens',
            'postcode': 'IG11 9TR',
            'hours': 60,
            'remote_work': True,
            'job_type': 'Part-time',
            'website':'https://www.computerhope.com',
            'benefits':'Free food, free healthcare',
        }
        
        form = AdvertisementForm(data=self.form_input)
        self.assertTrue(form.is_valid())
        advertisement = form.save(commit=False)
        form.cleaned_data['benefits'] = None
        advertisement = form.save(commit=False)
        self.assertIsNone(advertisement.benefits)


    def test_form_accepts_valid_input(self):
        form = AdvertisementForm(data=self.form_input)
        self.assertTrue(form.is_valid())
