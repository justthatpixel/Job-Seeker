"""Unit tests of the user form."""
from django import forms
from django.test import TestCase
from jobs.forms.authentication_forms import UserForm


class UserFormTestCase(TestCase):
    """Unit tests of the user form"""

    fixtures = [
        'jobs/tests/fixtures/default_employers.json'
    ]

    def setUp(self):
        self.form_input = {
            'first_name': 'Jane',
            'last_name': 'Doe',
            'email': 'jane.doe@example.org',
            'phone_number_0': 'US',
            'phone_number_1': '6044011234'
        }

    def test_form_has_necessary_fields(self):
        form = UserForm()
        self.assertIn('first_name', form.fields)
        self.assertIn('last_name', form.fields)
        self.assertIn('email', form.fields)
        email_field = form.fields['email']
        self.assertTrue(isinstance(email_field, forms.EmailField))

    def test_valid_user_form(self):
        form = UserForm(data=self.form_input)
        self.assertTrue(form.is_valid())

    def test_form_uses_model_validation(self):
        self.form_input['email'] = 'bademail'
        form = UserForm(data=self.form_input)
        self.assertFalse(form.is_valid())
