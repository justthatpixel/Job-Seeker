from django import forms
from django.test import TestCase
from django.contrib.auth.hashers import check_password

from jobs.forms.authentication_forms import SignUpForm
from jobs.models.user_models import User


class SignUpFormTestCase(TestCase):
    """Tests for the sign up form"""

    fixtures = ['jobs/tests/fixtures/default_job_seekers.json']

    def setUp(self):
        self.form_input = {
            'first_name': 'Adam',
            'last_name': 'Johnson',
            'email': 'adam.johnson@example.com',
            'new_password': 'Password123',
            'confirmation_password': 'Password123',
            'phone_number_0': 'US',
            'phone_number_1': '6044011234'
        }

    def test_valid_sign_up_form(self):
        form = SignUpForm(data=self.form_input)
        self.assertTrue(form.is_valid())

    def test_form_has_necessary_fields(self):
        form = SignUpForm()
        self.assertIn('first_name', form.fields)
        self.assertIn('last_name', form.fields)

        self.assertIn('email', form.fields)
        email_field = form.fields['email']
        self.assertTrue(isinstance(email_field, forms.EmailField))

        self.assertIn('new_password', form.fields)
        new_password_widget = form.fields['new_password'].widget
        self.assertTrue(isinstance(new_password_widget, forms.PasswordInput))

        self.assertIn('confirmation_password', form.fields)
        confirmation_password_widget = form.fields['confirmation_password'].widget
        self.assertTrue(isinstance(confirmation_password_widget, forms.PasswordInput))

        self.assertIn('phone_number', form.fields)

    def test_form_uses_email_validation(self):
        self.form_input['email'] = 'badEmail'
        form = SignUpForm(data=self.form_input)
        self.assertFalse(form.is_valid())

    def test_existing_email_as_input(self):
        self.form_input['email'] = 'john.doe@example.org'
        form = SignUpForm(data=self.form_input)
        self.assertFalse(form.is_valid())

    def test_password_must_contain_uppercase_character(self):
        self.form_input['new_password'] = 'password123'
        self.form_input['confirmation_password'] = 'password123'
        form = SignUpForm(data=self.form_input)
        self.assertFalse(form.is_valid())

    def test_password_must_contain_lowercase_character(self):
        self.form_input['new_password'] = 'PASSWORD123'
        self.form_input['confirmation_password'] = 'PASSWORD123'
        form = SignUpForm(data=self.form_input)
        self.assertFalse(form.is_valid())

    def test_password_must_contain_number(self):
        self.form_input['new_password'] = 'PasswordABC'
        self.form_input['confirmation_password'] = 'PasswordABC'
        form = SignUpForm(data=self.form_input)
        self.assertFalse(form.is_valid())

    def test_new_password_and_confirmation_password_are_identical(self):
        self.form_input['confirmation_password'] = 'WrongPassword123'
        form = SignUpForm(data=self.form_input)
        self.assertFalse(form.is_valid())

    def test_form_bad_phone_number_region(self):
        self.form_input['phone_number_0'] = 'USSR'
        self.form_input['phone_number_1'] = '6044011234'
        form = SignUpForm(data=self.form_input)
        self.assertFalse(form.is_valid())

    def test_form_bad_phone_number_number(self):
        self.form_input['phone_number_0'] = 'US'
        self.form_input['phone_number_1'] = '7894561230'
        form = SignUpForm(data=self.form_input)
        self.assertFalse(form.is_valid())

    def test_form_saves_correctly(self):
        form = SignUpForm(data=self.form_input)
        before_save_count = User.objects.count()
        # is_valid() must be called before save() since it generates the cleaned_data
        form.is_valid()
        form.save()
        after_save_count = User.objects.count()
        self.assertEqual(after_save_count, before_save_count + 1)

        user = User.objects.get(email='adam.johnson@example.com')
        self.assertEqual(user.first_name, 'Adam')
        self.assertEqual(user.last_name, 'Johnson')
        is_password_correct = check_password('Password123', user.password)
        self.assertTrue(is_password_correct)
