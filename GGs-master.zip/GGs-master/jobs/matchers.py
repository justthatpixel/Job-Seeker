from jobs.models import JobApplication, JobAdvertisement
from django.utils import timezone

THRESHOLD = 1

def below_threshold(n):
    return n < THRESHOLD

def delete_expired_adverts():
    """For all adverts if their start date is in the past then they are deleted"""
    ads = JobAdvertisement.objects.all()
    for ad in ads:
        if ad.start_date < timezone.now():
            ad.delete(is_expired=True)

# template refers to the template pattern, not django templates
def template_match(adverts, job_seeker, *strategies):
    """
    Filters and reorders the adverts passed to it by applying strategies in the order they were given

    Args:
        adverts (List): The initial set of adverts

        job_seeker (JobSeeker): The user who the adverts will be matched to

        *strategies (*function): Each strategy must have a List and JobSeeker parameter and return a List
                                 A strategy can filter and/or reorder a QuerySet 

    Returns:
        QuerySet: The ordered set of job seeker tailored adverts
    """
    ads = adverts
    for strat in strategies:
        temp_ads = strat(ads, job_seeker)
        # If the this strategy's filtering removes enough adverts that the number of adverts is below the threshold
        # then we discount this strategy and move on to the next
        # This avoids overtrimming a seeker's advert list
        if not below_threshold(len(temp_ads)):
            ads = temp_ads
    return ads


def field_filter(ad_list, **filters):
    """
    This is a sudo replacement of the QuerySet filter method, designed to be used on lists. This function's main difference
    is that it only filters by the field values of adverts.
    Example invocation: field_filter(ads, id=[60,61,72], salary=[20, 40])

    Args:
        ad_list (List): The list of adverts that will be filtered.
        
        **filters (<field name>=List<field values>): The dictionary of key value pairs where each value is a list of values to filter by
        based on the field specified by its associated key.

    Returns:
        List: The filtered list of adverts.
    """
    ads = []
    for ad in ad_list:
        addable = True
        for k, v in filters.items():
            for field_value in v:
                try:
                    if getattr(ad, k).lower() != field_value.lower():
                        addable = False
                except:
                    # If the ad's field is None then the match is automatically a success regardless of the value of the seekers's field
                    if getattr(ad, k) == None:
                        break
                    if getattr(ad, k) != field_value:
                        addable = False
        if addable:
            ads.append(ad)
    return ads


def field_exclude(ad_list, **exclusions):
    """
    This is a sudo replacement of the QuerySet exclude method, designed to be used on lists. This function's main difference
    is that it only excludes by the field values of adverts.
    Example invocation: field_exclude(ads, id=[60,61], job_title=[Engineer])

    Args:
        ad_list (List): The list of adverts that will be trimmed.
        
        **filters (<field name>=List<field values>): The dictionary of key value pairs where each value is a list of values to exclude
        from the ad_list based on the field specified by its associated key.

    Returns:
        List: The trimmed list of adverts.
    """
    ads = []
    for ad in ad_list:
        addable = True
        for k, v in exclusions.items():
            for field_value in v:
                try:
                    if getattr(ad, k).lower() == field_value.lower():
                        addable = False
                except:
                    if getattr(ad, k) == field_value:
                        addable = False
        if addable:
            ads.append(ad)
    return ads


def location_match(adverts, job_seeker):
    """Filters the advertisements by their location data relative the seeker's location criteria"""
    ids_to_exclude = []
    for ad in adverts:
        match (ad.country, ad.state, ad.city):
            # If these fields are all none it implies the job is not location specific and so is available no matter
            # the location criteria of the seeker
            case (None, None, None):
                pass
            case (_, _, _):
                match (job_seeker.country, job_seeker.state, job_seeker.city):
                    # If the seeker fields are all None then their search criteria is global, the locations have no affect on the filtering
                    case (None, None, None):
                        pass
                    case (_, None, None):
                        if ad.country != job_seeker.country:
                            ids_to_exclude.append(ad.id)
                    case (_, _, None):
                        if ad.country != job_seeker.country or ad.state != job_seeker.state:
                            ids_to_exclude.append(ad.id)
                    case (_, _, _):
                        if ad.country != job_seeker.country or ad.state != job_seeker.state or ad.city != job_seeker.city:
                            ids_to_exclude.append(ad.id)
    return field_exclude(adverts, id=ids_to_exclude)


def job_title_match(advertisements, job_seeker):
    """Filters the advertisements by the job title specified by the job seeker."""
    ads = []
    if job_seeker.job_title != None:
        for ad in advertisements:
            matched = False
            split_ad_title = ad.job_title.lower().replace("_", " ").split(" ")
            split_seeker_title = job_seeker.job_title.lower().replace("_", " ").split(" ")
            for ad_word in split_ad_title:
                for seeker_word in split_seeker_title:
                    if ad_word == seeker_word:
                        ads.append(ad)
                        matched = True
                        break
                if matched:
                    break
        return ads
    return advertisements


def hours_match(advertisements, job_seeker):
    """Filters the advertisements to show only those that are smaller than or equal to the hours of job seeker."""
    if job_seeker.hours != None:
        ads = []
        for ad in advertisements:
            if ad.hours <= job_seeker.hours:
                ads.append(ad)
        return ads
    return advertisements


def remote_work_match(advertisements, job_seeker):
    """Filters the advertisements on the basis of the job seeker wanting to work remotely or not."""
    if job_seeker.remote != None:
        return field_filter(advertisements, remote_work=[job_seeker.remote])
    return advertisements

def job_type_match(advertisements, job_seeker):
    """Filters the advertisements on the type of job the seeker wants to work."""
    if job_seeker.type != None:
        return field_filter(advertisements, job_type=[job_seeker.type])
    return advertisements


def salary_match(advertisements, job_seeker):
    """Filters out advertisements which have a lower salary than the minimum salary of the seeker."""
    if job_seeker.min_salary != None:
        ads = []
        for ad in advertisements:
            ad_salary_amount = float(ad.salary.amount)
            ad_exchange_rate = float(ad.exchange_rate)
            job_seeker_exchange_rate = float(job_seeker.exchange_rate)
            job_seeker_min_salary_amount = float(job_seeker.min_salary.amount)
            match ad.salary_type:
                case 'Hourly':
                    if ((ad_salary_amount*ad.hours*52*ad_exchange_rate)/job_seeker_exchange_rate) >= job_seeker_min_salary_amount:
                        ads.append(ad)
                case 'Monthly':
                    if ((ad_salary_amount*12*ad_exchange_rate)/job_seeker_exchange_rate) >= job_seeker_min_salary_amount:
                        ads.append(ad)
                case 'Yearly':
                    if ((ad_salary_amount*ad_exchange_rate)/job_seeker_exchange_rate) >= job_seeker_min_salary_amount:
                        ads.append(ad)
        return ads
    return advertisements


def order_by_application_count(advertisements, job_seeker):
    """Orders the advertisements by the number of job applications in descending order."""
    ads_with_application_count = map(lambda ad: (ad, JobApplication.objects.filter(advertisement=ad).count()), advertisements)
    ordered_ads_with_application_count = sorted(ads_with_application_count, key=lambda ad: ad[1], reverse=True)
    ordered_ads = map(lambda ad: ad[0], ordered_ads_with_application_count)
    return list(ordered_ads)


def order_by_start_date(advertisements, job_seeker):
    """Orders the advertisements by the their start dates from closest to latest."""
    return list(sorted(advertisements, key=lambda ad: (ad.start_date.year, ad.start_date.month, ad.start_date.day)))


def order_by_hours(advertisements, job_seeker):
    """Orders the advertisements by their working hours from shortest to longest"""
    return list(sorted(advertisements, key=lambda ad: ad.hours))